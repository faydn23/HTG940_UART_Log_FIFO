//Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
//Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
//--------------------------------------------------------------------------------
//Tool Version: Vivado v.2025.1_REL2_CR1238551_REL2 (lin64) Build 0 Fri Sep 12 10:40:17 MDT 2025
//Date        : Thu Sep 24 17:58:14 2026
//Host        : bearcat14802 running 64-bit Rocky Linux release 8.10 (Green Obsidian)
//Command     : generate_target caliptra_htg940_bd.bd
//Design      : caliptra_htg940_bd
//Purpose     : IP block netlist
//--------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

(* CORE_GENERATION_INFO = "caliptra_htg940_bd,IP_Integrator,{x_ipVendor=xilinx.com,x_ipLibrary=BlockDiagram,x_ipName=caliptra_htg940_bd,x_ipVersion=1.00.a,x_ipLanguage=VERILOG,numBlks=17,numReposBlks=17,numNonXlnxBlks=1,numHierBlks=0,maxHierDepth=0,numSysgenBlks=0,numHlsBlks=0,numHdlrefBlks=0,numPkgbdBlks=0,bdsource=USER,synth_mode=Hierarchical}" *) (* HW_HANDOFF = "caliptra_htg940_bd.hwdef" *) 
module caliptra_htg940_bd
   (EXT_SCL,
    EXT_SDA,
    EXT_SDA_EN,
    EXT_SDA_IN,
    EXT_SDA_UP,
    USB_ULPI_CLK,
    USB_ULPI_DATA,
    USB_ULPI_DIR,
    USB_ULPI_NXT,
    USB_ULPI_STP,
    board_clock_locked,
    board_core_clk,
    board_core_log_byte,
    board_core_log_valid,
    board_mcu_log_byte,
    board_mcu_log_valid,
    board_reset_n,
    host_entropy_data,
    host_entropy_req,
    host_entropy_valid,
    jtag_in,
    jtag_out,
    ref_clock_156p25mhz_clk_n,
    ref_clock_156p25mhz_clk_p,
    reset_n,
    subsystem_reset_n);
  input EXT_SCL;
  input EXT_SDA;
  output EXT_SDA_EN;
  output EXT_SDA_IN;
  output EXT_SDA_UP;
  (* X_INTERFACE_INFO = "xilinx.com:signal:clock:1.0 CLK.USB_ULPI_CLK CLK" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME CLK.USB_ULPI_CLK, CLK_DOMAIN caliptra_htg940_bd_USB_ULPI_CLK, FREQ_HZ 100000000, FREQ_TOLERANCE_HZ 0, INSERT_VIP 0, PHASE 0.0" *) input USB_ULPI_CLK;
  inout [7:0]USB_ULPI_DATA;
  input USB_ULPI_DIR;
  input USB_ULPI_NXT;
  output USB_ULPI_STP;
  output board_clock_locked;
  output board_core_clk;
  output [7:0]board_core_log_byte;
  output board_core_log_valid;
  output [7:0]board_mcu_log_byte;
  output board_mcu_log_valid;
  output [0:0]board_reset_n;
  input [3:0]host_entropy_data;
  output host_entropy_req;
  input host_entropy_valid;
  input [14:0]jtag_in;
  output [14:0]jtag_out;
  (* X_INTERFACE_INFO = "xilinx.com:signal:clock:1.0 CLK.REF_CLOCK_156P25MHZ_CLK_N CLK" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME CLK.REF_CLOCK_156P25MHZ_CLK_N, CLK_DOMAIN caliptra_htg940_bd_ref_clock_156p25mhz_clk_n, FREQ_HZ 156250000, FREQ_TOLERANCE_HZ 0, INSERT_VIP 0, PHASE 0.0" *) input ref_clock_156p25mhz_clk_n;
  (* X_INTERFACE_INFO = "xilinx.com:signal:clock:1.0 CLK.REF_CLOCK_156P25MHZ_CLK_P CLK" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME CLK.REF_CLOCK_156P25MHZ_CLK_P, CLK_DOMAIN caliptra_htg940_bd_ref_clock_156p25mhz_clk_p, FREQ_HZ 156250000, FREQ_TOLERANCE_HZ 0, INSERT_VIP 0, PHASE 0.0" *) input ref_clock_156p25mhz_clk_p;
  (* X_INTERFACE_INFO = "xilinx.com:signal:reset:1.0 RST.RESET_N RST" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME RST.RESET_N, INSERT_VIP 0, POLARITY ACTIVE_LOW" *) input reset_n;
  (* X_INTERFACE_INFO = "xilinx.com:signal:reset:1.0 RST.SUBSYSTEM_RESET_N RST" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME RST.SUBSYSTEM_RESET_N, INSERT_VIP 0, POLARITY ACTIVE_LOW" *) input subsystem_reset_n;

  wire EXT_SCL;
  wire EXT_SDA;
  wire EXT_SDA_EN;
  wire EXT_SDA_IN;
  wire EXT_SDA_UP;
  wire [31:0]M_AXI_USB_BRIDGE_ARADDR;
  wire [1:0]M_AXI_USB_BRIDGE_ARBURST;
  wire [3:0]M_AXI_USB_BRIDGE_ARCACHE;
  wire [2:0]M_AXI_USB_BRIDGE_ARID;
  wire [7:0]M_AXI_USB_BRIDGE_ARLEN;
  wire [0:0]M_AXI_USB_BRIDGE_ARLOCK;
  wire [2:0]M_AXI_USB_BRIDGE_ARPROT;
  wire [3:0]M_AXI_USB_BRIDGE_ARQOS;
  wire M_AXI_USB_BRIDGE_ARREADY;
  wire [2:0]M_AXI_USB_BRIDGE_ARSIZE;
  wire [145:0]M_AXI_USB_BRIDGE_ARUSER;
  wire M_AXI_USB_BRIDGE_ARVALID;
  wire [31:0]M_AXI_USB_BRIDGE_AWADDR;
  wire [1:0]M_AXI_USB_BRIDGE_AWBURST;
  wire [3:0]M_AXI_USB_BRIDGE_AWCACHE;
  wire [2:0]M_AXI_USB_BRIDGE_AWID;
  wire [7:0]M_AXI_USB_BRIDGE_AWLEN;
  wire [0:0]M_AXI_USB_BRIDGE_AWLOCK;
  wire [2:0]M_AXI_USB_BRIDGE_AWPROT;
  wire [3:0]M_AXI_USB_BRIDGE_AWQOS;
  wire M_AXI_USB_BRIDGE_AWREADY;
  wire [2:0]M_AXI_USB_BRIDGE_AWSIZE;
  wire [145:0]M_AXI_USB_BRIDGE_AWUSER;
  wire M_AXI_USB_BRIDGE_AWVALID;
  wire [2:0]M_AXI_USB_BRIDGE_BID;
  wire M_AXI_USB_BRIDGE_BREADY;
  wire [1:0]M_AXI_USB_BRIDGE_BRESP;
  wire [113:0]M_AXI_USB_BRIDGE_BUSER;
  wire M_AXI_USB_BRIDGE_BVALID;
  wire [63:0]M_AXI_USB_BRIDGE_RDATA;
  wire [2:0]M_AXI_USB_BRIDGE_RID;
  wire M_AXI_USB_BRIDGE_RLAST;
  wire M_AXI_USB_BRIDGE_RREADY;
  wire [1:0]M_AXI_USB_BRIDGE_RRESP;
  wire [13:0]M_AXI_USB_BRIDGE_RUSER;
  wire M_AXI_USB_BRIDGE_RVALID;
  wire [63:0]M_AXI_USB_BRIDGE_WDATA;
  wire M_AXI_USB_BRIDGE_WLAST;
  wire M_AXI_USB_BRIDGE_WREADY;
  wire [7:0]M_AXI_USB_BRIDGE_WSTRB;
  wire [13:0]M_AXI_USB_BRIDGE_WUSER;
  wire M_AXI_USB_BRIDGE_WVALID;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [31:0]S_AXI_CALIPTRA_ARADDR;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [1:0]S_AXI_CALIPTRA_ARBURST;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [7:0]S_AXI_CALIPTRA_ARLEN;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [0:0]S_AXI_CALIPTRA_ARLOCK;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire S_AXI_CALIPTRA_ARREADY;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [2:0]S_AXI_CALIPTRA_ARSIZE;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [31:0]S_AXI_CALIPTRA_ARUSER;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire S_AXI_CALIPTRA_ARVALID;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [31:0]S_AXI_CALIPTRA_AWADDR;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [1:0]S_AXI_CALIPTRA_AWBURST;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [7:0]S_AXI_CALIPTRA_AWLEN;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [0:0]S_AXI_CALIPTRA_AWLOCK;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire S_AXI_CALIPTRA_AWREADY;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [2:0]S_AXI_CALIPTRA_AWSIZE;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [31:0]S_AXI_CALIPTRA_AWUSER;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire S_AXI_CALIPTRA_AWVALID;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire S_AXI_CALIPTRA_BREADY;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [1:0]S_AXI_CALIPTRA_BRESP;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire S_AXI_CALIPTRA_BVALID;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [31:0]S_AXI_CALIPTRA_RDATA;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire S_AXI_CALIPTRA_RLAST;
  wire [16:0]S_AXI_CALIPTRA_ROM_ARADDR;
  wire [1:0]S_AXI_CALIPTRA_ROM_ARBURST;
  wire [3:0]S_AXI_CALIPTRA_ROM_ARCACHE;
  wire [7:0]S_AXI_CALIPTRA_ROM_ARLEN;
  wire [0:0]S_AXI_CALIPTRA_ROM_ARLOCK;
  wire [2:0]S_AXI_CALIPTRA_ROM_ARPROT;
  wire S_AXI_CALIPTRA_ROM_ARREADY;
  wire [2:0]S_AXI_CALIPTRA_ROM_ARSIZE;
  wire S_AXI_CALIPTRA_ROM_ARVALID;
  wire [16:0]S_AXI_CALIPTRA_ROM_AWADDR;
  wire [1:0]S_AXI_CALIPTRA_ROM_AWBURST;
  wire [3:0]S_AXI_CALIPTRA_ROM_AWCACHE;
  wire [7:0]S_AXI_CALIPTRA_ROM_AWLEN;
  wire [0:0]S_AXI_CALIPTRA_ROM_AWLOCK;
  wire [2:0]S_AXI_CALIPTRA_ROM_AWPROT;
  wire S_AXI_CALIPTRA_ROM_AWREADY;
  wire [2:0]S_AXI_CALIPTRA_ROM_AWSIZE;
  wire S_AXI_CALIPTRA_ROM_AWVALID;
  wire S_AXI_CALIPTRA_ROM_BREADY;
  wire [1:0]S_AXI_CALIPTRA_ROM_BRESP;
  wire S_AXI_CALIPTRA_ROM_BVALID;
  wire [31:0]S_AXI_CALIPTRA_ROM_RDATA;
  wire S_AXI_CALIPTRA_ROM_RLAST;
  wire S_AXI_CALIPTRA_ROM_RREADY;
  wire [1:0]S_AXI_CALIPTRA_ROM_RRESP;
  wire S_AXI_CALIPTRA_ROM_RVALID;
  wire [31:0]S_AXI_CALIPTRA_ROM_WDATA;
  wire S_AXI_CALIPTRA_ROM_WLAST;
  wire S_AXI_CALIPTRA_ROM_WREADY;
  wire [3:0]S_AXI_CALIPTRA_ROM_WSTRB;
  wire S_AXI_CALIPTRA_ROM_WVALID;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire S_AXI_CALIPTRA_RREADY;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [1:0]S_AXI_CALIPTRA_RRESP;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire S_AXI_CALIPTRA_RVALID;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [31:0]S_AXI_CALIPTRA_WDATA;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire S_AXI_CALIPTRA_WLAST;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire S_AXI_CALIPTRA_WREADY;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [3:0]S_AXI_CALIPTRA_WSTRB;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire S_AXI_CALIPTRA_WVALID;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [20:0]S_AXI_FIRMWARE_FLASH_ARADDR;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [1:0]S_AXI_FIRMWARE_FLASH_ARBURST;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [3:0]S_AXI_FIRMWARE_FLASH_ARCACHE;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [7:0]S_AXI_FIRMWARE_FLASH_ARLEN;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [0:0]S_AXI_FIRMWARE_FLASH_ARLOCK;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [2:0]S_AXI_FIRMWARE_FLASH_ARPROT;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire S_AXI_FIRMWARE_FLASH_ARREADY;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [2:0]S_AXI_FIRMWARE_FLASH_ARSIZE;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire S_AXI_FIRMWARE_FLASH_ARVALID;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [20:0]S_AXI_FIRMWARE_FLASH_AWADDR;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [1:0]S_AXI_FIRMWARE_FLASH_AWBURST;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [3:0]S_AXI_FIRMWARE_FLASH_AWCACHE;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [7:0]S_AXI_FIRMWARE_FLASH_AWLEN;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [0:0]S_AXI_FIRMWARE_FLASH_AWLOCK;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [2:0]S_AXI_FIRMWARE_FLASH_AWPROT;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire S_AXI_FIRMWARE_FLASH_AWREADY;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [2:0]S_AXI_FIRMWARE_FLASH_AWSIZE;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire S_AXI_FIRMWARE_FLASH_AWVALID;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire S_AXI_FIRMWARE_FLASH_BREADY;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [1:0]S_AXI_FIRMWARE_FLASH_BRESP;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire S_AXI_FIRMWARE_FLASH_BVALID;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [63:0]S_AXI_FIRMWARE_FLASH_RDATA;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire S_AXI_FIRMWARE_FLASH_RLAST;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire S_AXI_FIRMWARE_FLASH_RREADY;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [1:0]S_AXI_FIRMWARE_FLASH_RRESP;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire S_AXI_FIRMWARE_FLASH_RVALID;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [63:0]S_AXI_FIRMWARE_FLASH_WDATA;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire S_AXI_FIRMWARE_FLASH_WLAST;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire S_AXI_FIRMWARE_FLASH_WREADY;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [7:0]S_AXI_FIRMWARE_FLASH_WSTRB;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire S_AXI_FIRMWARE_FLASH_WVALID;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [31:0]S_AXI_I3C_ARADDR;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [1:0]S_AXI_I3C_ARBURST;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [7:0]S_AXI_I3C_ARLEN;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [0:0]S_AXI_I3C_ARLOCK;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [2:0]S_AXI_I3C_ARPROT;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire S_AXI_I3C_ARREADY;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [2:0]S_AXI_I3C_ARSIZE;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [31:0]S_AXI_I3C_ARUSER;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire S_AXI_I3C_ARVALID;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [31:0]S_AXI_I3C_AWADDR;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [1:0]S_AXI_I3C_AWBURST;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [7:0]S_AXI_I3C_AWLEN;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [0:0]S_AXI_I3C_AWLOCK;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [2:0]S_AXI_I3C_AWPROT;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire S_AXI_I3C_AWREADY;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [2:0]S_AXI_I3C_AWSIZE;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [31:0]S_AXI_I3C_AWUSER;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire S_AXI_I3C_AWVALID;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire S_AXI_I3C_BREADY;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [1:0]S_AXI_I3C_BRESP;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire S_AXI_I3C_BVALID;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [31:0]S_AXI_I3C_RDATA;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire S_AXI_I3C_RLAST;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire S_AXI_I3C_RREADY;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [1:0]S_AXI_I3C_RRESP;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire S_AXI_I3C_RVALID;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [31:0]S_AXI_I3C_SPARE_ARADDR;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [1:0]S_AXI_I3C_SPARE_ARBURST;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [7:0]S_AXI_I3C_SPARE_ARLEN;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [0:0]S_AXI_I3C_SPARE_ARLOCK;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire S_AXI_I3C_SPARE_ARREADY;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [2:0]S_AXI_I3C_SPARE_ARSIZE;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [31:0]S_AXI_I3C_SPARE_ARUSER;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire S_AXI_I3C_SPARE_ARVALID;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [31:0]S_AXI_I3C_SPARE_AWADDR;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [1:0]S_AXI_I3C_SPARE_AWBURST;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [7:0]S_AXI_I3C_SPARE_AWLEN;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [0:0]S_AXI_I3C_SPARE_AWLOCK;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire S_AXI_I3C_SPARE_AWREADY;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [2:0]S_AXI_I3C_SPARE_AWSIZE;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [31:0]S_AXI_I3C_SPARE_AWUSER;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire S_AXI_I3C_SPARE_AWVALID;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire S_AXI_I3C_SPARE_BREADY;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [1:0]S_AXI_I3C_SPARE_BRESP;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire S_AXI_I3C_SPARE_BVALID;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [31:0]S_AXI_I3C_SPARE_RDATA;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire S_AXI_I3C_SPARE_RLAST;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire S_AXI_I3C_SPARE_RREADY;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [1:0]S_AXI_I3C_SPARE_RRESP;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire S_AXI_I3C_SPARE_RVALID;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [31:0]S_AXI_I3C_SPARE_WDATA;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire S_AXI_I3C_SPARE_WLAST;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire S_AXI_I3C_SPARE_WREADY;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [3:0]S_AXI_I3C_SPARE_WSTRB;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire S_AXI_I3C_SPARE_WVALID;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [31:0]S_AXI_I3C_WDATA;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire S_AXI_I3C_WLAST;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire S_AXI_I3C_WREADY;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [3:0]S_AXI_I3C_WSTRB;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire S_AXI_I3C_WVALID;
  wire [31:0]S_AXI_LCC_ARADDR;
  wire [1:0]S_AXI_LCC_ARBURST;
  wire [7:0]S_AXI_LCC_ARLEN;
  wire [0:0]S_AXI_LCC_ARLOCK;
  wire [2:0]S_AXI_LCC_ARPROT;
  wire S_AXI_LCC_ARREADY;
  wire [2:0]S_AXI_LCC_ARSIZE;
  wire [31:0]S_AXI_LCC_ARUSER;
  wire S_AXI_LCC_ARVALID;
  wire [31:0]S_AXI_LCC_AWADDR;
  wire [1:0]S_AXI_LCC_AWBURST;
  wire [7:0]S_AXI_LCC_AWLEN;
  wire [0:0]S_AXI_LCC_AWLOCK;
  wire [2:0]S_AXI_LCC_AWPROT;
  wire S_AXI_LCC_AWREADY;
  wire [2:0]S_AXI_LCC_AWSIZE;
  wire [31:0]S_AXI_LCC_AWUSER;
  wire S_AXI_LCC_AWVALID;
  wire S_AXI_LCC_BREADY;
  wire [1:0]S_AXI_LCC_BRESP;
  wire S_AXI_LCC_BVALID;
  wire [31:0]S_AXI_LCC_RDATA;
  wire S_AXI_LCC_RLAST;
  wire S_AXI_LCC_RREADY;
  wire [1:0]S_AXI_LCC_RRESP;
  wire S_AXI_LCC_RVALID;
  wire [31:0]S_AXI_LCC_WDATA;
  wire S_AXI_LCC_WLAST;
  wire S_AXI_LCC_WREADY;
  wire [3:0]S_AXI_LCC_WSTRB;
  wire S_AXI_LCC_WVALID;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [31:0]S_AXI_MCI_ARADDR;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [1:0]S_AXI_MCI_ARBURST;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [7:0]S_AXI_MCI_ARLEN;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [0:0]S_AXI_MCI_ARLOCK;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire S_AXI_MCI_ARREADY;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [2:0]S_AXI_MCI_ARSIZE;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [31:0]S_AXI_MCI_ARUSER;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire S_AXI_MCI_ARVALID;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [31:0]S_AXI_MCI_AWADDR;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [1:0]S_AXI_MCI_AWBURST;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [7:0]S_AXI_MCI_AWLEN;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [0:0]S_AXI_MCI_AWLOCK;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire S_AXI_MCI_AWREADY;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [2:0]S_AXI_MCI_AWSIZE;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [31:0]S_AXI_MCI_AWUSER;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire S_AXI_MCI_AWVALID;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire S_AXI_MCI_BREADY;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [1:0]S_AXI_MCI_BRESP;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire S_AXI_MCI_BVALID;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [31:0]S_AXI_MCI_RDATA;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire S_AXI_MCI_RLAST;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire S_AXI_MCI_RREADY;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [1:0]S_AXI_MCI_RRESP;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire S_AXI_MCI_RVALID;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [31:0]S_AXI_MCI_WDATA;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire S_AXI_MCI_WLAST;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire S_AXI_MCI_WREADY;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [3:0]S_AXI_MCI_WSTRB;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire S_AXI_MCI_WVALID;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [31:0]S_AXI_MCU_ROM_ARADDR;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [1:0]S_AXI_MCU_ROM_ARBURST;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [7:0]S_AXI_MCU_ROM_ARLEN;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [0:0]S_AXI_MCU_ROM_ARLOCK;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire S_AXI_MCU_ROM_ARREADY;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [2:0]S_AXI_MCU_ROM_ARSIZE;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [31:0]S_AXI_MCU_ROM_ARUSER;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire S_AXI_MCU_ROM_ARVALID;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [31:0]S_AXI_MCU_ROM_AWADDR;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [1:0]S_AXI_MCU_ROM_AWBURST;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [7:0]S_AXI_MCU_ROM_AWLEN;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [0:0]S_AXI_MCU_ROM_AWLOCK;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire S_AXI_MCU_ROM_AWREADY;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [2:0]S_AXI_MCU_ROM_AWSIZE;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [31:0]S_AXI_MCU_ROM_AWUSER;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire S_AXI_MCU_ROM_AWVALID;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire S_AXI_MCU_ROM_BREADY;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [1:0]S_AXI_MCU_ROM_BRESP;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire S_AXI_MCU_ROM_BVALID;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [63:0]S_AXI_MCU_ROM_RDATA;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire S_AXI_MCU_ROM_RLAST;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire S_AXI_MCU_ROM_RREADY;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [1:0]S_AXI_MCU_ROM_RRESP;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire S_AXI_MCU_ROM_RVALID;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [63:0]S_AXI_MCU_ROM_WDATA;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire S_AXI_MCU_ROM_WLAST;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire S_AXI_MCU_ROM_WREADY;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [7:0]S_AXI_MCU_ROM_WSTRB;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire S_AXI_MCU_ROM_WVALID;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [31:0]S_AXI_OTP_ARADDR;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [1:0]S_AXI_OTP_ARBURST;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [7:0]S_AXI_OTP_ARLEN;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [0:0]S_AXI_OTP_ARLOCK;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [2:0]S_AXI_OTP_ARPROT;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire S_AXI_OTP_ARREADY;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [2:0]S_AXI_OTP_ARSIZE;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [31:0]S_AXI_OTP_ARUSER;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire S_AXI_OTP_ARVALID;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [31:0]S_AXI_OTP_AWADDR;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [1:0]S_AXI_OTP_AWBURST;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [7:0]S_AXI_OTP_AWLEN;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [0:0]S_AXI_OTP_AWLOCK;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [2:0]S_AXI_OTP_AWPROT;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire S_AXI_OTP_AWREADY;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [2:0]S_AXI_OTP_AWSIZE;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [31:0]S_AXI_OTP_AWUSER;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire S_AXI_OTP_AWVALID;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire S_AXI_OTP_BREADY;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [1:0]S_AXI_OTP_BRESP;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire S_AXI_OTP_BVALID;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [15:0]S_AXI_OTP_RAM_ARADDR;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [1:0]S_AXI_OTP_RAM_ARBURST;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [3:0]S_AXI_OTP_RAM_ARCACHE;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [7:0]S_AXI_OTP_RAM_ARLEN;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [0:0]S_AXI_OTP_RAM_ARLOCK;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [2:0]S_AXI_OTP_RAM_ARPROT;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire S_AXI_OTP_RAM_ARREADY;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [2:0]S_AXI_OTP_RAM_ARSIZE;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire S_AXI_OTP_RAM_ARVALID;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [15:0]S_AXI_OTP_RAM_AWADDR;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [1:0]S_AXI_OTP_RAM_AWBURST;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [3:0]S_AXI_OTP_RAM_AWCACHE;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [7:0]S_AXI_OTP_RAM_AWLEN;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [0:0]S_AXI_OTP_RAM_AWLOCK;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [2:0]S_AXI_OTP_RAM_AWPROT;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire S_AXI_OTP_RAM_AWREADY;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [2:0]S_AXI_OTP_RAM_AWSIZE;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire S_AXI_OTP_RAM_AWVALID;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire S_AXI_OTP_RAM_BREADY;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [1:0]S_AXI_OTP_RAM_BRESP;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire S_AXI_OTP_RAM_BVALID;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [31:0]S_AXI_OTP_RAM_RDATA;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire S_AXI_OTP_RAM_RLAST;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire S_AXI_OTP_RAM_RREADY;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [1:0]S_AXI_OTP_RAM_RRESP;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire S_AXI_OTP_RAM_RVALID;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [31:0]S_AXI_OTP_RAM_WDATA;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire S_AXI_OTP_RAM_WLAST;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire S_AXI_OTP_RAM_WREADY;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [3:0]S_AXI_OTP_RAM_WSTRB;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire S_AXI_OTP_RAM_WVALID;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [31:0]S_AXI_OTP_RDATA;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire S_AXI_OTP_RLAST;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire S_AXI_OTP_RREADY;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [1:0]S_AXI_OTP_RRESP;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire S_AXI_OTP_RVALID;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [31:0]S_AXI_OTP_WDATA;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire S_AXI_OTP_WLAST;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire S_AXI_OTP_WREADY;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [3:0]S_AXI_OTP_WSTRB;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire S_AXI_OTP_WVALID;
  wire [16:0]S_AXI_SS_ROM_ARADDR;
  wire [1:0]S_AXI_SS_ROM_ARBURST;
  wire [3:0]S_AXI_SS_ROM_ARCACHE;
  wire [7:0]S_AXI_SS_ROM_ARLEN;
  wire [0:0]S_AXI_SS_ROM_ARLOCK;
  wire [2:0]S_AXI_SS_ROM_ARPROT;
  wire S_AXI_SS_ROM_ARREADY;
  wire [2:0]S_AXI_SS_ROM_ARSIZE;
  wire S_AXI_SS_ROM_ARVALID;
  wire [16:0]S_AXI_SS_ROM_AWADDR;
  wire [1:0]S_AXI_SS_ROM_AWBURST;
  wire [3:0]S_AXI_SS_ROM_AWCACHE;
  wire [7:0]S_AXI_SS_ROM_AWLEN;
  wire [0:0]S_AXI_SS_ROM_AWLOCK;
  wire [2:0]S_AXI_SS_ROM_AWPROT;
  wire S_AXI_SS_ROM_AWREADY;
  wire [2:0]S_AXI_SS_ROM_AWSIZE;
  wire S_AXI_SS_ROM_AWVALID;
  wire S_AXI_SS_ROM_BREADY;
  wire [1:0]S_AXI_SS_ROM_BRESP;
  wire S_AXI_SS_ROM_BVALID;
  wire [31:0]S_AXI_SS_ROM_RDATA;
  wire S_AXI_SS_ROM_RLAST;
  wire S_AXI_SS_ROM_RREADY;
  wire [1:0]S_AXI_SS_ROM_RRESP;
  wire S_AXI_SS_ROM_RVALID;
  wire [31:0]S_AXI_SS_ROM_WDATA;
  wire S_AXI_SS_ROM_WLAST;
  wire S_AXI_SS_ROM_WREADY;
  wire [3:0]S_AXI_SS_ROM_WSTRB;
  wire S_AXI_SS_ROM_WVALID;
  wire [17:0]S_AXI_STAGING_SRAM_ARADDR;
  wire [1:0]S_AXI_STAGING_SRAM_ARBURST;
  wire [3:0]S_AXI_STAGING_SRAM_ARCACHE;
  wire [7:0]S_AXI_STAGING_SRAM_ARLEN;
  wire [0:0]S_AXI_STAGING_SRAM_ARLOCK;
  wire [2:0]S_AXI_STAGING_SRAM_ARPROT;
  wire S_AXI_STAGING_SRAM_ARREADY;
  wire [2:0]S_AXI_STAGING_SRAM_ARSIZE;
  wire S_AXI_STAGING_SRAM_ARVALID;
  wire [17:0]S_AXI_STAGING_SRAM_AWADDR;
  wire [1:0]S_AXI_STAGING_SRAM_AWBURST;
  wire [3:0]S_AXI_STAGING_SRAM_AWCACHE;
  wire [7:0]S_AXI_STAGING_SRAM_AWLEN;
  wire [0:0]S_AXI_STAGING_SRAM_AWLOCK;
  wire [2:0]S_AXI_STAGING_SRAM_AWPROT;
  wire S_AXI_STAGING_SRAM_AWREADY;
  wire [2:0]S_AXI_STAGING_SRAM_AWSIZE;
  wire S_AXI_STAGING_SRAM_AWVALID;
  wire S_AXI_STAGING_SRAM_BREADY;
  wire [1:0]S_AXI_STAGING_SRAM_BRESP;
  wire S_AXI_STAGING_SRAM_BVALID;
  wire [63:0]S_AXI_STAGING_SRAM_RDATA;
  wire S_AXI_STAGING_SRAM_RLAST;
  wire S_AXI_STAGING_SRAM_RREADY;
  wire [1:0]S_AXI_STAGING_SRAM_RRESP;
  wire S_AXI_STAGING_SRAM_RVALID;
  wire [63:0]S_AXI_STAGING_SRAM_WDATA;
  wire S_AXI_STAGING_SRAM_WLAST;
  wire S_AXI_STAGING_SRAM_WREADY;
  wire [7:0]S_AXI_STAGING_SRAM_WSTRB;
  wire S_AXI_STAGING_SRAM_WVALID;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [31:0]S_AXI_USB_DEV_ARADDR;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [1:0]S_AXI_USB_DEV_ARBURST;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [7:0]S_AXI_USB_DEV_ARLEN;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [0:0]S_AXI_USB_DEV_ARLOCK;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire S_AXI_USB_DEV_ARREADY;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [2:0]S_AXI_USB_DEV_ARSIZE;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [31:0]S_AXI_USB_DEV_ARUSER;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire S_AXI_USB_DEV_ARVALID;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [31:0]S_AXI_USB_DEV_AWADDR;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [1:0]S_AXI_USB_DEV_AWBURST;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [7:0]S_AXI_USB_DEV_AWLEN;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [0:0]S_AXI_USB_DEV_AWLOCK;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire S_AXI_USB_DEV_AWREADY;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [2:0]S_AXI_USB_DEV_AWSIZE;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [31:0]S_AXI_USB_DEV_AWUSER;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire S_AXI_USB_DEV_AWVALID;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire S_AXI_USB_DEV_BREADY;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [1:0]S_AXI_USB_DEV_BRESP;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire S_AXI_USB_DEV_BVALID;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [31:0]S_AXI_USB_DEV_RDATA;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire S_AXI_USB_DEV_RLAST;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire S_AXI_USB_DEV_RREADY;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [1:0]S_AXI_USB_DEV_RRESP;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire S_AXI_USB_DEV_RVALID;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [31:0]S_AXI_USB_DEV_WDATA;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire S_AXI_USB_DEV_WLAST;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire S_AXI_USB_DEV_WREADY;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [3:0]S_AXI_USB_DEV_WSTRB;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire S_AXI_USB_DEV_WVALID;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [31:0]S_AXI_USB_DMA_ARADDR;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [1:0]S_AXI_USB_DMA_ARBURST;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [7:0]S_AXI_USB_DMA_ARLEN;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [0:0]S_AXI_USB_DMA_ARLOCK;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire S_AXI_USB_DMA_ARREADY;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [2:0]S_AXI_USB_DMA_ARSIZE;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [31:0]S_AXI_USB_DMA_ARUSER;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire S_AXI_USB_DMA_ARVALID;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [31:0]S_AXI_USB_DMA_AWADDR;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [1:0]S_AXI_USB_DMA_AWBURST;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [7:0]S_AXI_USB_DMA_AWLEN;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [0:0]S_AXI_USB_DMA_AWLOCK;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire S_AXI_USB_DMA_AWREADY;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [2:0]S_AXI_USB_DMA_AWSIZE;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [31:0]S_AXI_USB_DMA_AWUSER;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire S_AXI_USB_DMA_AWVALID;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire S_AXI_USB_DMA_BREADY;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [1:0]S_AXI_USB_DMA_BRESP;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire S_AXI_USB_DMA_BVALID;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [31:0]S_AXI_USB_DMA_RDATA;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire S_AXI_USB_DMA_RLAST;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire S_AXI_USB_DMA_RREADY;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [1:0]S_AXI_USB_DMA_RRESP;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire S_AXI_USB_DMA_RVALID;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [31:0]S_AXI_USB_DMA_WDATA;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire S_AXI_USB_DMA_WLAST;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire S_AXI_USB_DMA_WREADY;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [3:0]S_AXI_USB_DMA_WSTRB;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire S_AXI_USB_DMA_WVALID;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [31:0]S_AXI_USB_HOST_ARADDR;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [1:0]S_AXI_USB_HOST_ARBURST;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [7:0]S_AXI_USB_HOST_ARLEN;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [0:0]S_AXI_USB_HOST_ARLOCK;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire S_AXI_USB_HOST_ARREADY;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [2:0]S_AXI_USB_HOST_ARSIZE;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [31:0]S_AXI_USB_HOST_ARUSER;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire S_AXI_USB_HOST_ARVALID;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [31:0]S_AXI_USB_HOST_AWADDR;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [1:0]S_AXI_USB_HOST_AWBURST;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [7:0]S_AXI_USB_HOST_AWLEN;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [0:0]S_AXI_USB_HOST_AWLOCK;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire S_AXI_USB_HOST_AWREADY;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [2:0]S_AXI_USB_HOST_AWSIZE;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [31:0]S_AXI_USB_HOST_AWUSER;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire S_AXI_USB_HOST_AWVALID;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire S_AXI_USB_HOST_BREADY;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [1:0]S_AXI_USB_HOST_BRESP;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire S_AXI_USB_HOST_BVALID;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [31:0]S_AXI_USB_HOST_RDATA;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire S_AXI_USB_HOST_RLAST;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire S_AXI_USB_HOST_RREADY;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [1:0]S_AXI_USB_HOST_RRESP;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire S_AXI_USB_HOST_RVALID;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [31:0]S_AXI_USB_HOST_WDATA;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire S_AXI_USB_HOST_WLAST;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire S_AXI_USB_HOST_WREADY;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire [3:0]S_AXI_USB_HOST_WSTRB;
  (* DEBUG = "true" *) (* MARK_DEBUG *) wire S_AXI_USB_HOST_WVALID;
  wire [31:0]S_AXI_WRAPPER_ARADDR;
  wire [2:0]S_AXI_WRAPPER_ARPROT;
  wire S_AXI_WRAPPER_ARREADY;
  wire S_AXI_WRAPPER_ARVALID;
  wire [31:0]S_AXI_WRAPPER_AWADDR;
  wire [2:0]S_AXI_WRAPPER_AWPROT;
  wire S_AXI_WRAPPER_AWREADY;
  wire S_AXI_WRAPPER_AWVALID;
  wire S_AXI_WRAPPER_BREADY;
  wire [1:0]S_AXI_WRAPPER_BRESP;
  wire S_AXI_WRAPPER_BVALID;
  wire [31:0]S_AXI_WRAPPER_RDATA;
  wire S_AXI_WRAPPER_RREADY;
  wire [1:0]S_AXI_WRAPPER_RRESP;
  wire S_AXI_WRAPPER_RVALID;
  wire [31:0]S_AXI_WRAPPER_WDATA;
  wire S_AXI_WRAPPER_WREADY;
  wire [3:0]S_AXI_WRAPPER_WSTRB;
  wire S_AXI_WRAPPER_WVALID;
  wire [5:0]S_AXI_XILINX_DMA_ARADDR;
  wire S_AXI_XILINX_DMA_ARREADY;
  wire S_AXI_XILINX_DMA_ARVALID;
  wire [5:0]S_AXI_XILINX_DMA_AWADDR;
  wire S_AXI_XILINX_DMA_AWREADY;
  wire S_AXI_XILINX_DMA_AWVALID;
  wire S_AXI_XILINX_DMA_BREADY;
  wire [1:0]S_AXI_XILINX_DMA_BRESP;
  wire S_AXI_XILINX_DMA_BVALID;
  wire [31:0]S_AXI_XILINX_DMA_RDATA;
  wire S_AXI_XILINX_DMA_RREADY;
  wire [1:0]S_AXI_XILINX_DMA_RRESP;
  wire S_AXI_XILINX_DMA_RVALID;
  wire [31:0]S_AXI_XILINX_DMA_WDATA;
  wire S_AXI_XILINX_DMA_WREADY;
  wire S_AXI_XILINX_DMA_WVALID;
  wire [31:0]S_AXI_XILINX_I3C_ARADDR;
  wire S_AXI_XILINX_I3C_ARREADY;
  wire S_AXI_XILINX_I3C_ARVALID;
  wire [31:0]S_AXI_XILINX_I3C_AWADDR;
  wire S_AXI_XILINX_I3C_AWREADY;
  wire S_AXI_XILINX_I3C_AWVALID;
  wire S_AXI_XILINX_I3C_BREADY;
  wire [1:0]S_AXI_XILINX_I3C_BRESP;
  wire S_AXI_XILINX_I3C_BVALID;
  wire [31:0]S_AXI_XILINX_I3C_RDATA;
  wire S_AXI_XILINX_I3C_RREADY;
  wire [1:0]S_AXI_XILINX_I3C_RRESP;
  wire S_AXI_XILINX_I3C_RVALID;
  wire [31:0]S_AXI_XILINX_I3C_WDATA;
  wire S_AXI_XILINX_I3C_WREADY;
  wire [3:0]S_AXI_XILINX_I3C_WSTRB;
  wire S_AXI_XILINX_I3C_WVALID;
  wire USB_ULPI_CLK;
  wire [7:0]USB_ULPI_DATA;
  wire USB_ULPI_DIR;
  wire USB_ULPI_NXT;
  wire USB_ULPI_STP;
  wire [0:0]aux_reset_const_0_dout;
  wire [31:0]axi_cdma_0_M_AXI_ARADDR;
  wire [1:0]axi_cdma_0_M_AXI_ARBURST;
  wire [3:0]axi_cdma_0_M_AXI_ARCACHE;
  wire [7:0]axi_cdma_0_M_AXI_ARLEN;
  wire [2:0]axi_cdma_0_M_AXI_ARPROT;
  wire axi_cdma_0_M_AXI_ARREADY;
  wire [2:0]axi_cdma_0_M_AXI_ARSIZE;
  wire axi_cdma_0_M_AXI_ARVALID;
  wire [31:0]axi_cdma_0_M_AXI_AWADDR;
  wire [1:0]axi_cdma_0_M_AXI_AWBURST;
  wire [3:0]axi_cdma_0_M_AXI_AWCACHE;
  wire [7:0]axi_cdma_0_M_AXI_AWLEN;
  wire [2:0]axi_cdma_0_M_AXI_AWPROT;
  wire axi_cdma_0_M_AXI_AWREADY;
  wire [2:0]axi_cdma_0_M_AXI_AWSIZE;
  wire axi_cdma_0_M_AXI_AWVALID;
  wire axi_cdma_0_M_AXI_BREADY;
  wire [1:0]axi_cdma_0_M_AXI_BRESP;
  wire axi_cdma_0_M_AXI_BVALID;
  wire [31:0]axi_cdma_0_M_AXI_RDATA;
  wire axi_cdma_0_M_AXI_RLAST;
  wire axi_cdma_0_M_AXI_RREADY;
  wire [1:0]axi_cdma_0_M_AXI_RRESP;
  wire axi_cdma_0_M_AXI_RVALID;
  wire [31:0]axi_cdma_0_M_AXI_WDATA;
  wire axi_cdma_0_M_AXI_WLAST;
  wire axi_cdma_0_M_AXI_WREADY;
  wire [3:0]axi_cdma_0_M_AXI_WSTRB;
  wire axi_cdma_0_M_AXI_WVALID;
  wire board_clock_locked;
  wire board_core_clk;
  wire [7:0]board_core_log_byte;
  wire board_core_log_valid;
  wire [7:0]board_mcu_log_byte;
  wire board_mcu_log_valid;
  wire [0:0]board_reset_n;
  wire [31:0]caliptra_package_top_0_M_AXI_CALIPTRA_ARADDR;
  wire [1:0]caliptra_package_top_0_M_AXI_CALIPTRA_ARBURST;
  wire [15:0]caliptra_package_top_0_M_AXI_CALIPTRA_ARID;
  wire [7:0]caliptra_package_top_0_M_AXI_CALIPTRA_ARLEN;
  wire caliptra_package_top_0_M_AXI_CALIPTRA_ARLOCK;
  wire caliptra_package_top_0_M_AXI_CALIPTRA_ARREADY;
  wire [2:0]caliptra_package_top_0_M_AXI_CALIPTRA_ARSIZE;
  wire [31:0]caliptra_package_top_0_M_AXI_CALIPTRA_ARUSER;
  wire caliptra_package_top_0_M_AXI_CALIPTRA_ARVALID;
  wire [31:0]caliptra_package_top_0_M_AXI_CALIPTRA_AWADDR;
  wire [1:0]caliptra_package_top_0_M_AXI_CALIPTRA_AWBURST;
  wire [15:0]caliptra_package_top_0_M_AXI_CALIPTRA_AWID;
  wire [7:0]caliptra_package_top_0_M_AXI_CALIPTRA_AWLEN;
  wire caliptra_package_top_0_M_AXI_CALIPTRA_AWLOCK;
  wire caliptra_package_top_0_M_AXI_CALIPTRA_AWREADY;
  wire [2:0]caliptra_package_top_0_M_AXI_CALIPTRA_AWSIZE;
  wire [31:0]caliptra_package_top_0_M_AXI_CALIPTRA_AWUSER;
  wire caliptra_package_top_0_M_AXI_CALIPTRA_AWVALID;
  wire [15:0]caliptra_package_top_0_M_AXI_CALIPTRA_BID;
  wire caliptra_package_top_0_M_AXI_CALIPTRA_BREADY;
  wire [1:0]caliptra_package_top_0_M_AXI_CALIPTRA_BRESP;
  wire caliptra_package_top_0_M_AXI_CALIPTRA_BVALID;
  wire [31:0]caliptra_package_top_0_M_AXI_CALIPTRA_RDATA;
  wire [15:0]caliptra_package_top_0_M_AXI_CALIPTRA_RID;
  wire caliptra_package_top_0_M_AXI_CALIPTRA_RLAST;
  wire caliptra_package_top_0_M_AXI_CALIPTRA_RREADY;
  wire [1:0]caliptra_package_top_0_M_AXI_CALIPTRA_RRESP;
  wire caliptra_package_top_0_M_AXI_CALIPTRA_RVALID;
  wire [31:0]caliptra_package_top_0_M_AXI_CALIPTRA_WDATA;
  wire caliptra_package_top_0_M_AXI_CALIPTRA_WLAST;
  wire caliptra_package_top_0_M_AXI_CALIPTRA_WREADY;
  wire [3:0]caliptra_package_top_0_M_AXI_CALIPTRA_WSTRB;
  wire caliptra_package_top_0_M_AXI_CALIPTRA_WVALID;
  wire [31:0]caliptra_package_top_0_M_AXI_MCU_IFU_ARADDR;
  wire [1:0]caliptra_package_top_0_M_AXI_MCU_IFU_ARBURST;
  wire [3:0]caliptra_package_top_0_M_AXI_MCU_IFU_ARCACHE;
  wire [18:0]caliptra_package_top_0_M_AXI_MCU_IFU_ARID;
  wire [7:0]caliptra_package_top_0_M_AXI_MCU_IFU_ARLEN;
  wire caliptra_package_top_0_M_AXI_MCU_IFU_ARLOCK;
  wire [2:0]caliptra_package_top_0_M_AXI_MCU_IFU_ARPROT;
  wire [3:0]caliptra_package_top_0_M_AXI_MCU_IFU_ARQOS;
  wire caliptra_package_top_0_M_AXI_MCU_IFU_ARREADY;
  wire [2:0]caliptra_package_top_0_M_AXI_MCU_IFU_ARSIZE;
  wire [31:0]caliptra_package_top_0_M_AXI_MCU_IFU_ARUSER;
  wire caliptra_package_top_0_M_AXI_MCU_IFU_ARVALID;
  wire [31:0]caliptra_package_top_0_M_AXI_MCU_IFU_AWADDR;
  wire [1:0]caliptra_package_top_0_M_AXI_MCU_IFU_AWBURST;
  wire [3:0]caliptra_package_top_0_M_AXI_MCU_IFU_AWCACHE;
  wire [18:0]caliptra_package_top_0_M_AXI_MCU_IFU_AWID;
  wire [7:0]caliptra_package_top_0_M_AXI_MCU_IFU_AWLEN;
  wire caliptra_package_top_0_M_AXI_MCU_IFU_AWLOCK;
  wire [2:0]caliptra_package_top_0_M_AXI_MCU_IFU_AWPROT;
  wire [3:0]caliptra_package_top_0_M_AXI_MCU_IFU_AWQOS;
  wire caliptra_package_top_0_M_AXI_MCU_IFU_AWREADY;
  wire [2:0]caliptra_package_top_0_M_AXI_MCU_IFU_AWSIZE;
  wire [31:0]caliptra_package_top_0_M_AXI_MCU_IFU_AWUSER;
  wire caliptra_package_top_0_M_AXI_MCU_IFU_AWVALID;
  wire [18:0]caliptra_package_top_0_M_AXI_MCU_IFU_BID;
  wire caliptra_package_top_0_M_AXI_MCU_IFU_BREADY;
  wire [1:0]caliptra_package_top_0_M_AXI_MCU_IFU_BRESP;
  wire caliptra_package_top_0_M_AXI_MCU_IFU_BVALID;
  wire [63:0]caliptra_package_top_0_M_AXI_MCU_IFU_RDATA;
  wire [18:0]caliptra_package_top_0_M_AXI_MCU_IFU_RID;
  wire caliptra_package_top_0_M_AXI_MCU_IFU_RLAST;
  wire caliptra_package_top_0_M_AXI_MCU_IFU_RREADY;
  wire [1:0]caliptra_package_top_0_M_AXI_MCU_IFU_RRESP;
  wire caliptra_package_top_0_M_AXI_MCU_IFU_RVALID;
  wire [63:0]caliptra_package_top_0_M_AXI_MCU_IFU_WDATA;
  wire caliptra_package_top_0_M_AXI_MCU_IFU_WLAST;
  wire caliptra_package_top_0_M_AXI_MCU_IFU_WREADY;
  wire [7:0]caliptra_package_top_0_M_AXI_MCU_IFU_WSTRB;
  wire caliptra_package_top_0_M_AXI_MCU_IFU_WVALID;
  wire [31:0]caliptra_package_top_0_M_AXI_MCU_LSU_ARADDR;
  wire [1:0]caliptra_package_top_0_M_AXI_MCU_LSU_ARBURST;
  wire [3:0]caliptra_package_top_0_M_AXI_MCU_LSU_ARCACHE;
  wire [18:0]caliptra_package_top_0_M_AXI_MCU_LSU_ARID;
  wire [7:0]caliptra_package_top_0_M_AXI_MCU_LSU_ARLEN;
  wire caliptra_package_top_0_M_AXI_MCU_LSU_ARLOCK;
  wire [2:0]caliptra_package_top_0_M_AXI_MCU_LSU_ARPROT;
  wire [3:0]caliptra_package_top_0_M_AXI_MCU_LSU_ARQOS;
  wire caliptra_package_top_0_M_AXI_MCU_LSU_ARREADY;
  wire [2:0]caliptra_package_top_0_M_AXI_MCU_LSU_ARSIZE;
  wire [31:0]caliptra_package_top_0_M_AXI_MCU_LSU_ARUSER;
  wire caliptra_package_top_0_M_AXI_MCU_LSU_ARVALID;
  wire [31:0]caliptra_package_top_0_M_AXI_MCU_LSU_AWADDR;
  wire [1:0]caliptra_package_top_0_M_AXI_MCU_LSU_AWBURST;
  wire [3:0]caliptra_package_top_0_M_AXI_MCU_LSU_AWCACHE;
  wire [18:0]caliptra_package_top_0_M_AXI_MCU_LSU_AWID;
  wire [7:0]caliptra_package_top_0_M_AXI_MCU_LSU_AWLEN;
  wire caliptra_package_top_0_M_AXI_MCU_LSU_AWLOCK;
  wire [2:0]caliptra_package_top_0_M_AXI_MCU_LSU_AWPROT;
  wire [3:0]caliptra_package_top_0_M_AXI_MCU_LSU_AWQOS;
  wire caliptra_package_top_0_M_AXI_MCU_LSU_AWREADY;
  wire [2:0]caliptra_package_top_0_M_AXI_MCU_LSU_AWSIZE;
  wire [31:0]caliptra_package_top_0_M_AXI_MCU_LSU_AWUSER;
  wire caliptra_package_top_0_M_AXI_MCU_LSU_AWVALID;
  wire [18:0]caliptra_package_top_0_M_AXI_MCU_LSU_BID;
  wire caliptra_package_top_0_M_AXI_MCU_LSU_BREADY;
  wire [1:0]caliptra_package_top_0_M_AXI_MCU_LSU_BRESP;
  wire caliptra_package_top_0_M_AXI_MCU_LSU_BVALID;
  wire [63:0]caliptra_package_top_0_M_AXI_MCU_LSU_RDATA;
  wire [18:0]caliptra_package_top_0_M_AXI_MCU_LSU_RID;
  wire caliptra_package_top_0_M_AXI_MCU_LSU_RLAST;
  wire caliptra_package_top_0_M_AXI_MCU_LSU_RREADY;
  wire [1:0]caliptra_package_top_0_M_AXI_MCU_LSU_RRESP;
  wire caliptra_package_top_0_M_AXI_MCU_LSU_RVALID;
  wire [63:0]caliptra_package_top_0_M_AXI_MCU_LSU_WDATA;
  wire caliptra_package_top_0_M_AXI_MCU_LSU_WLAST;
  wire caliptra_package_top_0_M_AXI_MCU_LSU_WREADY;
  wire [7:0]caliptra_package_top_0_M_AXI_MCU_LSU_WSTRB;
  wire caliptra_package_top_0_M_AXI_MCU_LSU_WVALID;
  wire [31:0]caliptra_package_top_0_M_AXI_MCU_SB_ARADDR;
  wire [1:0]caliptra_package_top_0_M_AXI_MCU_SB_ARBURST;
  wire [3:0]caliptra_package_top_0_M_AXI_MCU_SB_ARCACHE;
  wire [18:0]caliptra_package_top_0_M_AXI_MCU_SB_ARID;
  wire [7:0]caliptra_package_top_0_M_AXI_MCU_SB_ARLEN;
  wire caliptra_package_top_0_M_AXI_MCU_SB_ARLOCK;
  wire [2:0]caliptra_package_top_0_M_AXI_MCU_SB_ARPROT;
  wire [3:0]caliptra_package_top_0_M_AXI_MCU_SB_ARQOS;
  wire caliptra_package_top_0_M_AXI_MCU_SB_ARREADY;
  wire [2:0]caliptra_package_top_0_M_AXI_MCU_SB_ARSIZE;
  wire [31:0]caliptra_package_top_0_M_AXI_MCU_SB_ARUSER;
  wire caliptra_package_top_0_M_AXI_MCU_SB_ARVALID;
  wire [31:0]caliptra_package_top_0_M_AXI_MCU_SB_AWADDR;
  wire [1:0]caliptra_package_top_0_M_AXI_MCU_SB_AWBURST;
  wire [3:0]caliptra_package_top_0_M_AXI_MCU_SB_AWCACHE;
  wire [18:0]caliptra_package_top_0_M_AXI_MCU_SB_AWID;
  wire [7:0]caliptra_package_top_0_M_AXI_MCU_SB_AWLEN;
  wire caliptra_package_top_0_M_AXI_MCU_SB_AWLOCK;
  wire [2:0]caliptra_package_top_0_M_AXI_MCU_SB_AWPROT;
  wire [3:0]caliptra_package_top_0_M_AXI_MCU_SB_AWQOS;
  wire caliptra_package_top_0_M_AXI_MCU_SB_AWREADY;
  wire [2:0]caliptra_package_top_0_M_AXI_MCU_SB_AWSIZE;
  wire [31:0]caliptra_package_top_0_M_AXI_MCU_SB_AWUSER;
  wire caliptra_package_top_0_M_AXI_MCU_SB_AWVALID;
  wire [18:0]caliptra_package_top_0_M_AXI_MCU_SB_BID;
  wire caliptra_package_top_0_M_AXI_MCU_SB_BREADY;
  wire [1:0]caliptra_package_top_0_M_AXI_MCU_SB_BRESP;
  wire caliptra_package_top_0_M_AXI_MCU_SB_BVALID;
  wire [63:0]caliptra_package_top_0_M_AXI_MCU_SB_RDATA;
  wire [18:0]caliptra_package_top_0_M_AXI_MCU_SB_RID;
  wire caliptra_package_top_0_M_AXI_MCU_SB_RLAST;
  wire caliptra_package_top_0_M_AXI_MCU_SB_RREADY;
  wire [1:0]caliptra_package_top_0_M_AXI_MCU_SB_RRESP;
  wire caliptra_package_top_0_M_AXI_MCU_SB_RVALID;
  wire [63:0]caliptra_package_top_0_M_AXI_MCU_SB_WDATA;
  wire caliptra_package_top_0_M_AXI_MCU_SB_WLAST;
  wire caliptra_package_top_0_M_AXI_MCU_SB_WREADY;
  wire [7:0]caliptra_package_top_0_M_AXI_MCU_SB_WSTRB;
  wire caliptra_package_top_0_M_AXI_MCU_SB_WVALID;
  wire caliptra_package_top_0_xilinx_i3c_aresetn;
  wire caliptra_package_top_0_xilinx_scl;
  wire caliptra_package_top_0_xilinx_sda;
  wire [16:0]cptra_rom_backdoor_bram_0_BRAM_PORTA_ADDR;
  wire cptra_rom_backdoor_bram_0_BRAM_PORTA_CLK;
  wire [31:0]cptra_rom_backdoor_bram_0_BRAM_PORTA_DIN;
  wire [31:0]cptra_rom_backdoor_bram_0_BRAM_PORTA_DOUT;
  wire cptra_rom_backdoor_bram_0_BRAM_PORTA_EN;
  wire cptra_rom_backdoor_bram_0_BRAM_PORTA_RST;
  wire [3:0]cptra_rom_backdoor_bram_0_BRAM_PORTA_WE;
  wire [17:0]firmware_byte_to_word_0_Dout;
  wire [20:0]firmware_flash_bram_ctrl_0_bram_addr_a;
  wire firmware_flash_bram_ctrl_0_bram_clk_a;
  wire firmware_flash_bram_ctrl_0_bram_en_a;
  wire [7:0]firmware_flash_bram_ctrl_0_bram_we_a;
  wire [63:0]firmware_flash_bram_ctrl_0_bram_wrdata_a;
  wire [63:0]firmware_flash_mem_0_douta;
  wire [3:0]host_entropy_data;
  wire host_entropy_req;
  wire host_entropy_valid;
  wire htg940_clocks_clk_out2;
  wire [14:0]jtag_in;
  wire [14:0]jtag_out;
  wire [16:0]mcu_rom_backdoor_bram_0_BRAM_PORTA_ADDR;
  wire mcu_rom_backdoor_bram_0_BRAM_PORTA_CLK;
  wire [31:0]mcu_rom_backdoor_bram_0_BRAM_PORTA_DIN;
  wire [31:0]mcu_rom_backdoor_bram_0_BRAM_PORTA_DOUT;
  wire mcu_rom_backdoor_bram_0_BRAM_PORTA_EN;
  wire mcu_rom_backdoor_bram_0_BRAM_PORTA_RST;
  wire [3:0]mcu_rom_backdoor_bram_0_BRAM_PORTA_WE;
  wire [15:0]otp_ram_bram_ctrl_0_BRAM_PORTA_ADDR;
  wire otp_ram_bram_ctrl_0_BRAM_PORTA_CLK;
  wire [31:0]otp_ram_bram_ctrl_0_BRAM_PORTA_DIN;
  wire [31:0]otp_ram_bram_ctrl_0_BRAM_PORTA_DOUT;
  wire otp_ram_bram_ctrl_0_BRAM_PORTA_EN;
  wire otp_ram_bram_ctrl_0_BRAM_PORTA_RST;
  wire [3:0]otp_ram_bram_ctrl_0_BRAM_PORTA_WE;
  wire ref_clock_156p25mhz_clk_n;
  wire ref_clock_156p25mhz_clk_p;
  wire reset_n;
  wire [17:0]staging_sram_bram_ctrl_0_BRAM_PORTA_ADDR;
  wire staging_sram_bram_ctrl_0_BRAM_PORTA_CLK;
  wire [63:0]staging_sram_bram_ctrl_0_BRAM_PORTA_DIN;
  wire [63:0]staging_sram_bram_ctrl_0_BRAM_PORTA_DOUT;
  wire staging_sram_bram_ctrl_0_BRAM_PORTA_EN;
  wire staging_sram_bram_ctrl_0_BRAM_PORTA_RST;
  wire [7:0]staging_sram_bram_ctrl_0_BRAM_PORTA_WE;
  wire subsystem_reset_n;
  wire xilinx_i3c_0_scl_o;
  wire xilinx_i3c_0_scl_pullup_en;
  wire xilinx_i3c_0_scl_t;
  wire xilinx_i3c_0_sda_o;
  wire xilinx_i3c_0_sda_pullup_en;
  wire xilinx_i3c_0_sda_t;
  wire xpm_cdc_gen_0_dest_rst_out;

  caliptra_htg940_bd_aux_reset_const_0_0 aux_reset_const_0
       (.dout(aux_reset_const_0_dout));
  caliptra_htg940_bd_axi_cdma_0_0 axi_cdma_0
       (.m_axi_aclk(board_core_clk),
        .m_axi_araddr(axi_cdma_0_M_AXI_ARADDR),
        .m_axi_arburst(axi_cdma_0_M_AXI_ARBURST),
        .m_axi_arcache(axi_cdma_0_M_AXI_ARCACHE),
        .m_axi_arlen(axi_cdma_0_M_AXI_ARLEN),
        .m_axi_arprot(axi_cdma_0_M_AXI_ARPROT),
        .m_axi_arready(axi_cdma_0_M_AXI_ARREADY),
        .m_axi_arsize(axi_cdma_0_M_AXI_ARSIZE),
        .m_axi_arvalid(axi_cdma_0_M_AXI_ARVALID),
        .m_axi_awaddr(axi_cdma_0_M_AXI_AWADDR),
        .m_axi_awburst(axi_cdma_0_M_AXI_AWBURST),
        .m_axi_awcache(axi_cdma_0_M_AXI_AWCACHE),
        .m_axi_awlen(axi_cdma_0_M_AXI_AWLEN),
        .m_axi_awprot(axi_cdma_0_M_AXI_AWPROT),
        .m_axi_awready(axi_cdma_0_M_AXI_AWREADY),
        .m_axi_awsize(axi_cdma_0_M_AXI_AWSIZE),
        .m_axi_awvalid(axi_cdma_0_M_AXI_AWVALID),
        .m_axi_bready(axi_cdma_0_M_AXI_BREADY),
        .m_axi_bresp(axi_cdma_0_M_AXI_BRESP),
        .m_axi_bvalid(axi_cdma_0_M_AXI_BVALID),
        .m_axi_rdata(axi_cdma_0_M_AXI_RDATA),
        .m_axi_rlast(axi_cdma_0_M_AXI_RLAST),
        .m_axi_rready(axi_cdma_0_M_AXI_RREADY),
        .m_axi_rresp(axi_cdma_0_M_AXI_RRESP),
        .m_axi_rvalid(axi_cdma_0_M_AXI_RVALID),
        .m_axi_wdata(axi_cdma_0_M_AXI_WDATA),
        .m_axi_wlast(axi_cdma_0_M_AXI_WLAST),
        .m_axi_wready(axi_cdma_0_M_AXI_WREADY),
        .m_axi_wstrb(axi_cdma_0_M_AXI_WSTRB),
        .m_axi_wvalid(axi_cdma_0_M_AXI_WVALID),
        .s_axi_lite_aclk(board_core_clk),
        .s_axi_lite_araddr(S_AXI_XILINX_DMA_ARADDR),
        .s_axi_lite_aresetn(board_reset_n),
        .s_axi_lite_arready(S_AXI_XILINX_DMA_ARREADY),
        .s_axi_lite_arvalid(S_AXI_XILINX_DMA_ARVALID),
        .s_axi_lite_awaddr(S_AXI_XILINX_DMA_AWADDR),
        .s_axi_lite_awready(S_AXI_XILINX_DMA_AWREADY),
        .s_axi_lite_awvalid(S_AXI_XILINX_DMA_AWVALID),
        .s_axi_lite_bready(S_AXI_XILINX_DMA_BREADY),
        .s_axi_lite_bresp(S_AXI_XILINX_DMA_BRESP),
        .s_axi_lite_bvalid(S_AXI_XILINX_DMA_BVALID),
        .s_axi_lite_rdata(S_AXI_XILINX_DMA_RDATA),
        .s_axi_lite_rready(S_AXI_XILINX_DMA_RREADY),
        .s_axi_lite_rresp(S_AXI_XILINX_DMA_RRESP),
        .s_axi_lite_rvalid(S_AXI_XILINX_DMA_RVALID),
        .s_axi_lite_wdata(S_AXI_XILINX_DMA_WDATA),
        .s_axi_lite_wready(S_AXI_XILINX_DMA_WREADY),
        .s_axi_lite_wvalid(S_AXI_XILINX_DMA_WVALID));
  caliptra_htg940_bd_axi_interconnect_0_0 axi_interconnect_0
       (.M00_AXI_araddr(S_AXI_CALIPTRA_ARADDR),
        .M00_AXI_arburst(S_AXI_CALIPTRA_ARBURST),
        .M00_AXI_arlen(S_AXI_CALIPTRA_ARLEN),
        .M00_AXI_arlock(S_AXI_CALIPTRA_ARLOCK),
        .M00_AXI_arready(S_AXI_CALIPTRA_ARREADY),
        .M00_AXI_arsize(S_AXI_CALIPTRA_ARSIZE),
        .M00_AXI_aruser(S_AXI_CALIPTRA_ARUSER),
        .M00_AXI_arvalid(S_AXI_CALIPTRA_ARVALID),
        .M00_AXI_awaddr(S_AXI_CALIPTRA_AWADDR),
        .M00_AXI_awburst(S_AXI_CALIPTRA_AWBURST),
        .M00_AXI_awlen(S_AXI_CALIPTRA_AWLEN),
        .M00_AXI_awlock(S_AXI_CALIPTRA_AWLOCK),
        .M00_AXI_awready(S_AXI_CALIPTRA_AWREADY),
        .M00_AXI_awsize(S_AXI_CALIPTRA_AWSIZE),
        .M00_AXI_awuser(S_AXI_CALIPTRA_AWUSER),
        .M00_AXI_awvalid(S_AXI_CALIPTRA_AWVALID),
        .M00_AXI_bready(S_AXI_CALIPTRA_BREADY),
        .M00_AXI_bresp(S_AXI_CALIPTRA_BRESP),
        .M00_AXI_bvalid(S_AXI_CALIPTRA_BVALID),
        .M00_AXI_rdata(S_AXI_CALIPTRA_RDATA),
        .M00_AXI_rlast(S_AXI_CALIPTRA_RLAST),
        .M00_AXI_rready(S_AXI_CALIPTRA_RREADY),
        .M00_AXI_rresp(S_AXI_CALIPTRA_RRESP),
        .M00_AXI_rvalid(S_AXI_CALIPTRA_RVALID),
        .M00_AXI_wdata(S_AXI_CALIPTRA_WDATA),
        .M00_AXI_wlast(S_AXI_CALIPTRA_WLAST),
        .M00_AXI_wready(S_AXI_CALIPTRA_WREADY),
        .M00_AXI_wstrb(S_AXI_CALIPTRA_WSTRB),
        .M00_AXI_wvalid(S_AXI_CALIPTRA_WVALID),
        .M01_AXI_araddr(S_AXI_I3C_ARADDR),
        .M01_AXI_arburst(S_AXI_I3C_ARBURST),
        .M01_AXI_arlen(S_AXI_I3C_ARLEN),
        .M01_AXI_arlock(S_AXI_I3C_ARLOCK),
        .M01_AXI_arprot(S_AXI_I3C_ARPROT),
        .M01_AXI_arready(S_AXI_I3C_ARREADY),
        .M01_AXI_arsize(S_AXI_I3C_ARSIZE),
        .M01_AXI_aruser(S_AXI_I3C_ARUSER),
        .M01_AXI_arvalid(S_AXI_I3C_ARVALID),
        .M01_AXI_awaddr(S_AXI_I3C_AWADDR),
        .M01_AXI_awburst(S_AXI_I3C_AWBURST),
        .M01_AXI_awlen(S_AXI_I3C_AWLEN),
        .M01_AXI_awlock(S_AXI_I3C_AWLOCK),
        .M01_AXI_awprot(S_AXI_I3C_AWPROT),
        .M01_AXI_awready(S_AXI_I3C_AWREADY),
        .M01_AXI_awsize(S_AXI_I3C_AWSIZE),
        .M01_AXI_awuser(S_AXI_I3C_AWUSER),
        .M01_AXI_awvalid(S_AXI_I3C_AWVALID),
        .M01_AXI_bready(S_AXI_I3C_BREADY),
        .M01_AXI_bresp(S_AXI_I3C_BRESP),
        .M01_AXI_bvalid(S_AXI_I3C_BVALID),
        .M01_AXI_rdata(S_AXI_I3C_RDATA),
        .M01_AXI_rlast(S_AXI_I3C_RLAST),
        .M01_AXI_rready(S_AXI_I3C_RREADY),
        .M01_AXI_rresp(S_AXI_I3C_RRESP),
        .M01_AXI_rvalid(S_AXI_I3C_RVALID),
        .M01_AXI_wdata(S_AXI_I3C_WDATA),
        .M01_AXI_wlast(S_AXI_I3C_WLAST),
        .M01_AXI_wready(S_AXI_I3C_WREADY),
        .M01_AXI_wstrb(S_AXI_I3C_WSTRB),
        .M01_AXI_wvalid(S_AXI_I3C_WVALID),
        .M02_AXI_araddr(S_AXI_LCC_ARADDR),
        .M02_AXI_arburst(S_AXI_LCC_ARBURST),
        .M02_AXI_arlen(S_AXI_LCC_ARLEN),
        .M02_AXI_arlock(S_AXI_LCC_ARLOCK),
        .M02_AXI_arprot(S_AXI_LCC_ARPROT),
        .M02_AXI_arready(S_AXI_LCC_ARREADY),
        .M02_AXI_arsize(S_AXI_LCC_ARSIZE),
        .M02_AXI_aruser(S_AXI_LCC_ARUSER),
        .M02_AXI_arvalid(S_AXI_LCC_ARVALID),
        .M02_AXI_awaddr(S_AXI_LCC_AWADDR),
        .M02_AXI_awburst(S_AXI_LCC_AWBURST),
        .M02_AXI_awlen(S_AXI_LCC_AWLEN),
        .M02_AXI_awlock(S_AXI_LCC_AWLOCK),
        .M02_AXI_awprot(S_AXI_LCC_AWPROT),
        .M02_AXI_awready(S_AXI_LCC_AWREADY),
        .M02_AXI_awsize(S_AXI_LCC_AWSIZE),
        .M02_AXI_awuser(S_AXI_LCC_AWUSER),
        .M02_AXI_awvalid(S_AXI_LCC_AWVALID),
        .M02_AXI_bready(S_AXI_LCC_BREADY),
        .M02_AXI_bresp(S_AXI_LCC_BRESP),
        .M02_AXI_bvalid(S_AXI_LCC_BVALID),
        .M02_AXI_rdata(S_AXI_LCC_RDATA),
        .M02_AXI_rlast(S_AXI_LCC_RLAST),
        .M02_AXI_rready(S_AXI_LCC_RREADY),
        .M02_AXI_rresp(S_AXI_LCC_RRESP),
        .M02_AXI_rvalid(S_AXI_LCC_RVALID),
        .M02_AXI_wdata(S_AXI_LCC_WDATA),
        .M02_AXI_wlast(S_AXI_LCC_WLAST),
        .M02_AXI_wready(S_AXI_LCC_WREADY),
        .M02_AXI_wstrb(S_AXI_LCC_WSTRB),
        .M02_AXI_wvalid(S_AXI_LCC_WVALID),
        .M03_AXI_araddr(S_AXI_MCI_ARADDR),
        .M03_AXI_arburst(S_AXI_MCI_ARBURST),
        .M03_AXI_arlen(S_AXI_MCI_ARLEN),
        .M03_AXI_arlock(S_AXI_MCI_ARLOCK),
        .M03_AXI_arready(S_AXI_MCI_ARREADY),
        .M03_AXI_arsize(S_AXI_MCI_ARSIZE),
        .M03_AXI_aruser(S_AXI_MCI_ARUSER),
        .M03_AXI_arvalid(S_AXI_MCI_ARVALID),
        .M03_AXI_awaddr(S_AXI_MCI_AWADDR),
        .M03_AXI_awburst(S_AXI_MCI_AWBURST),
        .M03_AXI_awlen(S_AXI_MCI_AWLEN),
        .M03_AXI_awlock(S_AXI_MCI_AWLOCK),
        .M03_AXI_awready(S_AXI_MCI_AWREADY),
        .M03_AXI_awsize(S_AXI_MCI_AWSIZE),
        .M03_AXI_awuser(S_AXI_MCI_AWUSER),
        .M03_AXI_awvalid(S_AXI_MCI_AWVALID),
        .M03_AXI_bready(S_AXI_MCI_BREADY),
        .M03_AXI_bresp(S_AXI_MCI_BRESP),
        .M03_AXI_bvalid(S_AXI_MCI_BVALID),
        .M03_AXI_rdata(S_AXI_MCI_RDATA),
        .M03_AXI_rlast(S_AXI_MCI_RLAST),
        .M03_AXI_rready(S_AXI_MCI_RREADY),
        .M03_AXI_rresp(S_AXI_MCI_RRESP),
        .M03_AXI_rvalid(S_AXI_MCI_RVALID),
        .M03_AXI_wdata(S_AXI_MCI_WDATA),
        .M03_AXI_wlast(S_AXI_MCI_WLAST),
        .M03_AXI_wready(S_AXI_MCI_WREADY),
        .M03_AXI_wstrb(S_AXI_MCI_WSTRB),
        .M03_AXI_wvalid(S_AXI_MCI_WVALID),
        .M04_AXI_araddr(S_AXI_MCU_ROM_ARADDR),
        .M04_AXI_arburst(S_AXI_MCU_ROM_ARBURST),
        .M04_AXI_arlen(S_AXI_MCU_ROM_ARLEN),
        .M04_AXI_arlock(S_AXI_MCU_ROM_ARLOCK),
        .M04_AXI_arready(S_AXI_MCU_ROM_ARREADY),
        .M04_AXI_arsize(S_AXI_MCU_ROM_ARSIZE),
        .M04_AXI_aruser(S_AXI_MCU_ROM_ARUSER),
        .M04_AXI_arvalid(S_AXI_MCU_ROM_ARVALID),
        .M04_AXI_awaddr(S_AXI_MCU_ROM_AWADDR),
        .M04_AXI_awburst(S_AXI_MCU_ROM_AWBURST),
        .M04_AXI_awlen(S_AXI_MCU_ROM_AWLEN),
        .M04_AXI_awlock(S_AXI_MCU_ROM_AWLOCK),
        .M04_AXI_awready(S_AXI_MCU_ROM_AWREADY),
        .M04_AXI_awsize(S_AXI_MCU_ROM_AWSIZE),
        .M04_AXI_awuser(S_AXI_MCU_ROM_AWUSER),
        .M04_AXI_awvalid(S_AXI_MCU_ROM_AWVALID),
        .M04_AXI_bready(S_AXI_MCU_ROM_BREADY),
        .M04_AXI_bresp(S_AXI_MCU_ROM_BRESP),
        .M04_AXI_bvalid(S_AXI_MCU_ROM_BVALID),
        .M04_AXI_rdata(S_AXI_MCU_ROM_RDATA),
        .M04_AXI_rlast(S_AXI_MCU_ROM_RLAST),
        .M04_AXI_rready(S_AXI_MCU_ROM_RREADY),
        .M04_AXI_rresp(S_AXI_MCU_ROM_RRESP),
        .M04_AXI_rvalid(S_AXI_MCU_ROM_RVALID),
        .M04_AXI_wdata(S_AXI_MCU_ROM_WDATA),
        .M04_AXI_wlast(S_AXI_MCU_ROM_WLAST),
        .M04_AXI_wready(S_AXI_MCU_ROM_WREADY),
        .M04_AXI_wstrb(S_AXI_MCU_ROM_WSTRB),
        .M04_AXI_wvalid(S_AXI_MCU_ROM_WVALID),
        .M05_AXI_araddr(S_AXI_OTP_ARADDR),
        .M05_AXI_arburst(S_AXI_OTP_ARBURST),
        .M05_AXI_arlen(S_AXI_OTP_ARLEN),
        .M05_AXI_arlock(S_AXI_OTP_ARLOCK),
        .M05_AXI_arprot(S_AXI_OTP_ARPROT),
        .M05_AXI_arready(S_AXI_OTP_ARREADY),
        .M05_AXI_arsize(S_AXI_OTP_ARSIZE),
        .M05_AXI_aruser(S_AXI_OTP_ARUSER),
        .M05_AXI_arvalid(S_AXI_OTP_ARVALID),
        .M05_AXI_awaddr(S_AXI_OTP_AWADDR),
        .M05_AXI_awburst(S_AXI_OTP_AWBURST),
        .M05_AXI_awlen(S_AXI_OTP_AWLEN),
        .M05_AXI_awlock(S_AXI_OTP_AWLOCK),
        .M05_AXI_awprot(S_AXI_OTP_AWPROT),
        .M05_AXI_awready(S_AXI_OTP_AWREADY),
        .M05_AXI_awsize(S_AXI_OTP_AWSIZE),
        .M05_AXI_awuser(S_AXI_OTP_AWUSER),
        .M05_AXI_awvalid(S_AXI_OTP_AWVALID),
        .M05_AXI_bready(S_AXI_OTP_BREADY),
        .M05_AXI_bresp(S_AXI_OTP_BRESP),
        .M05_AXI_bvalid(S_AXI_OTP_BVALID),
        .M05_AXI_rdata(S_AXI_OTP_RDATA),
        .M05_AXI_rlast(S_AXI_OTP_RLAST),
        .M05_AXI_rready(S_AXI_OTP_RREADY),
        .M05_AXI_rresp(S_AXI_OTP_RRESP),
        .M05_AXI_rvalid(S_AXI_OTP_RVALID),
        .M05_AXI_wdata(S_AXI_OTP_WDATA),
        .M05_AXI_wlast(S_AXI_OTP_WLAST),
        .M05_AXI_wready(S_AXI_OTP_WREADY),
        .M05_AXI_wstrb(S_AXI_OTP_WSTRB),
        .M05_AXI_wvalid(S_AXI_OTP_WVALID),
        .M06_AXI_araddr(S_AXI_WRAPPER_ARADDR),
        .M06_AXI_arprot(S_AXI_WRAPPER_ARPROT),
        .M06_AXI_arready(S_AXI_WRAPPER_ARREADY),
        .M06_AXI_arvalid(S_AXI_WRAPPER_ARVALID),
        .M06_AXI_awaddr(S_AXI_WRAPPER_AWADDR),
        .M06_AXI_awprot(S_AXI_WRAPPER_AWPROT),
        .M06_AXI_awready(S_AXI_WRAPPER_AWREADY),
        .M06_AXI_awvalid(S_AXI_WRAPPER_AWVALID),
        .M06_AXI_bready(S_AXI_WRAPPER_BREADY),
        .M06_AXI_bresp(S_AXI_WRAPPER_BRESP),
        .M06_AXI_bvalid(S_AXI_WRAPPER_BVALID),
        .M06_AXI_rdata(S_AXI_WRAPPER_RDATA),
        .M06_AXI_rready(S_AXI_WRAPPER_RREADY),
        .M06_AXI_rresp(S_AXI_WRAPPER_RRESP),
        .M06_AXI_rvalid(S_AXI_WRAPPER_RVALID),
        .M06_AXI_wdata(S_AXI_WRAPPER_WDATA),
        .M06_AXI_wready(S_AXI_WRAPPER_WREADY),
        .M06_AXI_wstrb(S_AXI_WRAPPER_WSTRB),
        .M06_AXI_wvalid(S_AXI_WRAPPER_WVALID),
        .M07_AXI_araddr(S_AXI_OTP_RAM_ARADDR),
        .M07_AXI_arburst(S_AXI_OTP_RAM_ARBURST),
        .M07_AXI_arcache(S_AXI_OTP_RAM_ARCACHE),
        .M07_AXI_arlen(S_AXI_OTP_RAM_ARLEN),
        .M07_AXI_arlock(S_AXI_OTP_RAM_ARLOCK),
        .M07_AXI_arprot(S_AXI_OTP_RAM_ARPROT),
        .M07_AXI_arready(S_AXI_OTP_RAM_ARREADY),
        .M07_AXI_arsize(S_AXI_OTP_RAM_ARSIZE),
        .M07_AXI_arvalid(S_AXI_OTP_RAM_ARVALID),
        .M07_AXI_awaddr(S_AXI_OTP_RAM_AWADDR),
        .M07_AXI_awburst(S_AXI_OTP_RAM_AWBURST),
        .M07_AXI_awcache(S_AXI_OTP_RAM_AWCACHE),
        .M07_AXI_awlen(S_AXI_OTP_RAM_AWLEN),
        .M07_AXI_awlock(S_AXI_OTP_RAM_AWLOCK),
        .M07_AXI_awprot(S_AXI_OTP_RAM_AWPROT),
        .M07_AXI_awready(S_AXI_OTP_RAM_AWREADY),
        .M07_AXI_awsize(S_AXI_OTP_RAM_AWSIZE),
        .M07_AXI_awvalid(S_AXI_OTP_RAM_AWVALID),
        .M07_AXI_bready(S_AXI_OTP_RAM_BREADY),
        .M07_AXI_bresp(S_AXI_OTP_RAM_BRESP),
        .M07_AXI_bvalid(S_AXI_OTP_RAM_BVALID),
        .M07_AXI_rdata(S_AXI_OTP_RAM_RDATA),
        .M07_AXI_rlast(S_AXI_OTP_RAM_RLAST),
        .M07_AXI_rready(S_AXI_OTP_RAM_RREADY),
        .M07_AXI_rresp(S_AXI_OTP_RAM_RRESP),
        .M07_AXI_rvalid(S_AXI_OTP_RAM_RVALID),
        .M07_AXI_wdata(S_AXI_OTP_RAM_WDATA),
        .M07_AXI_wlast(S_AXI_OTP_RAM_WLAST),
        .M07_AXI_wready(S_AXI_OTP_RAM_WREADY),
        .M07_AXI_wstrb(S_AXI_OTP_RAM_WSTRB),
        .M07_AXI_wvalid(S_AXI_OTP_RAM_WVALID),
        .M08_AXI_araddr(S_AXI_STAGING_SRAM_ARADDR),
        .M08_AXI_arburst(S_AXI_STAGING_SRAM_ARBURST),
        .M08_AXI_arcache(S_AXI_STAGING_SRAM_ARCACHE),
        .M08_AXI_arlen(S_AXI_STAGING_SRAM_ARLEN),
        .M08_AXI_arlock(S_AXI_STAGING_SRAM_ARLOCK),
        .M08_AXI_arprot(S_AXI_STAGING_SRAM_ARPROT),
        .M08_AXI_arready(S_AXI_STAGING_SRAM_ARREADY),
        .M08_AXI_arsize(S_AXI_STAGING_SRAM_ARSIZE),
        .M08_AXI_arvalid(S_AXI_STAGING_SRAM_ARVALID),
        .M08_AXI_awaddr(S_AXI_STAGING_SRAM_AWADDR),
        .M08_AXI_awburst(S_AXI_STAGING_SRAM_AWBURST),
        .M08_AXI_awcache(S_AXI_STAGING_SRAM_AWCACHE),
        .M08_AXI_awlen(S_AXI_STAGING_SRAM_AWLEN),
        .M08_AXI_awlock(S_AXI_STAGING_SRAM_AWLOCK),
        .M08_AXI_awprot(S_AXI_STAGING_SRAM_AWPROT),
        .M08_AXI_awready(S_AXI_STAGING_SRAM_AWREADY),
        .M08_AXI_awsize(S_AXI_STAGING_SRAM_AWSIZE),
        .M08_AXI_awvalid(S_AXI_STAGING_SRAM_AWVALID),
        .M08_AXI_bready(S_AXI_STAGING_SRAM_BREADY),
        .M08_AXI_bresp(S_AXI_STAGING_SRAM_BRESP),
        .M08_AXI_bvalid(S_AXI_STAGING_SRAM_BVALID),
        .M08_AXI_rdata(S_AXI_STAGING_SRAM_RDATA),
        .M08_AXI_rlast(S_AXI_STAGING_SRAM_RLAST),
        .M08_AXI_rready(S_AXI_STAGING_SRAM_RREADY),
        .M08_AXI_rresp(S_AXI_STAGING_SRAM_RRESP),
        .M08_AXI_rvalid(S_AXI_STAGING_SRAM_RVALID),
        .M08_AXI_wdata(S_AXI_STAGING_SRAM_WDATA),
        .M08_AXI_wlast(S_AXI_STAGING_SRAM_WLAST),
        .M08_AXI_wready(S_AXI_STAGING_SRAM_WREADY),
        .M08_AXI_wstrb(S_AXI_STAGING_SRAM_WSTRB),
        .M08_AXI_wvalid(S_AXI_STAGING_SRAM_WVALID),
        .M09_AXI_araddr(S_AXI_XILINX_I3C_ARADDR),
        .M09_AXI_arready(S_AXI_XILINX_I3C_ARREADY),
        .M09_AXI_arvalid(S_AXI_XILINX_I3C_ARVALID),
        .M09_AXI_awaddr(S_AXI_XILINX_I3C_AWADDR),
        .M09_AXI_awready(S_AXI_XILINX_I3C_AWREADY),
        .M09_AXI_awvalid(S_AXI_XILINX_I3C_AWVALID),
        .M09_AXI_bready(S_AXI_XILINX_I3C_BREADY),
        .M09_AXI_bresp(S_AXI_XILINX_I3C_BRESP),
        .M09_AXI_bvalid(S_AXI_XILINX_I3C_BVALID),
        .M09_AXI_rdata(S_AXI_XILINX_I3C_RDATA),
        .M09_AXI_rready(S_AXI_XILINX_I3C_RREADY),
        .M09_AXI_rresp(S_AXI_XILINX_I3C_RRESP),
        .M09_AXI_rvalid(S_AXI_XILINX_I3C_RVALID),
        .M09_AXI_wdata(S_AXI_XILINX_I3C_WDATA),
        .M09_AXI_wready(S_AXI_XILINX_I3C_WREADY),
        .M09_AXI_wstrb(S_AXI_XILINX_I3C_WSTRB),
        .M09_AXI_wvalid(S_AXI_XILINX_I3C_WVALID),
        .M10_AXI_araddr(S_AXI_XILINX_DMA_ARADDR),
        .M10_AXI_arready(S_AXI_XILINX_DMA_ARREADY),
        .M10_AXI_arvalid(S_AXI_XILINX_DMA_ARVALID),
        .M10_AXI_awaddr(S_AXI_XILINX_DMA_AWADDR),
        .M10_AXI_awready(S_AXI_XILINX_DMA_AWREADY),
        .M10_AXI_awvalid(S_AXI_XILINX_DMA_AWVALID),
        .M10_AXI_bready(S_AXI_XILINX_DMA_BREADY),
        .M10_AXI_bresp(S_AXI_XILINX_DMA_BRESP),
        .M10_AXI_bvalid(S_AXI_XILINX_DMA_BVALID),
        .M10_AXI_rdata(S_AXI_XILINX_DMA_RDATA),
        .M10_AXI_rready(S_AXI_XILINX_DMA_RREADY),
        .M10_AXI_rresp(S_AXI_XILINX_DMA_RRESP),
        .M10_AXI_rvalid(S_AXI_XILINX_DMA_RVALID),
        .M10_AXI_wdata(S_AXI_XILINX_DMA_WDATA),
        .M10_AXI_wready(S_AXI_XILINX_DMA_WREADY),
        .M10_AXI_wvalid(S_AXI_XILINX_DMA_WVALID),
        .M11_AXI_araddr(S_AXI_CALIPTRA_ROM_ARADDR),
        .M11_AXI_arburst(S_AXI_CALIPTRA_ROM_ARBURST),
        .M11_AXI_arcache(S_AXI_CALIPTRA_ROM_ARCACHE),
        .M11_AXI_arlen(S_AXI_CALIPTRA_ROM_ARLEN),
        .M11_AXI_arlock(S_AXI_CALIPTRA_ROM_ARLOCK),
        .M11_AXI_arprot(S_AXI_CALIPTRA_ROM_ARPROT),
        .M11_AXI_arready(S_AXI_CALIPTRA_ROM_ARREADY),
        .M11_AXI_arsize(S_AXI_CALIPTRA_ROM_ARSIZE),
        .M11_AXI_arvalid(S_AXI_CALIPTRA_ROM_ARVALID),
        .M11_AXI_awaddr(S_AXI_CALIPTRA_ROM_AWADDR),
        .M11_AXI_awburst(S_AXI_CALIPTRA_ROM_AWBURST),
        .M11_AXI_awcache(S_AXI_CALIPTRA_ROM_AWCACHE),
        .M11_AXI_awlen(S_AXI_CALIPTRA_ROM_AWLEN),
        .M11_AXI_awlock(S_AXI_CALIPTRA_ROM_AWLOCK),
        .M11_AXI_awprot(S_AXI_CALIPTRA_ROM_AWPROT),
        .M11_AXI_awready(S_AXI_CALIPTRA_ROM_AWREADY),
        .M11_AXI_awsize(S_AXI_CALIPTRA_ROM_AWSIZE),
        .M11_AXI_awvalid(S_AXI_CALIPTRA_ROM_AWVALID),
        .M11_AXI_bready(S_AXI_CALIPTRA_ROM_BREADY),
        .M11_AXI_bresp(S_AXI_CALIPTRA_ROM_BRESP),
        .M11_AXI_bvalid(S_AXI_CALIPTRA_ROM_BVALID),
        .M11_AXI_rdata(S_AXI_CALIPTRA_ROM_RDATA),
        .M11_AXI_rlast(S_AXI_CALIPTRA_ROM_RLAST),
        .M11_AXI_rready(S_AXI_CALIPTRA_ROM_RREADY),
        .M11_AXI_rresp(S_AXI_CALIPTRA_ROM_RRESP),
        .M11_AXI_rvalid(S_AXI_CALIPTRA_ROM_RVALID),
        .M11_AXI_wdata(S_AXI_CALIPTRA_ROM_WDATA),
        .M11_AXI_wlast(S_AXI_CALIPTRA_ROM_WLAST),
        .M11_AXI_wready(S_AXI_CALIPTRA_ROM_WREADY),
        .M11_AXI_wstrb(S_AXI_CALIPTRA_ROM_WSTRB),
        .M11_AXI_wvalid(S_AXI_CALIPTRA_ROM_WVALID),
        .M12_AXI_araddr(S_AXI_SS_ROM_ARADDR),
        .M12_AXI_arburst(S_AXI_SS_ROM_ARBURST),
        .M12_AXI_arcache(S_AXI_SS_ROM_ARCACHE),
        .M12_AXI_arlen(S_AXI_SS_ROM_ARLEN),
        .M12_AXI_arlock(S_AXI_SS_ROM_ARLOCK),
        .M12_AXI_arprot(S_AXI_SS_ROM_ARPROT),
        .M12_AXI_arready(S_AXI_SS_ROM_ARREADY),
        .M12_AXI_arsize(S_AXI_SS_ROM_ARSIZE),
        .M12_AXI_arvalid(S_AXI_SS_ROM_ARVALID),
        .M12_AXI_awaddr(S_AXI_SS_ROM_AWADDR),
        .M12_AXI_awburst(S_AXI_SS_ROM_AWBURST),
        .M12_AXI_awcache(S_AXI_SS_ROM_AWCACHE),
        .M12_AXI_awlen(S_AXI_SS_ROM_AWLEN),
        .M12_AXI_awlock(S_AXI_SS_ROM_AWLOCK),
        .M12_AXI_awprot(S_AXI_SS_ROM_AWPROT),
        .M12_AXI_awready(S_AXI_SS_ROM_AWREADY),
        .M12_AXI_awsize(S_AXI_SS_ROM_AWSIZE),
        .M12_AXI_awvalid(S_AXI_SS_ROM_AWVALID),
        .M12_AXI_bready(S_AXI_SS_ROM_BREADY),
        .M12_AXI_bresp(S_AXI_SS_ROM_BRESP),
        .M12_AXI_bvalid(S_AXI_SS_ROM_BVALID),
        .M12_AXI_rdata(S_AXI_SS_ROM_RDATA),
        .M12_AXI_rlast(S_AXI_SS_ROM_RLAST),
        .M12_AXI_rready(S_AXI_SS_ROM_RREADY),
        .M12_AXI_rresp(S_AXI_SS_ROM_RRESP),
        .M12_AXI_rvalid(S_AXI_SS_ROM_RVALID),
        .M12_AXI_wdata(S_AXI_SS_ROM_WDATA),
        .M12_AXI_wlast(S_AXI_SS_ROM_WLAST),
        .M12_AXI_wready(S_AXI_SS_ROM_WREADY),
        .M12_AXI_wstrb(S_AXI_SS_ROM_WSTRB),
        .M12_AXI_wvalid(S_AXI_SS_ROM_WVALID),
        .M13_AXI_araddr(S_AXI_I3C_SPARE_ARADDR),
        .M13_AXI_arburst(S_AXI_I3C_SPARE_ARBURST),
        .M13_AXI_arlen(S_AXI_I3C_SPARE_ARLEN),
        .M13_AXI_arlock(S_AXI_I3C_SPARE_ARLOCK),
        .M13_AXI_arready(S_AXI_I3C_SPARE_ARREADY),
        .M13_AXI_arsize(S_AXI_I3C_SPARE_ARSIZE),
        .M13_AXI_aruser(S_AXI_I3C_SPARE_ARUSER),
        .M13_AXI_arvalid(S_AXI_I3C_SPARE_ARVALID),
        .M13_AXI_awaddr(S_AXI_I3C_SPARE_AWADDR),
        .M13_AXI_awburst(S_AXI_I3C_SPARE_AWBURST),
        .M13_AXI_awlen(S_AXI_I3C_SPARE_AWLEN),
        .M13_AXI_awlock(S_AXI_I3C_SPARE_AWLOCK),
        .M13_AXI_awready(S_AXI_I3C_SPARE_AWREADY),
        .M13_AXI_awsize(S_AXI_I3C_SPARE_AWSIZE),
        .M13_AXI_awuser(S_AXI_I3C_SPARE_AWUSER),
        .M13_AXI_awvalid(S_AXI_I3C_SPARE_AWVALID),
        .M13_AXI_bready(S_AXI_I3C_SPARE_BREADY),
        .M13_AXI_bresp(S_AXI_I3C_SPARE_BRESP),
        .M13_AXI_bvalid(S_AXI_I3C_SPARE_BVALID),
        .M13_AXI_rdata(S_AXI_I3C_SPARE_RDATA),
        .M13_AXI_rlast(S_AXI_I3C_SPARE_RLAST),
        .M13_AXI_rready(S_AXI_I3C_SPARE_RREADY),
        .M13_AXI_rresp(S_AXI_I3C_SPARE_RRESP),
        .M13_AXI_rvalid(S_AXI_I3C_SPARE_RVALID),
        .M13_AXI_wdata(S_AXI_I3C_SPARE_WDATA),
        .M13_AXI_wlast(S_AXI_I3C_SPARE_WLAST),
        .M13_AXI_wready(S_AXI_I3C_SPARE_WREADY),
        .M13_AXI_wstrb(S_AXI_I3C_SPARE_WSTRB),
        .M13_AXI_wvalid(S_AXI_I3C_SPARE_WVALID),
        .M14_AXI_araddr(M_AXI_USB_BRIDGE_ARADDR),
        .M14_AXI_arburst(M_AXI_USB_BRIDGE_ARBURST),
        .M14_AXI_arcache(M_AXI_USB_BRIDGE_ARCACHE),
        .M14_AXI_arid(M_AXI_USB_BRIDGE_ARID),
        .M14_AXI_arlen(M_AXI_USB_BRIDGE_ARLEN),
        .M14_AXI_arlock(M_AXI_USB_BRIDGE_ARLOCK),
        .M14_AXI_arprot(M_AXI_USB_BRIDGE_ARPROT),
        .M14_AXI_arqos(M_AXI_USB_BRIDGE_ARQOS),
        .M14_AXI_arready(M_AXI_USB_BRIDGE_ARREADY),
        .M14_AXI_arsize(M_AXI_USB_BRIDGE_ARSIZE),
        .M14_AXI_aruser(M_AXI_USB_BRIDGE_ARUSER),
        .M14_AXI_arvalid(M_AXI_USB_BRIDGE_ARVALID),
        .M14_AXI_awaddr(M_AXI_USB_BRIDGE_AWADDR),
        .M14_AXI_awburst(M_AXI_USB_BRIDGE_AWBURST),
        .M14_AXI_awcache(M_AXI_USB_BRIDGE_AWCACHE),
        .M14_AXI_awid(M_AXI_USB_BRIDGE_AWID),
        .M14_AXI_awlen(M_AXI_USB_BRIDGE_AWLEN),
        .M14_AXI_awlock(M_AXI_USB_BRIDGE_AWLOCK),
        .M14_AXI_awprot(M_AXI_USB_BRIDGE_AWPROT),
        .M14_AXI_awqos(M_AXI_USB_BRIDGE_AWQOS),
        .M14_AXI_awready(M_AXI_USB_BRIDGE_AWREADY),
        .M14_AXI_awsize(M_AXI_USB_BRIDGE_AWSIZE),
        .M14_AXI_awuser(M_AXI_USB_BRIDGE_AWUSER),
        .M14_AXI_awvalid(M_AXI_USB_BRIDGE_AWVALID),
        .M14_AXI_bid(M_AXI_USB_BRIDGE_BID),
        .M14_AXI_bready(M_AXI_USB_BRIDGE_BREADY),
        .M14_AXI_bresp(M_AXI_USB_BRIDGE_BRESP),
        .M14_AXI_buser(M_AXI_USB_BRIDGE_BUSER),
        .M14_AXI_bvalid(M_AXI_USB_BRIDGE_BVALID),
        .M14_AXI_rdata(M_AXI_USB_BRIDGE_RDATA),
        .M14_AXI_rid(M_AXI_USB_BRIDGE_RID),
        .M14_AXI_rlast(M_AXI_USB_BRIDGE_RLAST),
        .M14_AXI_rready(M_AXI_USB_BRIDGE_RREADY),
        .M14_AXI_rresp(M_AXI_USB_BRIDGE_RRESP),
        .M14_AXI_ruser(M_AXI_USB_BRIDGE_RUSER),
        .M14_AXI_rvalid(M_AXI_USB_BRIDGE_RVALID),
        .M14_AXI_wdata(M_AXI_USB_BRIDGE_WDATA),
        .M14_AXI_wlast(M_AXI_USB_BRIDGE_WLAST),
        .M14_AXI_wready(M_AXI_USB_BRIDGE_WREADY),
        .M14_AXI_wstrb(M_AXI_USB_BRIDGE_WSTRB),
        .M14_AXI_wuser(M_AXI_USB_BRIDGE_WUSER),
        .M14_AXI_wvalid(M_AXI_USB_BRIDGE_WVALID),
        .M15_AXI_araddr(S_AXI_FIRMWARE_FLASH_ARADDR),
        .M15_AXI_arburst(S_AXI_FIRMWARE_FLASH_ARBURST),
        .M15_AXI_arcache(S_AXI_FIRMWARE_FLASH_ARCACHE),
        .M15_AXI_arlen(S_AXI_FIRMWARE_FLASH_ARLEN),
        .M15_AXI_arlock(S_AXI_FIRMWARE_FLASH_ARLOCK),
        .M15_AXI_arprot(S_AXI_FIRMWARE_FLASH_ARPROT),
        .M15_AXI_arready(S_AXI_FIRMWARE_FLASH_ARREADY),
        .M15_AXI_arsize(S_AXI_FIRMWARE_FLASH_ARSIZE),
        .M15_AXI_arvalid(S_AXI_FIRMWARE_FLASH_ARVALID),
        .M15_AXI_awaddr(S_AXI_FIRMWARE_FLASH_AWADDR),
        .M15_AXI_awburst(S_AXI_FIRMWARE_FLASH_AWBURST),
        .M15_AXI_awcache(S_AXI_FIRMWARE_FLASH_AWCACHE),
        .M15_AXI_awlen(S_AXI_FIRMWARE_FLASH_AWLEN),
        .M15_AXI_awlock(S_AXI_FIRMWARE_FLASH_AWLOCK),
        .M15_AXI_awprot(S_AXI_FIRMWARE_FLASH_AWPROT),
        .M15_AXI_awready(S_AXI_FIRMWARE_FLASH_AWREADY),
        .M15_AXI_awsize(S_AXI_FIRMWARE_FLASH_AWSIZE),
        .M15_AXI_awvalid(S_AXI_FIRMWARE_FLASH_AWVALID),
        .M15_AXI_bready(S_AXI_FIRMWARE_FLASH_BREADY),
        .M15_AXI_bresp(S_AXI_FIRMWARE_FLASH_BRESP),
        .M15_AXI_bvalid(S_AXI_FIRMWARE_FLASH_BVALID),
        .M15_AXI_rdata(S_AXI_FIRMWARE_FLASH_RDATA),
        .M15_AXI_rlast(S_AXI_FIRMWARE_FLASH_RLAST),
        .M15_AXI_rready(S_AXI_FIRMWARE_FLASH_RREADY),
        .M15_AXI_rresp(S_AXI_FIRMWARE_FLASH_RRESP),
        .M15_AXI_rvalid(S_AXI_FIRMWARE_FLASH_RVALID),
        .M15_AXI_wdata(S_AXI_FIRMWARE_FLASH_WDATA),
        .M15_AXI_wlast(S_AXI_FIRMWARE_FLASH_WLAST),
        .M15_AXI_wready(S_AXI_FIRMWARE_FLASH_WREADY),
        .M15_AXI_wstrb(S_AXI_FIRMWARE_FLASH_WSTRB),
        .M15_AXI_wvalid(S_AXI_FIRMWARE_FLASH_WVALID),
        .S00_AXI_araddr(caliptra_package_top_0_M_AXI_CALIPTRA_ARADDR),
        .S00_AXI_arburst(caliptra_package_top_0_M_AXI_CALIPTRA_ARBURST),
        .S00_AXI_arcache({1'b0,1'b0,1'b1,1'b1}),
        .S00_AXI_arid(caliptra_package_top_0_M_AXI_CALIPTRA_ARID),
        .S00_AXI_arlen(caliptra_package_top_0_M_AXI_CALIPTRA_ARLEN),
        .S00_AXI_arlock(caliptra_package_top_0_M_AXI_CALIPTRA_ARLOCK),
        .S00_AXI_arprot({1'b0,1'b0,1'b0}),
        .S00_AXI_arqos({1'b0,1'b0,1'b0,1'b0}),
        .S00_AXI_arready(caliptra_package_top_0_M_AXI_CALIPTRA_ARREADY),
        .S00_AXI_arsize(caliptra_package_top_0_M_AXI_CALIPTRA_ARSIZE),
        .S00_AXI_aruser(caliptra_package_top_0_M_AXI_CALIPTRA_ARUSER),
        .S00_AXI_arvalid(caliptra_package_top_0_M_AXI_CALIPTRA_ARVALID),
        .S00_AXI_awaddr(caliptra_package_top_0_M_AXI_CALIPTRA_AWADDR),
        .S00_AXI_awburst(caliptra_package_top_0_M_AXI_CALIPTRA_AWBURST),
        .S00_AXI_awcache({1'b0,1'b0,1'b1,1'b1}),
        .S00_AXI_awid(caliptra_package_top_0_M_AXI_CALIPTRA_AWID),
        .S00_AXI_awlen(caliptra_package_top_0_M_AXI_CALIPTRA_AWLEN),
        .S00_AXI_awlock(caliptra_package_top_0_M_AXI_CALIPTRA_AWLOCK),
        .S00_AXI_awprot({1'b0,1'b0,1'b0}),
        .S00_AXI_awqos({1'b0,1'b0,1'b0,1'b0}),
        .S00_AXI_awready(caliptra_package_top_0_M_AXI_CALIPTRA_AWREADY),
        .S00_AXI_awsize(caliptra_package_top_0_M_AXI_CALIPTRA_AWSIZE),
        .S00_AXI_awuser(caliptra_package_top_0_M_AXI_CALIPTRA_AWUSER),
        .S00_AXI_awvalid(caliptra_package_top_0_M_AXI_CALIPTRA_AWVALID),
        .S00_AXI_bid(caliptra_package_top_0_M_AXI_CALIPTRA_BID),
        .S00_AXI_bready(caliptra_package_top_0_M_AXI_CALIPTRA_BREADY),
        .S00_AXI_bresp(caliptra_package_top_0_M_AXI_CALIPTRA_BRESP),
        .S00_AXI_bvalid(caliptra_package_top_0_M_AXI_CALIPTRA_BVALID),
        .S00_AXI_rdata(caliptra_package_top_0_M_AXI_CALIPTRA_RDATA),
        .S00_AXI_rid(caliptra_package_top_0_M_AXI_CALIPTRA_RID),
        .S00_AXI_rlast(caliptra_package_top_0_M_AXI_CALIPTRA_RLAST),
        .S00_AXI_rready(caliptra_package_top_0_M_AXI_CALIPTRA_RREADY),
        .S00_AXI_rresp(caliptra_package_top_0_M_AXI_CALIPTRA_RRESP),
        .S00_AXI_rvalid(caliptra_package_top_0_M_AXI_CALIPTRA_RVALID),
        .S00_AXI_wdata(caliptra_package_top_0_M_AXI_CALIPTRA_WDATA),
        .S00_AXI_wlast(caliptra_package_top_0_M_AXI_CALIPTRA_WLAST),
        .S00_AXI_wready(caliptra_package_top_0_M_AXI_CALIPTRA_WREADY),
        .S00_AXI_wstrb(caliptra_package_top_0_M_AXI_CALIPTRA_WSTRB),
        .S00_AXI_wvalid(caliptra_package_top_0_M_AXI_CALIPTRA_WVALID),
        .S01_AXI_araddr(caliptra_package_top_0_M_AXI_MCU_IFU_ARADDR),
        .S01_AXI_arburst(caliptra_package_top_0_M_AXI_MCU_IFU_ARBURST),
        .S01_AXI_arcache(caliptra_package_top_0_M_AXI_MCU_IFU_ARCACHE),
        .S01_AXI_arid(caliptra_package_top_0_M_AXI_MCU_IFU_ARID),
        .S01_AXI_arlen(caliptra_package_top_0_M_AXI_MCU_IFU_ARLEN),
        .S01_AXI_arlock(caliptra_package_top_0_M_AXI_MCU_IFU_ARLOCK),
        .S01_AXI_arprot(caliptra_package_top_0_M_AXI_MCU_IFU_ARPROT),
        .S01_AXI_arqos(caliptra_package_top_0_M_AXI_MCU_IFU_ARQOS),
        .S01_AXI_arready(caliptra_package_top_0_M_AXI_MCU_IFU_ARREADY),
        .S01_AXI_arsize(caliptra_package_top_0_M_AXI_MCU_IFU_ARSIZE),
        .S01_AXI_aruser(caliptra_package_top_0_M_AXI_MCU_IFU_ARUSER),
        .S01_AXI_arvalid(caliptra_package_top_0_M_AXI_MCU_IFU_ARVALID),
        .S01_AXI_awaddr(caliptra_package_top_0_M_AXI_MCU_IFU_AWADDR),
        .S01_AXI_awburst(caliptra_package_top_0_M_AXI_MCU_IFU_AWBURST),
        .S01_AXI_awcache(caliptra_package_top_0_M_AXI_MCU_IFU_AWCACHE),
        .S01_AXI_awid(caliptra_package_top_0_M_AXI_MCU_IFU_AWID),
        .S01_AXI_awlen(caliptra_package_top_0_M_AXI_MCU_IFU_AWLEN),
        .S01_AXI_awlock(caliptra_package_top_0_M_AXI_MCU_IFU_AWLOCK),
        .S01_AXI_awprot(caliptra_package_top_0_M_AXI_MCU_IFU_AWPROT),
        .S01_AXI_awqos(caliptra_package_top_0_M_AXI_MCU_IFU_AWQOS),
        .S01_AXI_awready(caliptra_package_top_0_M_AXI_MCU_IFU_AWREADY),
        .S01_AXI_awsize(caliptra_package_top_0_M_AXI_MCU_IFU_AWSIZE),
        .S01_AXI_awuser(caliptra_package_top_0_M_AXI_MCU_IFU_AWUSER),
        .S01_AXI_awvalid(caliptra_package_top_0_M_AXI_MCU_IFU_AWVALID),
        .S01_AXI_bid(caliptra_package_top_0_M_AXI_MCU_IFU_BID),
        .S01_AXI_bready(caliptra_package_top_0_M_AXI_MCU_IFU_BREADY),
        .S01_AXI_bresp(caliptra_package_top_0_M_AXI_MCU_IFU_BRESP),
        .S01_AXI_bvalid(caliptra_package_top_0_M_AXI_MCU_IFU_BVALID),
        .S01_AXI_rdata(caliptra_package_top_0_M_AXI_MCU_IFU_RDATA),
        .S01_AXI_rid(caliptra_package_top_0_M_AXI_MCU_IFU_RID),
        .S01_AXI_rlast(caliptra_package_top_0_M_AXI_MCU_IFU_RLAST),
        .S01_AXI_rready(caliptra_package_top_0_M_AXI_MCU_IFU_RREADY),
        .S01_AXI_rresp(caliptra_package_top_0_M_AXI_MCU_IFU_RRESP),
        .S01_AXI_rvalid(caliptra_package_top_0_M_AXI_MCU_IFU_RVALID),
        .S01_AXI_wdata(caliptra_package_top_0_M_AXI_MCU_IFU_WDATA),
        .S01_AXI_wlast(caliptra_package_top_0_M_AXI_MCU_IFU_WLAST),
        .S01_AXI_wready(caliptra_package_top_0_M_AXI_MCU_IFU_WREADY),
        .S01_AXI_wstrb(caliptra_package_top_0_M_AXI_MCU_IFU_WSTRB),
        .S01_AXI_wvalid(caliptra_package_top_0_M_AXI_MCU_IFU_WVALID),
        .S02_AXI_araddr(caliptra_package_top_0_M_AXI_MCU_LSU_ARADDR),
        .S02_AXI_arburst(caliptra_package_top_0_M_AXI_MCU_LSU_ARBURST),
        .S02_AXI_arcache(caliptra_package_top_0_M_AXI_MCU_LSU_ARCACHE),
        .S02_AXI_arid(caliptra_package_top_0_M_AXI_MCU_LSU_ARID),
        .S02_AXI_arlen(caliptra_package_top_0_M_AXI_MCU_LSU_ARLEN),
        .S02_AXI_arlock(caliptra_package_top_0_M_AXI_MCU_LSU_ARLOCK),
        .S02_AXI_arprot(caliptra_package_top_0_M_AXI_MCU_LSU_ARPROT),
        .S02_AXI_arqos(caliptra_package_top_0_M_AXI_MCU_LSU_ARQOS),
        .S02_AXI_arready(caliptra_package_top_0_M_AXI_MCU_LSU_ARREADY),
        .S02_AXI_arsize(caliptra_package_top_0_M_AXI_MCU_LSU_ARSIZE),
        .S02_AXI_aruser(caliptra_package_top_0_M_AXI_MCU_LSU_ARUSER),
        .S02_AXI_arvalid(caliptra_package_top_0_M_AXI_MCU_LSU_ARVALID),
        .S02_AXI_awaddr(caliptra_package_top_0_M_AXI_MCU_LSU_AWADDR),
        .S02_AXI_awburst(caliptra_package_top_0_M_AXI_MCU_LSU_AWBURST),
        .S02_AXI_awcache(caliptra_package_top_0_M_AXI_MCU_LSU_AWCACHE),
        .S02_AXI_awid(caliptra_package_top_0_M_AXI_MCU_LSU_AWID),
        .S02_AXI_awlen(caliptra_package_top_0_M_AXI_MCU_LSU_AWLEN),
        .S02_AXI_awlock(caliptra_package_top_0_M_AXI_MCU_LSU_AWLOCK),
        .S02_AXI_awprot(caliptra_package_top_0_M_AXI_MCU_LSU_AWPROT),
        .S02_AXI_awqos(caliptra_package_top_0_M_AXI_MCU_LSU_AWQOS),
        .S02_AXI_awready(caliptra_package_top_0_M_AXI_MCU_LSU_AWREADY),
        .S02_AXI_awsize(caliptra_package_top_0_M_AXI_MCU_LSU_AWSIZE),
        .S02_AXI_awuser(caliptra_package_top_0_M_AXI_MCU_LSU_AWUSER),
        .S02_AXI_awvalid(caliptra_package_top_0_M_AXI_MCU_LSU_AWVALID),
        .S02_AXI_bid(caliptra_package_top_0_M_AXI_MCU_LSU_BID),
        .S02_AXI_bready(caliptra_package_top_0_M_AXI_MCU_LSU_BREADY),
        .S02_AXI_bresp(caliptra_package_top_0_M_AXI_MCU_LSU_BRESP),
        .S02_AXI_bvalid(caliptra_package_top_0_M_AXI_MCU_LSU_BVALID),
        .S02_AXI_rdata(caliptra_package_top_0_M_AXI_MCU_LSU_RDATA),
        .S02_AXI_rid(caliptra_package_top_0_M_AXI_MCU_LSU_RID),
        .S02_AXI_rlast(caliptra_package_top_0_M_AXI_MCU_LSU_RLAST),
        .S02_AXI_rready(caliptra_package_top_0_M_AXI_MCU_LSU_RREADY),
        .S02_AXI_rresp(caliptra_package_top_0_M_AXI_MCU_LSU_RRESP),
        .S02_AXI_rvalid(caliptra_package_top_0_M_AXI_MCU_LSU_RVALID),
        .S02_AXI_wdata(caliptra_package_top_0_M_AXI_MCU_LSU_WDATA),
        .S02_AXI_wlast(caliptra_package_top_0_M_AXI_MCU_LSU_WLAST),
        .S02_AXI_wready(caliptra_package_top_0_M_AXI_MCU_LSU_WREADY),
        .S02_AXI_wstrb(caliptra_package_top_0_M_AXI_MCU_LSU_WSTRB),
        .S02_AXI_wvalid(caliptra_package_top_0_M_AXI_MCU_LSU_WVALID),
        .S03_AXI_araddr(caliptra_package_top_0_M_AXI_MCU_SB_ARADDR),
        .S03_AXI_arburst(caliptra_package_top_0_M_AXI_MCU_SB_ARBURST),
        .S03_AXI_arcache(caliptra_package_top_0_M_AXI_MCU_SB_ARCACHE),
        .S03_AXI_arid(caliptra_package_top_0_M_AXI_MCU_SB_ARID),
        .S03_AXI_arlen(caliptra_package_top_0_M_AXI_MCU_SB_ARLEN),
        .S03_AXI_arlock(caliptra_package_top_0_M_AXI_MCU_SB_ARLOCK),
        .S03_AXI_arprot(caliptra_package_top_0_M_AXI_MCU_SB_ARPROT),
        .S03_AXI_arqos(caliptra_package_top_0_M_AXI_MCU_SB_ARQOS),
        .S03_AXI_arready(caliptra_package_top_0_M_AXI_MCU_SB_ARREADY),
        .S03_AXI_arsize(caliptra_package_top_0_M_AXI_MCU_SB_ARSIZE),
        .S03_AXI_aruser(caliptra_package_top_0_M_AXI_MCU_SB_ARUSER),
        .S03_AXI_arvalid(caliptra_package_top_0_M_AXI_MCU_SB_ARVALID),
        .S03_AXI_awaddr(caliptra_package_top_0_M_AXI_MCU_SB_AWADDR),
        .S03_AXI_awburst(caliptra_package_top_0_M_AXI_MCU_SB_AWBURST),
        .S03_AXI_awcache(caliptra_package_top_0_M_AXI_MCU_SB_AWCACHE),
        .S03_AXI_awid(caliptra_package_top_0_M_AXI_MCU_SB_AWID),
        .S03_AXI_awlen(caliptra_package_top_0_M_AXI_MCU_SB_AWLEN),
        .S03_AXI_awlock(caliptra_package_top_0_M_AXI_MCU_SB_AWLOCK),
        .S03_AXI_awprot(caliptra_package_top_0_M_AXI_MCU_SB_AWPROT),
        .S03_AXI_awqos(caliptra_package_top_0_M_AXI_MCU_SB_AWQOS),
        .S03_AXI_awready(caliptra_package_top_0_M_AXI_MCU_SB_AWREADY),
        .S03_AXI_awsize(caliptra_package_top_0_M_AXI_MCU_SB_AWSIZE),
        .S03_AXI_awuser(caliptra_package_top_0_M_AXI_MCU_SB_AWUSER),
        .S03_AXI_awvalid(caliptra_package_top_0_M_AXI_MCU_SB_AWVALID),
        .S03_AXI_bid(caliptra_package_top_0_M_AXI_MCU_SB_BID),
        .S03_AXI_bready(caliptra_package_top_0_M_AXI_MCU_SB_BREADY),
        .S03_AXI_bresp(caliptra_package_top_0_M_AXI_MCU_SB_BRESP),
        .S03_AXI_bvalid(caliptra_package_top_0_M_AXI_MCU_SB_BVALID),
        .S03_AXI_rdata(caliptra_package_top_0_M_AXI_MCU_SB_RDATA),
        .S03_AXI_rid(caliptra_package_top_0_M_AXI_MCU_SB_RID),
        .S03_AXI_rlast(caliptra_package_top_0_M_AXI_MCU_SB_RLAST),
        .S03_AXI_rready(caliptra_package_top_0_M_AXI_MCU_SB_RREADY),
        .S03_AXI_rresp(caliptra_package_top_0_M_AXI_MCU_SB_RRESP),
        .S03_AXI_rvalid(caliptra_package_top_0_M_AXI_MCU_SB_RVALID),
        .S03_AXI_wdata(caliptra_package_top_0_M_AXI_MCU_SB_WDATA),
        .S03_AXI_wlast(caliptra_package_top_0_M_AXI_MCU_SB_WLAST),
        .S03_AXI_wready(caliptra_package_top_0_M_AXI_MCU_SB_WREADY),
        .S03_AXI_wstrb(caliptra_package_top_0_M_AXI_MCU_SB_WSTRB),
        .S03_AXI_wvalid(caliptra_package_top_0_M_AXI_MCU_SB_WVALID),
        .S04_AXI_araddr(axi_cdma_0_M_AXI_ARADDR),
        .S04_AXI_arburst(axi_cdma_0_M_AXI_ARBURST),
        .S04_AXI_arcache(axi_cdma_0_M_AXI_ARCACHE),
        .S04_AXI_arlen(axi_cdma_0_M_AXI_ARLEN),
        .S04_AXI_arlock(1'b0),
        .S04_AXI_arprot(axi_cdma_0_M_AXI_ARPROT),
        .S04_AXI_arqos({1'b0,1'b0,1'b0,1'b0}),
        .S04_AXI_arready(axi_cdma_0_M_AXI_ARREADY),
        .S04_AXI_arsize(axi_cdma_0_M_AXI_ARSIZE),
        .S04_AXI_arvalid(axi_cdma_0_M_AXI_ARVALID),
        .S04_AXI_awaddr(axi_cdma_0_M_AXI_AWADDR),
        .S04_AXI_awburst(axi_cdma_0_M_AXI_AWBURST),
        .S04_AXI_awcache(axi_cdma_0_M_AXI_AWCACHE),
        .S04_AXI_awlen(axi_cdma_0_M_AXI_AWLEN),
        .S04_AXI_awlock(1'b0),
        .S04_AXI_awprot(axi_cdma_0_M_AXI_AWPROT),
        .S04_AXI_awqos({1'b0,1'b0,1'b0,1'b0}),
        .S04_AXI_awready(axi_cdma_0_M_AXI_AWREADY),
        .S04_AXI_awsize(axi_cdma_0_M_AXI_AWSIZE),
        .S04_AXI_awvalid(axi_cdma_0_M_AXI_AWVALID),
        .S04_AXI_bready(axi_cdma_0_M_AXI_BREADY),
        .S04_AXI_bresp(axi_cdma_0_M_AXI_BRESP),
        .S04_AXI_bvalid(axi_cdma_0_M_AXI_BVALID),
        .S04_AXI_rdata(axi_cdma_0_M_AXI_RDATA),
        .S04_AXI_rlast(axi_cdma_0_M_AXI_RLAST),
        .S04_AXI_rready(axi_cdma_0_M_AXI_RREADY),
        .S04_AXI_rresp(axi_cdma_0_M_AXI_RRESP),
        .S04_AXI_rvalid(axi_cdma_0_M_AXI_RVALID),
        .S04_AXI_wdata(axi_cdma_0_M_AXI_WDATA),
        .S04_AXI_wlast(axi_cdma_0_M_AXI_WLAST),
        .S04_AXI_wready(axi_cdma_0_M_AXI_WREADY),
        .S04_AXI_wstrb(axi_cdma_0_M_AXI_WSTRB),
        .S04_AXI_wvalid(axi_cdma_0_M_AXI_WVALID),
        .aclk(board_core_clk),
        .aclk1(htg940_clocks_clk_out2),
        .aresetn(board_reset_n));
  caliptra_htg940_bd_caliptra_package_top_0_0 caliptra_package_top_0
       (.EXT_SCL(EXT_SCL),
        .EXT_SDA(EXT_SDA),
        .EXT_SDA_EN(EXT_SDA_EN),
        .EXT_SDA_IN(EXT_SDA_IN),
        .EXT_SDA_UP(EXT_SDA_UP),
        .M_AXI_CALIPTRA_ARADDR(caliptra_package_top_0_M_AXI_CALIPTRA_ARADDR),
        .M_AXI_CALIPTRA_ARBURST(caliptra_package_top_0_M_AXI_CALIPTRA_ARBURST),
        .M_AXI_CALIPTRA_ARID(caliptra_package_top_0_M_AXI_CALIPTRA_ARID),
        .M_AXI_CALIPTRA_ARLEN(caliptra_package_top_0_M_AXI_CALIPTRA_ARLEN),
        .M_AXI_CALIPTRA_ARLOCK(caliptra_package_top_0_M_AXI_CALIPTRA_ARLOCK),
        .M_AXI_CALIPTRA_ARREADY(caliptra_package_top_0_M_AXI_CALIPTRA_ARREADY),
        .M_AXI_CALIPTRA_ARSIZE(caliptra_package_top_0_M_AXI_CALIPTRA_ARSIZE),
        .M_AXI_CALIPTRA_ARUSER(caliptra_package_top_0_M_AXI_CALIPTRA_ARUSER),
        .M_AXI_CALIPTRA_ARVALID(caliptra_package_top_0_M_AXI_CALIPTRA_ARVALID),
        .M_AXI_CALIPTRA_AWADDR(caliptra_package_top_0_M_AXI_CALIPTRA_AWADDR),
        .M_AXI_CALIPTRA_AWBURST(caliptra_package_top_0_M_AXI_CALIPTRA_AWBURST),
        .M_AXI_CALIPTRA_AWID(caliptra_package_top_0_M_AXI_CALIPTRA_AWID),
        .M_AXI_CALIPTRA_AWLEN(caliptra_package_top_0_M_AXI_CALIPTRA_AWLEN),
        .M_AXI_CALIPTRA_AWLOCK(caliptra_package_top_0_M_AXI_CALIPTRA_AWLOCK),
        .M_AXI_CALIPTRA_AWREADY(caliptra_package_top_0_M_AXI_CALIPTRA_AWREADY),
        .M_AXI_CALIPTRA_AWSIZE(caliptra_package_top_0_M_AXI_CALIPTRA_AWSIZE),
        .M_AXI_CALIPTRA_AWUSER(caliptra_package_top_0_M_AXI_CALIPTRA_AWUSER),
        .M_AXI_CALIPTRA_AWVALID(caliptra_package_top_0_M_AXI_CALIPTRA_AWVALID),
        .M_AXI_CALIPTRA_BID(caliptra_package_top_0_M_AXI_CALIPTRA_BID),
        .M_AXI_CALIPTRA_BREADY(caliptra_package_top_0_M_AXI_CALIPTRA_BREADY),
        .M_AXI_CALIPTRA_BRESP(caliptra_package_top_0_M_AXI_CALIPTRA_BRESP),
        .M_AXI_CALIPTRA_BVALID(caliptra_package_top_0_M_AXI_CALIPTRA_BVALID),
        .M_AXI_CALIPTRA_RDATA(caliptra_package_top_0_M_AXI_CALIPTRA_RDATA),
        .M_AXI_CALIPTRA_RID(caliptra_package_top_0_M_AXI_CALIPTRA_RID),
        .M_AXI_CALIPTRA_RLAST(caliptra_package_top_0_M_AXI_CALIPTRA_RLAST),
        .M_AXI_CALIPTRA_RREADY(caliptra_package_top_0_M_AXI_CALIPTRA_RREADY),
        .M_AXI_CALIPTRA_RRESP(caliptra_package_top_0_M_AXI_CALIPTRA_RRESP),
        .M_AXI_CALIPTRA_RVALID(caliptra_package_top_0_M_AXI_CALIPTRA_RVALID),
        .M_AXI_CALIPTRA_WDATA(caliptra_package_top_0_M_AXI_CALIPTRA_WDATA),
        .M_AXI_CALIPTRA_WLAST(caliptra_package_top_0_M_AXI_CALIPTRA_WLAST),
        .M_AXI_CALIPTRA_WREADY(caliptra_package_top_0_M_AXI_CALIPTRA_WREADY),
        .M_AXI_CALIPTRA_WSTRB(caliptra_package_top_0_M_AXI_CALIPTRA_WSTRB),
        .M_AXI_CALIPTRA_WVALID(caliptra_package_top_0_M_AXI_CALIPTRA_WVALID),
        .M_AXI_MCU_IFU_ARADDR(caliptra_package_top_0_M_AXI_MCU_IFU_ARADDR),
        .M_AXI_MCU_IFU_ARBURST(caliptra_package_top_0_M_AXI_MCU_IFU_ARBURST),
        .M_AXI_MCU_IFU_ARCACHE(caliptra_package_top_0_M_AXI_MCU_IFU_ARCACHE),
        .M_AXI_MCU_IFU_ARID(caliptra_package_top_0_M_AXI_MCU_IFU_ARID),
        .M_AXI_MCU_IFU_ARLEN(caliptra_package_top_0_M_AXI_MCU_IFU_ARLEN),
        .M_AXI_MCU_IFU_ARLOCK(caliptra_package_top_0_M_AXI_MCU_IFU_ARLOCK),
        .M_AXI_MCU_IFU_ARPROT(caliptra_package_top_0_M_AXI_MCU_IFU_ARPROT),
        .M_AXI_MCU_IFU_ARQOS(caliptra_package_top_0_M_AXI_MCU_IFU_ARQOS),
        .M_AXI_MCU_IFU_ARREADY(caliptra_package_top_0_M_AXI_MCU_IFU_ARREADY),
        .M_AXI_MCU_IFU_ARSIZE(caliptra_package_top_0_M_AXI_MCU_IFU_ARSIZE),
        .M_AXI_MCU_IFU_ARUSER(caliptra_package_top_0_M_AXI_MCU_IFU_ARUSER),
        .M_AXI_MCU_IFU_ARVALID(caliptra_package_top_0_M_AXI_MCU_IFU_ARVALID),
        .M_AXI_MCU_IFU_AWADDR(caliptra_package_top_0_M_AXI_MCU_IFU_AWADDR),
        .M_AXI_MCU_IFU_AWBURST(caliptra_package_top_0_M_AXI_MCU_IFU_AWBURST),
        .M_AXI_MCU_IFU_AWCACHE(caliptra_package_top_0_M_AXI_MCU_IFU_AWCACHE),
        .M_AXI_MCU_IFU_AWID(caliptra_package_top_0_M_AXI_MCU_IFU_AWID),
        .M_AXI_MCU_IFU_AWLEN(caliptra_package_top_0_M_AXI_MCU_IFU_AWLEN),
        .M_AXI_MCU_IFU_AWLOCK(caliptra_package_top_0_M_AXI_MCU_IFU_AWLOCK),
        .M_AXI_MCU_IFU_AWPROT(caliptra_package_top_0_M_AXI_MCU_IFU_AWPROT),
        .M_AXI_MCU_IFU_AWQOS(caliptra_package_top_0_M_AXI_MCU_IFU_AWQOS),
        .M_AXI_MCU_IFU_AWREADY(caliptra_package_top_0_M_AXI_MCU_IFU_AWREADY),
        .M_AXI_MCU_IFU_AWSIZE(caliptra_package_top_0_M_AXI_MCU_IFU_AWSIZE),
        .M_AXI_MCU_IFU_AWUSER(caliptra_package_top_0_M_AXI_MCU_IFU_AWUSER),
        .M_AXI_MCU_IFU_AWVALID(caliptra_package_top_0_M_AXI_MCU_IFU_AWVALID),
        .M_AXI_MCU_IFU_BID(caliptra_package_top_0_M_AXI_MCU_IFU_BID),
        .M_AXI_MCU_IFU_BREADY(caliptra_package_top_0_M_AXI_MCU_IFU_BREADY),
        .M_AXI_MCU_IFU_BRESP(caliptra_package_top_0_M_AXI_MCU_IFU_BRESP),
        .M_AXI_MCU_IFU_BVALID(caliptra_package_top_0_M_AXI_MCU_IFU_BVALID),
        .M_AXI_MCU_IFU_RDATA(caliptra_package_top_0_M_AXI_MCU_IFU_RDATA),
        .M_AXI_MCU_IFU_RID(caliptra_package_top_0_M_AXI_MCU_IFU_RID),
        .M_AXI_MCU_IFU_RLAST(caliptra_package_top_0_M_AXI_MCU_IFU_RLAST),
        .M_AXI_MCU_IFU_RREADY(caliptra_package_top_0_M_AXI_MCU_IFU_RREADY),
        .M_AXI_MCU_IFU_RRESP(caliptra_package_top_0_M_AXI_MCU_IFU_RRESP),
        .M_AXI_MCU_IFU_RVALID(caliptra_package_top_0_M_AXI_MCU_IFU_RVALID),
        .M_AXI_MCU_IFU_WDATA(caliptra_package_top_0_M_AXI_MCU_IFU_WDATA),
        .M_AXI_MCU_IFU_WLAST(caliptra_package_top_0_M_AXI_MCU_IFU_WLAST),
        .M_AXI_MCU_IFU_WREADY(caliptra_package_top_0_M_AXI_MCU_IFU_WREADY),
        .M_AXI_MCU_IFU_WSTRB(caliptra_package_top_0_M_AXI_MCU_IFU_WSTRB),
        .M_AXI_MCU_IFU_WVALID(caliptra_package_top_0_M_AXI_MCU_IFU_WVALID),
        .M_AXI_MCU_LSU_ARADDR(caliptra_package_top_0_M_AXI_MCU_LSU_ARADDR),
        .M_AXI_MCU_LSU_ARBURST(caliptra_package_top_0_M_AXI_MCU_LSU_ARBURST),
        .M_AXI_MCU_LSU_ARCACHE(caliptra_package_top_0_M_AXI_MCU_LSU_ARCACHE),
        .M_AXI_MCU_LSU_ARID(caliptra_package_top_0_M_AXI_MCU_LSU_ARID),
        .M_AXI_MCU_LSU_ARLEN(caliptra_package_top_0_M_AXI_MCU_LSU_ARLEN),
        .M_AXI_MCU_LSU_ARLOCK(caliptra_package_top_0_M_AXI_MCU_LSU_ARLOCK),
        .M_AXI_MCU_LSU_ARPROT(caliptra_package_top_0_M_AXI_MCU_LSU_ARPROT),
        .M_AXI_MCU_LSU_ARQOS(caliptra_package_top_0_M_AXI_MCU_LSU_ARQOS),
        .M_AXI_MCU_LSU_ARREADY(caliptra_package_top_0_M_AXI_MCU_LSU_ARREADY),
        .M_AXI_MCU_LSU_ARSIZE(caliptra_package_top_0_M_AXI_MCU_LSU_ARSIZE),
        .M_AXI_MCU_LSU_ARUSER(caliptra_package_top_0_M_AXI_MCU_LSU_ARUSER),
        .M_AXI_MCU_LSU_ARVALID(caliptra_package_top_0_M_AXI_MCU_LSU_ARVALID),
        .M_AXI_MCU_LSU_AWADDR(caliptra_package_top_0_M_AXI_MCU_LSU_AWADDR),
        .M_AXI_MCU_LSU_AWBURST(caliptra_package_top_0_M_AXI_MCU_LSU_AWBURST),
        .M_AXI_MCU_LSU_AWCACHE(caliptra_package_top_0_M_AXI_MCU_LSU_AWCACHE),
        .M_AXI_MCU_LSU_AWID(caliptra_package_top_0_M_AXI_MCU_LSU_AWID),
        .M_AXI_MCU_LSU_AWLEN(caliptra_package_top_0_M_AXI_MCU_LSU_AWLEN),
        .M_AXI_MCU_LSU_AWLOCK(caliptra_package_top_0_M_AXI_MCU_LSU_AWLOCK),
        .M_AXI_MCU_LSU_AWPROT(caliptra_package_top_0_M_AXI_MCU_LSU_AWPROT),
        .M_AXI_MCU_LSU_AWQOS(caliptra_package_top_0_M_AXI_MCU_LSU_AWQOS),
        .M_AXI_MCU_LSU_AWREADY(caliptra_package_top_0_M_AXI_MCU_LSU_AWREADY),
        .M_AXI_MCU_LSU_AWSIZE(caliptra_package_top_0_M_AXI_MCU_LSU_AWSIZE),
        .M_AXI_MCU_LSU_AWUSER(caliptra_package_top_0_M_AXI_MCU_LSU_AWUSER),
        .M_AXI_MCU_LSU_AWVALID(caliptra_package_top_0_M_AXI_MCU_LSU_AWVALID),
        .M_AXI_MCU_LSU_BID(caliptra_package_top_0_M_AXI_MCU_LSU_BID),
        .M_AXI_MCU_LSU_BREADY(caliptra_package_top_0_M_AXI_MCU_LSU_BREADY),
        .M_AXI_MCU_LSU_BRESP(caliptra_package_top_0_M_AXI_MCU_LSU_BRESP),
        .M_AXI_MCU_LSU_BVALID(caliptra_package_top_0_M_AXI_MCU_LSU_BVALID),
        .M_AXI_MCU_LSU_RDATA(caliptra_package_top_0_M_AXI_MCU_LSU_RDATA),
        .M_AXI_MCU_LSU_RID(caliptra_package_top_0_M_AXI_MCU_LSU_RID),
        .M_AXI_MCU_LSU_RLAST(caliptra_package_top_0_M_AXI_MCU_LSU_RLAST),
        .M_AXI_MCU_LSU_RREADY(caliptra_package_top_0_M_AXI_MCU_LSU_RREADY),
        .M_AXI_MCU_LSU_RRESP(caliptra_package_top_0_M_AXI_MCU_LSU_RRESP),
        .M_AXI_MCU_LSU_RVALID(caliptra_package_top_0_M_AXI_MCU_LSU_RVALID),
        .M_AXI_MCU_LSU_WDATA(caliptra_package_top_0_M_AXI_MCU_LSU_WDATA),
        .M_AXI_MCU_LSU_WLAST(caliptra_package_top_0_M_AXI_MCU_LSU_WLAST),
        .M_AXI_MCU_LSU_WREADY(caliptra_package_top_0_M_AXI_MCU_LSU_WREADY),
        .M_AXI_MCU_LSU_WSTRB(caliptra_package_top_0_M_AXI_MCU_LSU_WSTRB),
        .M_AXI_MCU_LSU_WVALID(caliptra_package_top_0_M_AXI_MCU_LSU_WVALID),
        .M_AXI_MCU_SB_ARADDR(caliptra_package_top_0_M_AXI_MCU_SB_ARADDR),
        .M_AXI_MCU_SB_ARBURST(caliptra_package_top_0_M_AXI_MCU_SB_ARBURST),
        .M_AXI_MCU_SB_ARCACHE(caliptra_package_top_0_M_AXI_MCU_SB_ARCACHE),
        .M_AXI_MCU_SB_ARID(caliptra_package_top_0_M_AXI_MCU_SB_ARID),
        .M_AXI_MCU_SB_ARLEN(caliptra_package_top_0_M_AXI_MCU_SB_ARLEN),
        .M_AXI_MCU_SB_ARLOCK(caliptra_package_top_0_M_AXI_MCU_SB_ARLOCK),
        .M_AXI_MCU_SB_ARPROT(caliptra_package_top_0_M_AXI_MCU_SB_ARPROT),
        .M_AXI_MCU_SB_ARQOS(caliptra_package_top_0_M_AXI_MCU_SB_ARQOS),
        .M_AXI_MCU_SB_ARREADY(caliptra_package_top_0_M_AXI_MCU_SB_ARREADY),
        .M_AXI_MCU_SB_ARSIZE(caliptra_package_top_0_M_AXI_MCU_SB_ARSIZE),
        .M_AXI_MCU_SB_ARUSER(caliptra_package_top_0_M_AXI_MCU_SB_ARUSER),
        .M_AXI_MCU_SB_ARVALID(caliptra_package_top_0_M_AXI_MCU_SB_ARVALID),
        .M_AXI_MCU_SB_AWADDR(caliptra_package_top_0_M_AXI_MCU_SB_AWADDR),
        .M_AXI_MCU_SB_AWBURST(caliptra_package_top_0_M_AXI_MCU_SB_AWBURST),
        .M_AXI_MCU_SB_AWCACHE(caliptra_package_top_0_M_AXI_MCU_SB_AWCACHE),
        .M_AXI_MCU_SB_AWID(caliptra_package_top_0_M_AXI_MCU_SB_AWID),
        .M_AXI_MCU_SB_AWLEN(caliptra_package_top_0_M_AXI_MCU_SB_AWLEN),
        .M_AXI_MCU_SB_AWLOCK(caliptra_package_top_0_M_AXI_MCU_SB_AWLOCK),
        .M_AXI_MCU_SB_AWPROT(caliptra_package_top_0_M_AXI_MCU_SB_AWPROT),
        .M_AXI_MCU_SB_AWQOS(caliptra_package_top_0_M_AXI_MCU_SB_AWQOS),
        .M_AXI_MCU_SB_AWREADY(caliptra_package_top_0_M_AXI_MCU_SB_AWREADY),
        .M_AXI_MCU_SB_AWSIZE(caliptra_package_top_0_M_AXI_MCU_SB_AWSIZE),
        .M_AXI_MCU_SB_AWUSER(caliptra_package_top_0_M_AXI_MCU_SB_AWUSER),
        .M_AXI_MCU_SB_AWVALID(caliptra_package_top_0_M_AXI_MCU_SB_AWVALID),
        .M_AXI_MCU_SB_BID(caliptra_package_top_0_M_AXI_MCU_SB_BID),
        .M_AXI_MCU_SB_BREADY(caliptra_package_top_0_M_AXI_MCU_SB_BREADY),
        .M_AXI_MCU_SB_BRESP(caliptra_package_top_0_M_AXI_MCU_SB_BRESP),
        .M_AXI_MCU_SB_BVALID(caliptra_package_top_0_M_AXI_MCU_SB_BVALID),
        .M_AXI_MCU_SB_RDATA(caliptra_package_top_0_M_AXI_MCU_SB_RDATA),
        .M_AXI_MCU_SB_RID(caliptra_package_top_0_M_AXI_MCU_SB_RID),
        .M_AXI_MCU_SB_RLAST(caliptra_package_top_0_M_AXI_MCU_SB_RLAST),
        .M_AXI_MCU_SB_RREADY(caliptra_package_top_0_M_AXI_MCU_SB_RREADY),
        .M_AXI_MCU_SB_RRESP(caliptra_package_top_0_M_AXI_MCU_SB_RRESP),
        .M_AXI_MCU_SB_RVALID(caliptra_package_top_0_M_AXI_MCU_SB_RVALID),
        .M_AXI_MCU_SB_WDATA(caliptra_package_top_0_M_AXI_MCU_SB_WDATA),
        .M_AXI_MCU_SB_WLAST(caliptra_package_top_0_M_AXI_MCU_SB_WLAST),
        .M_AXI_MCU_SB_WREADY(caliptra_package_top_0_M_AXI_MCU_SB_WREADY),
        .M_AXI_MCU_SB_WSTRB(caliptra_package_top_0_M_AXI_MCU_SB_WSTRB),
        .M_AXI_MCU_SB_WVALID(caliptra_package_top_0_M_AXI_MCU_SB_WVALID),
        .S_AXI_CALIPTRA_ARADDR(S_AXI_CALIPTRA_ARADDR),
        .S_AXI_CALIPTRA_ARBURST(S_AXI_CALIPTRA_ARBURST),
        .S_AXI_CALIPTRA_ARID({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .S_AXI_CALIPTRA_ARLEN(S_AXI_CALIPTRA_ARLEN),
        .S_AXI_CALIPTRA_ARLOCK(S_AXI_CALIPTRA_ARLOCK),
        .S_AXI_CALIPTRA_ARREADY(S_AXI_CALIPTRA_ARREADY),
        .S_AXI_CALIPTRA_ARSIZE(S_AXI_CALIPTRA_ARSIZE),
        .S_AXI_CALIPTRA_ARUSER(S_AXI_CALIPTRA_ARUSER),
        .S_AXI_CALIPTRA_ARVALID(S_AXI_CALIPTRA_ARVALID),
        .S_AXI_CALIPTRA_AWADDR(S_AXI_CALIPTRA_AWADDR),
        .S_AXI_CALIPTRA_AWBURST(S_AXI_CALIPTRA_AWBURST),
        .S_AXI_CALIPTRA_AWID({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .S_AXI_CALIPTRA_AWLEN(S_AXI_CALIPTRA_AWLEN),
        .S_AXI_CALIPTRA_AWLOCK(S_AXI_CALIPTRA_AWLOCK),
        .S_AXI_CALIPTRA_AWREADY(S_AXI_CALIPTRA_AWREADY),
        .S_AXI_CALIPTRA_AWSIZE(S_AXI_CALIPTRA_AWSIZE),
        .S_AXI_CALIPTRA_AWUSER(S_AXI_CALIPTRA_AWUSER),
        .S_AXI_CALIPTRA_AWVALID(S_AXI_CALIPTRA_AWVALID),
        .S_AXI_CALIPTRA_BREADY(S_AXI_CALIPTRA_BREADY),
        .S_AXI_CALIPTRA_BRESP(S_AXI_CALIPTRA_BRESP),
        .S_AXI_CALIPTRA_BVALID(S_AXI_CALIPTRA_BVALID),
        .S_AXI_CALIPTRA_RDATA(S_AXI_CALIPTRA_RDATA),
        .S_AXI_CALIPTRA_RLAST(S_AXI_CALIPTRA_RLAST),
        .S_AXI_CALIPTRA_RREADY(S_AXI_CALIPTRA_RREADY),
        .S_AXI_CALIPTRA_RRESP(S_AXI_CALIPTRA_RRESP),
        .S_AXI_CALIPTRA_RVALID(S_AXI_CALIPTRA_RVALID),
        .S_AXI_CALIPTRA_WDATA(S_AXI_CALIPTRA_WDATA),
        .S_AXI_CALIPTRA_WLAST(S_AXI_CALIPTRA_WLAST),
        .S_AXI_CALIPTRA_WREADY(S_AXI_CALIPTRA_WREADY),
        .S_AXI_CALIPTRA_WSTRB(S_AXI_CALIPTRA_WSTRB),
        .S_AXI_CALIPTRA_WVALID(S_AXI_CALIPTRA_WVALID),
        .S_AXI_I3C_ARADDR(S_AXI_I3C_ARADDR),
        .S_AXI_I3C_ARBURST(S_AXI_I3C_ARBURST),
        .S_AXI_I3C_ARID({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .S_AXI_I3C_ARLEN(S_AXI_I3C_ARLEN),
        .S_AXI_I3C_ARLOCK(S_AXI_I3C_ARLOCK),
        .S_AXI_I3C_ARPROT(S_AXI_I3C_ARPROT),
        .S_AXI_I3C_ARREADY(S_AXI_I3C_ARREADY),
        .S_AXI_I3C_ARSIZE(S_AXI_I3C_ARSIZE),
        .S_AXI_I3C_ARUSER(S_AXI_I3C_ARUSER),
        .S_AXI_I3C_ARVALID(S_AXI_I3C_ARVALID),
        .S_AXI_I3C_AWADDR(S_AXI_I3C_AWADDR),
        .S_AXI_I3C_AWBURST(S_AXI_I3C_AWBURST),
        .S_AXI_I3C_AWID({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .S_AXI_I3C_AWLEN(S_AXI_I3C_AWLEN),
        .S_AXI_I3C_AWLOCK(S_AXI_I3C_AWLOCK),
        .S_AXI_I3C_AWPROT(S_AXI_I3C_AWPROT),
        .S_AXI_I3C_AWREADY(S_AXI_I3C_AWREADY),
        .S_AXI_I3C_AWSIZE(S_AXI_I3C_AWSIZE),
        .S_AXI_I3C_AWUSER(S_AXI_I3C_AWUSER),
        .S_AXI_I3C_AWVALID(S_AXI_I3C_AWVALID),
        .S_AXI_I3C_BREADY(S_AXI_I3C_BREADY),
        .S_AXI_I3C_BRESP(S_AXI_I3C_BRESP),
        .S_AXI_I3C_BVALID(S_AXI_I3C_BVALID),
        .S_AXI_I3C_RDATA(S_AXI_I3C_RDATA),
        .S_AXI_I3C_RLAST(S_AXI_I3C_RLAST),
        .S_AXI_I3C_RREADY(S_AXI_I3C_RREADY),
        .S_AXI_I3C_RRESP(S_AXI_I3C_RRESP),
        .S_AXI_I3C_RVALID(S_AXI_I3C_RVALID),
        .S_AXI_I3C_SPARE_ARADDR(S_AXI_I3C_SPARE_ARADDR),
        .S_AXI_I3C_SPARE_ARBURST(S_AXI_I3C_SPARE_ARBURST),
        .S_AXI_I3C_SPARE_ARID({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .S_AXI_I3C_SPARE_ARLEN(S_AXI_I3C_SPARE_ARLEN),
        .S_AXI_I3C_SPARE_ARLOCK(S_AXI_I3C_SPARE_ARLOCK),
        .S_AXI_I3C_SPARE_ARREADY(S_AXI_I3C_SPARE_ARREADY),
        .S_AXI_I3C_SPARE_ARSIZE(S_AXI_I3C_SPARE_ARSIZE),
        .S_AXI_I3C_SPARE_ARUSER(S_AXI_I3C_SPARE_ARUSER),
        .S_AXI_I3C_SPARE_ARVALID(S_AXI_I3C_SPARE_ARVALID),
        .S_AXI_I3C_SPARE_AWADDR(S_AXI_I3C_SPARE_AWADDR),
        .S_AXI_I3C_SPARE_AWBURST(S_AXI_I3C_SPARE_AWBURST),
        .S_AXI_I3C_SPARE_AWID({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .S_AXI_I3C_SPARE_AWLEN(S_AXI_I3C_SPARE_AWLEN),
        .S_AXI_I3C_SPARE_AWLOCK(S_AXI_I3C_SPARE_AWLOCK),
        .S_AXI_I3C_SPARE_AWREADY(S_AXI_I3C_SPARE_AWREADY),
        .S_AXI_I3C_SPARE_AWSIZE(S_AXI_I3C_SPARE_AWSIZE),
        .S_AXI_I3C_SPARE_AWUSER(S_AXI_I3C_SPARE_AWUSER),
        .S_AXI_I3C_SPARE_AWVALID(S_AXI_I3C_SPARE_AWVALID),
        .S_AXI_I3C_SPARE_BREADY(S_AXI_I3C_SPARE_BREADY),
        .S_AXI_I3C_SPARE_BRESP(S_AXI_I3C_SPARE_BRESP),
        .S_AXI_I3C_SPARE_BVALID(S_AXI_I3C_SPARE_BVALID),
        .S_AXI_I3C_SPARE_RDATA(S_AXI_I3C_SPARE_RDATA),
        .S_AXI_I3C_SPARE_RLAST(S_AXI_I3C_SPARE_RLAST),
        .S_AXI_I3C_SPARE_RREADY(S_AXI_I3C_SPARE_RREADY),
        .S_AXI_I3C_SPARE_RRESP(S_AXI_I3C_SPARE_RRESP),
        .S_AXI_I3C_SPARE_RVALID(S_AXI_I3C_SPARE_RVALID),
        .S_AXI_I3C_SPARE_WDATA(S_AXI_I3C_SPARE_WDATA),
        .S_AXI_I3C_SPARE_WLAST(S_AXI_I3C_SPARE_WLAST),
        .S_AXI_I3C_SPARE_WREADY(S_AXI_I3C_SPARE_WREADY),
        .S_AXI_I3C_SPARE_WSTRB(S_AXI_I3C_SPARE_WSTRB),
        .S_AXI_I3C_SPARE_WVALID(S_AXI_I3C_SPARE_WVALID),
        .S_AXI_I3C_WDATA(S_AXI_I3C_WDATA),
        .S_AXI_I3C_WLAST(S_AXI_I3C_WLAST),
        .S_AXI_I3C_WREADY(S_AXI_I3C_WREADY),
        .S_AXI_I3C_WSTRB(S_AXI_I3C_WSTRB),
        .S_AXI_I3C_WVALID(S_AXI_I3C_WVALID),
        .S_AXI_LCC_ARADDR(S_AXI_LCC_ARADDR),
        .S_AXI_LCC_ARBURST(S_AXI_LCC_ARBURST),
        .S_AXI_LCC_ARID({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .S_AXI_LCC_ARLEN(S_AXI_LCC_ARLEN),
        .S_AXI_LCC_ARLOCK(S_AXI_LCC_ARLOCK),
        .S_AXI_LCC_ARPROT(S_AXI_LCC_ARPROT),
        .S_AXI_LCC_ARREADY(S_AXI_LCC_ARREADY),
        .S_AXI_LCC_ARSIZE(S_AXI_LCC_ARSIZE),
        .S_AXI_LCC_ARUSER(S_AXI_LCC_ARUSER),
        .S_AXI_LCC_ARVALID(S_AXI_LCC_ARVALID),
        .S_AXI_LCC_AWADDR(S_AXI_LCC_AWADDR),
        .S_AXI_LCC_AWBURST(S_AXI_LCC_AWBURST),
        .S_AXI_LCC_AWID({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .S_AXI_LCC_AWLEN(S_AXI_LCC_AWLEN),
        .S_AXI_LCC_AWLOCK(S_AXI_LCC_AWLOCK),
        .S_AXI_LCC_AWPROT(S_AXI_LCC_AWPROT),
        .S_AXI_LCC_AWREADY(S_AXI_LCC_AWREADY),
        .S_AXI_LCC_AWSIZE(S_AXI_LCC_AWSIZE),
        .S_AXI_LCC_AWUSER(S_AXI_LCC_AWUSER),
        .S_AXI_LCC_AWVALID(S_AXI_LCC_AWVALID),
        .S_AXI_LCC_BREADY(S_AXI_LCC_BREADY),
        .S_AXI_LCC_BRESP(S_AXI_LCC_BRESP),
        .S_AXI_LCC_BVALID(S_AXI_LCC_BVALID),
        .S_AXI_LCC_RDATA(S_AXI_LCC_RDATA),
        .S_AXI_LCC_RLAST(S_AXI_LCC_RLAST),
        .S_AXI_LCC_RREADY(S_AXI_LCC_RREADY),
        .S_AXI_LCC_RRESP(S_AXI_LCC_RRESP),
        .S_AXI_LCC_RVALID(S_AXI_LCC_RVALID),
        .S_AXI_LCC_WDATA(S_AXI_LCC_WDATA),
        .S_AXI_LCC_WLAST(S_AXI_LCC_WLAST),
        .S_AXI_LCC_WREADY(S_AXI_LCC_WREADY),
        .S_AXI_LCC_WSTRB(S_AXI_LCC_WSTRB),
        .S_AXI_LCC_WVALID(S_AXI_LCC_WVALID),
        .S_AXI_MCI_ARADDR(S_AXI_MCI_ARADDR),
        .S_AXI_MCI_ARBURST(S_AXI_MCI_ARBURST),
        .S_AXI_MCI_ARID({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .S_AXI_MCI_ARLEN(S_AXI_MCI_ARLEN),
        .S_AXI_MCI_ARLOCK(S_AXI_MCI_ARLOCK),
        .S_AXI_MCI_ARREADY(S_AXI_MCI_ARREADY),
        .S_AXI_MCI_ARSIZE(S_AXI_MCI_ARSIZE),
        .S_AXI_MCI_ARUSER(S_AXI_MCI_ARUSER),
        .S_AXI_MCI_ARVALID(S_AXI_MCI_ARVALID),
        .S_AXI_MCI_AWADDR(S_AXI_MCI_AWADDR),
        .S_AXI_MCI_AWBURST(S_AXI_MCI_AWBURST),
        .S_AXI_MCI_AWID({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .S_AXI_MCI_AWLEN(S_AXI_MCI_AWLEN),
        .S_AXI_MCI_AWLOCK(S_AXI_MCI_AWLOCK),
        .S_AXI_MCI_AWREADY(S_AXI_MCI_AWREADY),
        .S_AXI_MCI_AWSIZE(S_AXI_MCI_AWSIZE),
        .S_AXI_MCI_AWUSER(S_AXI_MCI_AWUSER),
        .S_AXI_MCI_AWVALID(S_AXI_MCI_AWVALID),
        .S_AXI_MCI_BREADY(S_AXI_MCI_BREADY),
        .S_AXI_MCI_BRESP(S_AXI_MCI_BRESP),
        .S_AXI_MCI_BVALID(S_AXI_MCI_BVALID),
        .S_AXI_MCI_RDATA(S_AXI_MCI_RDATA),
        .S_AXI_MCI_RLAST(S_AXI_MCI_RLAST),
        .S_AXI_MCI_RREADY(S_AXI_MCI_RREADY),
        .S_AXI_MCI_RRESP(S_AXI_MCI_RRESP),
        .S_AXI_MCI_RVALID(S_AXI_MCI_RVALID),
        .S_AXI_MCI_WDATA(S_AXI_MCI_WDATA),
        .S_AXI_MCI_WLAST(S_AXI_MCI_WLAST),
        .S_AXI_MCI_WREADY(S_AXI_MCI_WREADY),
        .S_AXI_MCI_WSTRB(S_AXI_MCI_WSTRB),
        .S_AXI_MCI_WVALID(S_AXI_MCI_WVALID),
        .S_AXI_MCU_ROM_ARADDR(S_AXI_MCU_ROM_ARADDR),
        .S_AXI_MCU_ROM_ARBURST(S_AXI_MCU_ROM_ARBURST),
        .S_AXI_MCU_ROM_ARID({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .S_AXI_MCU_ROM_ARLEN(S_AXI_MCU_ROM_ARLEN),
        .S_AXI_MCU_ROM_ARLOCK(S_AXI_MCU_ROM_ARLOCK),
        .S_AXI_MCU_ROM_ARREADY(S_AXI_MCU_ROM_ARREADY),
        .S_AXI_MCU_ROM_ARSIZE(S_AXI_MCU_ROM_ARSIZE),
        .S_AXI_MCU_ROM_ARUSER(S_AXI_MCU_ROM_ARUSER),
        .S_AXI_MCU_ROM_ARVALID(S_AXI_MCU_ROM_ARVALID),
        .S_AXI_MCU_ROM_AWADDR(S_AXI_MCU_ROM_AWADDR),
        .S_AXI_MCU_ROM_AWBURST(S_AXI_MCU_ROM_AWBURST),
        .S_AXI_MCU_ROM_AWID({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .S_AXI_MCU_ROM_AWLEN(S_AXI_MCU_ROM_AWLEN),
        .S_AXI_MCU_ROM_AWLOCK(S_AXI_MCU_ROM_AWLOCK),
        .S_AXI_MCU_ROM_AWREADY(S_AXI_MCU_ROM_AWREADY),
        .S_AXI_MCU_ROM_AWSIZE(S_AXI_MCU_ROM_AWSIZE),
        .S_AXI_MCU_ROM_AWUSER(S_AXI_MCU_ROM_AWUSER),
        .S_AXI_MCU_ROM_AWVALID(S_AXI_MCU_ROM_AWVALID),
        .S_AXI_MCU_ROM_BREADY(S_AXI_MCU_ROM_BREADY),
        .S_AXI_MCU_ROM_BRESP(S_AXI_MCU_ROM_BRESP),
        .S_AXI_MCU_ROM_BVALID(S_AXI_MCU_ROM_BVALID),
        .S_AXI_MCU_ROM_RDATA(S_AXI_MCU_ROM_RDATA),
        .S_AXI_MCU_ROM_RLAST(S_AXI_MCU_ROM_RLAST),
        .S_AXI_MCU_ROM_RREADY(S_AXI_MCU_ROM_RREADY),
        .S_AXI_MCU_ROM_RRESP(S_AXI_MCU_ROM_RRESP),
        .S_AXI_MCU_ROM_RVALID(S_AXI_MCU_ROM_RVALID),
        .S_AXI_MCU_ROM_WDATA(S_AXI_MCU_ROM_WDATA),
        .S_AXI_MCU_ROM_WLAST(S_AXI_MCU_ROM_WLAST),
        .S_AXI_MCU_ROM_WREADY(S_AXI_MCU_ROM_WREADY),
        .S_AXI_MCU_ROM_WSTRB(S_AXI_MCU_ROM_WSTRB),
        .S_AXI_MCU_ROM_WVALID(S_AXI_MCU_ROM_WVALID),
        .S_AXI_OTP_ARADDR(S_AXI_OTP_ARADDR),
        .S_AXI_OTP_ARBURST(S_AXI_OTP_ARBURST),
        .S_AXI_OTP_ARID({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .S_AXI_OTP_ARLEN(S_AXI_OTP_ARLEN),
        .S_AXI_OTP_ARLOCK(S_AXI_OTP_ARLOCK),
        .S_AXI_OTP_ARPROT(S_AXI_OTP_ARPROT),
        .S_AXI_OTP_ARREADY(S_AXI_OTP_ARREADY),
        .S_AXI_OTP_ARSIZE(S_AXI_OTP_ARSIZE),
        .S_AXI_OTP_ARUSER(S_AXI_OTP_ARUSER),
        .S_AXI_OTP_ARVALID(S_AXI_OTP_ARVALID),
        .S_AXI_OTP_AWADDR(S_AXI_OTP_AWADDR),
        .S_AXI_OTP_AWBURST(S_AXI_OTP_AWBURST),
        .S_AXI_OTP_AWID({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .S_AXI_OTP_AWLEN(S_AXI_OTP_AWLEN),
        .S_AXI_OTP_AWLOCK(S_AXI_OTP_AWLOCK),
        .S_AXI_OTP_AWPROT(S_AXI_OTP_AWPROT),
        .S_AXI_OTP_AWREADY(S_AXI_OTP_AWREADY),
        .S_AXI_OTP_AWSIZE(S_AXI_OTP_AWSIZE),
        .S_AXI_OTP_AWUSER(S_AXI_OTP_AWUSER),
        .S_AXI_OTP_AWVALID(S_AXI_OTP_AWVALID),
        .S_AXI_OTP_BREADY(S_AXI_OTP_BREADY),
        .S_AXI_OTP_BRESP(S_AXI_OTP_BRESP),
        .S_AXI_OTP_BVALID(S_AXI_OTP_BVALID),
        .S_AXI_OTP_RDATA(S_AXI_OTP_RDATA),
        .S_AXI_OTP_RLAST(S_AXI_OTP_RLAST),
        .S_AXI_OTP_RREADY(S_AXI_OTP_RREADY),
        .S_AXI_OTP_RRESP(S_AXI_OTP_RRESP),
        .S_AXI_OTP_RVALID(S_AXI_OTP_RVALID),
        .S_AXI_OTP_WDATA(S_AXI_OTP_WDATA),
        .S_AXI_OTP_WLAST(S_AXI_OTP_WLAST),
        .S_AXI_OTP_WREADY(S_AXI_OTP_WREADY),
        .S_AXI_OTP_WSTRB(S_AXI_OTP_WSTRB),
        .S_AXI_OTP_WVALID(S_AXI_OTP_WVALID),
        .S_AXI_USB_DEV_ARADDR(S_AXI_USB_DEV_ARADDR),
        .S_AXI_USB_DEV_ARBURST(S_AXI_USB_DEV_ARBURST),
        .S_AXI_USB_DEV_ARID({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .S_AXI_USB_DEV_ARLEN(S_AXI_USB_DEV_ARLEN),
        .S_AXI_USB_DEV_ARLOCK(S_AXI_USB_DEV_ARLOCK),
        .S_AXI_USB_DEV_ARREADY(S_AXI_USB_DEV_ARREADY),
        .S_AXI_USB_DEV_ARSIZE(S_AXI_USB_DEV_ARSIZE),
        .S_AXI_USB_DEV_ARUSER(S_AXI_USB_DEV_ARUSER),
        .S_AXI_USB_DEV_ARVALID(S_AXI_USB_DEV_ARVALID),
        .S_AXI_USB_DEV_AWADDR(S_AXI_USB_DEV_AWADDR),
        .S_AXI_USB_DEV_AWBURST(S_AXI_USB_DEV_AWBURST),
        .S_AXI_USB_DEV_AWID({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .S_AXI_USB_DEV_AWLEN(S_AXI_USB_DEV_AWLEN),
        .S_AXI_USB_DEV_AWLOCK(S_AXI_USB_DEV_AWLOCK),
        .S_AXI_USB_DEV_AWREADY(S_AXI_USB_DEV_AWREADY),
        .S_AXI_USB_DEV_AWSIZE(S_AXI_USB_DEV_AWSIZE),
        .S_AXI_USB_DEV_AWUSER(S_AXI_USB_DEV_AWUSER),
        .S_AXI_USB_DEV_AWVALID(S_AXI_USB_DEV_AWVALID),
        .S_AXI_USB_DEV_BREADY(S_AXI_USB_DEV_BREADY),
        .S_AXI_USB_DEV_BRESP(S_AXI_USB_DEV_BRESP),
        .S_AXI_USB_DEV_BVALID(S_AXI_USB_DEV_BVALID),
        .S_AXI_USB_DEV_RDATA(S_AXI_USB_DEV_RDATA),
        .S_AXI_USB_DEV_RLAST(S_AXI_USB_DEV_RLAST),
        .S_AXI_USB_DEV_RREADY(S_AXI_USB_DEV_RREADY),
        .S_AXI_USB_DEV_RRESP(S_AXI_USB_DEV_RRESP),
        .S_AXI_USB_DEV_RVALID(S_AXI_USB_DEV_RVALID),
        .S_AXI_USB_DEV_WDATA(S_AXI_USB_DEV_WDATA),
        .S_AXI_USB_DEV_WLAST(S_AXI_USB_DEV_WLAST),
        .S_AXI_USB_DEV_WREADY(S_AXI_USB_DEV_WREADY),
        .S_AXI_USB_DEV_WSTRB(S_AXI_USB_DEV_WSTRB),
        .S_AXI_USB_DEV_WVALID(S_AXI_USB_DEV_WVALID),
        .S_AXI_USB_DMA_ARADDR(S_AXI_USB_DMA_ARADDR),
        .S_AXI_USB_DMA_ARBURST(S_AXI_USB_DMA_ARBURST),
        .S_AXI_USB_DMA_ARID({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .S_AXI_USB_DMA_ARLEN(S_AXI_USB_DMA_ARLEN),
        .S_AXI_USB_DMA_ARLOCK(S_AXI_USB_DMA_ARLOCK),
        .S_AXI_USB_DMA_ARREADY(S_AXI_USB_DMA_ARREADY),
        .S_AXI_USB_DMA_ARSIZE(S_AXI_USB_DMA_ARSIZE),
        .S_AXI_USB_DMA_ARUSER(S_AXI_USB_DMA_ARUSER),
        .S_AXI_USB_DMA_ARVALID(S_AXI_USB_DMA_ARVALID),
        .S_AXI_USB_DMA_AWADDR(S_AXI_USB_DMA_AWADDR),
        .S_AXI_USB_DMA_AWBURST(S_AXI_USB_DMA_AWBURST),
        .S_AXI_USB_DMA_AWID({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .S_AXI_USB_DMA_AWLEN(S_AXI_USB_DMA_AWLEN),
        .S_AXI_USB_DMA_AWLOCK(S_AXI_USB_DMA_AWLOCK),
        .S_AXI_USB_DMA_AWREADY(S_AXI_USB_DMA_AWREADY),
        .S_AXI_USB_DMA_AWSIZE(S_AXI_USB_DMA_AWSIZE),
        .S_AXI_USB_DMA_AWUSER(S_AXI_USB_DMA_AWUSER),
        .S_AXI_USB_DMA_AWVALID(S_AXI_USB_DMA_AWVALID),
        .S_AXI_USB_DMA_BREADY(S_AXI_USB_DMA_BREADY),
        .S_AXI_USB_DMA_BRESP(S_AXI_USB_DMA_BRESP),
        .S_AXI_USB_DMA_BVALID(S_AXI_USB_DMA_BVALID),
        .S_AXI_USB_DMA_RDATA(S_AXI_USB_DMA_RDATA),
        .S_AXI_USB_DMA_RLAST(S_AXI_USB_DMA_RLAST),
        .S_AXI_USB_DMA_RREADY(S_AXI_USB_DMA_RREADY),
        .S_AXI_USB_DMA_RRESP(S_AXI_USB_DMA_RRESP),
        .S_AXI_USB_DMA_RVALID(S_AXI_USB_DMA_RVALID),
        .S_AXI_USB_DMA_WDATA(S_AXI_USB_DMA_WDATA),
        .S_AXI_USB_DMA_WLAST(S_AXI_USB_DMA_WLAST),
        .S_AXI_USB_DMA_WREADY(S_AXI_USB_DMA_WREADY),
        .S_AXI_USB_DMA_WSTRB(S_AXI_USB_DMA_WSTRB),
        .S_AXI_USB_DMA_WVALID(S_AXI_USB_DMA_WVALID),
        .S_AXI_USB_HOST_ARADDR(S_AXI_USB_HOST_ARADDR),
        .S_AXI_USB_HOST_ARBURST(S_AXI_USB_HOST_ARBURST),
        .S_AXI_USB_HOST_ARID({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .S_AXI_USB_HOST_ARLEN(S_AXI_USB_HOST_ARLEN),
        .S_AXI_USB_HOST_ARLOCK(S_AXI_USB_HOST_ARLOCK),
        .S_AXI_USB_HOST_ARREADY(S_AXI_USB_HOST_ARREADY),
        .S_AXI_USB_HOST_ARSIZE(S_AXI_USB_HOST_ARSIZE),
        .S_AXI_USB_HOST_ARUSER(S_AXI_USB_HOST_ARUSER),
        .S_AXI_USB_HOST_ARVALID(S_AXI_USB_HOST_ARVALID),
        .S_AXI_USB_HOST_AWADDR(S_AXI_USB_HOST_AWADDR),
        .S_AXI_USB_HOST_AWBURST(S_AXI_USB_HOST_AWBURST),
        .S_AXI_USB_HOST_AWID({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .S_AXI_USB_HOST_AWLEN(S_AXI_USB_HOST_AWLEN),
        .S_AXI_USB_HOST_AWLOCK(S_AXI_USB_HOST_AWLOCK),
        .S_AXI_USB_HOST_AWREADY(S_AXI_USB_HOST_AWREADY),
        .S_AXI_USB_HOST_AWSIZE(S_AXI_USB_HOST_AWSIZE),
        .S_AXI_USB_HOST_AWUSER(S_AXI_USB_HOST_AWUSER),
        .S_AXI_USB_HOST_AWVALID(S_AXI_USB_HOST_AWVALID),
        .S_AXI_USB_HOST_BREADY(S_AXI_USB_HOST_BREADY),
        .S_AXI_USB_HOST_BRESP(S_AXI_USB_HOST_BRESP),
        .S_AXI_USB_HOST_BVALID(S_AXI_USB_HOST_BVALID),
        .S_AXI_USB_HOST_RDATA(S_AXI_USB_HOST_RDATA),
        .S_AXI_USB_HOST_RLAST(S_AXI_USB_HOST_RLAST),
        .S_AXI_USB_HOST_RREADY(S_AXI_USB_HOST_RREADY),
        .S_AXI_USB_HOST_RRESP(S_AXI_USB_HOST_RRESP),
        .S_AXI_USB_HOST_RVALID(S_AXI_USB_HOST_RVALID),
        .S_AXI_USB_HOST_WDATA(S_AXI_USB_HOST_WDATA),
        .S_AXI_USB_HOST_WLAST(S_AXI_USB_HOST_WLAST),
        .S_AXI_USB_HOST_WREADY(S_AXI_USB_HOST_WREADY),
        .S_AXI_USB_HOST_WSTRB(S_AXI_USB_HOST_WSTRB),
        .S_AXI_USB_HOST_WVALID(S_AXI_USB_HOST_WVALID),
        .S_AXI_WRAPPER_ARADDR(S_AXI_WRAPPER_ARADDR),
        .S_AXI_WRAPPER_ARESETN(board_reset_n),
        .S_AXI_WRAPPER_ARPROT(S_AXI_WRAPPER_ARPROT),
        .S_AXI_WRAPPER_ARREADY(S_AXI_WRAPPER_ARREADY),
        .S_AXI_WRAPPER_ARVALID(S_AXI_WRAPPER_ARVALID),
        .S_AXI_WRAPPER_AWADDR(S_AXI_WRAPPER_AWADDR),
        .S_AXI_WRAPPER_AWPROT(S_AXI_WRAPPER_AWPROT),
        .S_AXI_WRAPPER_AWREADY(S_AXI_WRAPPER_AWREADY),
        .S_AXI_WRAPPER_AWVALID(S_AXI_WRAPPER_AWVALID),
        .S_AXI_WRAPPER_BREADY(S_AXI_WRAPPER_BREADY),
        .S_AXI_WRAPPER_BRESP(S_AXI_WRAPPER_BRESP),
        .S_AXI_WRAPPER_BVALID(S_AXI_WRAPPER_BVALID),
        .S_AXI_WRAPPER_RDATA(S_AXI_WRAPPER_RDATA),
        .S_AXI_WRAPPER_RREADY(S_AXI_WRAPPER_RREADY),
        .S_AXI_WRAPPER_RRESP(S_AXI_WRAPPER_RRESP),
        .S_AXI_WRAPPER_RVALID(S_AXI_WRAPPER_RVALID),
        .S_AXI_WRAPPER_WDATA(S_AXI_WRAPPER_WDATA),
        .S_AXI_WRAPPER_WREADY(S_AXI_WRAPPER_WREADY),
        .S_AXI_WRAPPER_WSTRB(S_AXI_WRAPPER_WSTRB),
        .S_AXI_WRAPPER_WVALID(S_AXI_WRAPPER_WVALID),
        .USB_ULPI_CLK(USB_ULPI_CLK),
        .USB_ULPI_DATA(USB_ULPI_DATA),
        .USB_ULPI_DIR(USB_ULPI_DIR),
        .USB_ULPI_NXT(USB_ULPI_NXT),
        .USB_ULPI_STP(USB_ULPI_STP),
        .board_core_log_byte(board_core_log_byte),
        .board_core_log_valid(board_core_log_valid),
        .board_entropy_data(host_entropy_data),
        .board_entropy_req(host_entropy_req),
        .board_entropy_valid(host_entropy_valid),
        .board_mcu_log_byte(board_mcu_log_byte),
        .board_mcu_log_valid(board_mcu_log_valid),
        .core_clk(board_core_clk),
        .i3c_clk(htg940_clocks_clk_out2),
        .jtag_in(jtag_in),
        .jtag_out(jtag_out),
        .mcu_rom_backdoor_addr({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,mcu_rom_backdoor_bram_0_BRAM_PORTA_ADDR}),
        .mcu_rom_backdoor_clk(mcu_rom_backdoor_bram_0_BRAM_PORTA_CLK),
        .mcu_rom_backdoor_din(mcu_rom_backdoor_bram_0_BRAM_PORTA_DIN),
        .mcu_rom_backdoor_dout(mcu_rom_backdoor_bram_0_BRAM_PORTA_DOUT),
        .mcu_rom_backdoor_en(mcu_rom_backdoor_bram_0_BRAM_PORTA_EN),
        .mcu_rom_backdoor_rst(mcu_rom_backdoor_bram_0_BRAM_PORTA_RST),
        .mcu_rom_backdoor_we(mcu_rom_backdoor_bram_0_BRAM_PORTA_WE),
        .otp_mem_backdoor_addr({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,otp_ram_bram_ctrl_0_BRAM_PORTA_ADDR}),
        .otp_mem_backdoor_clk(otp_ram_bram_ctrl_0_BRAM_PORTA_CLK),
        .otp_mem_backdoor_din(otp_ram_bram_ctrl_0_BRAM_PORTA_DIN),
        .otp_mem_backdoor_dout(otp_ram_bram_ctrl_0_BRAM_PORTA_DOUT),
        .otp_mem_backdoor_en(otp_ram_bram_ctrl_0_BRAM_PORTA_EN),
        .otp_mem_backdoor_rst(otp_ram_bram_ctrl_0_BRAM_PORTA_RST),
        .otp_mem_backdoor_we(otp_ram_bram_ctrl_0_BRAM_PORTA_WE[0]),
        .rom_backdoor_addr(cptra_rom_backdoor_bram_0_BRAM_PORTA_ADDR),
        .rom_backdoor_clk(cptra_rom_backdoor_bram_0_BRAM_PORTA_CLK),
        .rom_backdoor_din(cptra_rom_backdoor_bram_0_BRAM_PORTA_DIN),
        .rom_backdoor_dout(cptra_rom_backdoor_bram_0_BRAM_PORTA_DOUT),
        .rom_backdoor_en(cptra_rom_backdoor_bram_0_BRAM_PORTA_EN),
        .rom_backdoor_rst(cptra_rom_backdoor_bram_0_BRAM_PORTA_RST),
        .rom_backdoor_we(cptra_rom_backdoor_bram_0_BRAM_PORTA_WE),
        .xilinx_i3c_aresetn(caliptra_package_top_0_xilinx_i3c_aresetn),
        .xilinx_scl(caliptra_package_top_0_xilinx_scl),
        .xilinx_scl_o(xilinx_i3c_0_scl_o),
        .xilinx_scl_pullup_en(xilinx_i3c_0_scl_pullup_en),
        .xilinx_scl_t(xilinx_i3c_0_scl_t),
        .xilinx_sda(caliptra_package_top_0_xilinx_sda),
        .xilinx_sda_o(xilinx_i3c_0_sda_o),
        .xilinx_sda_pullup_en(xilinx_i3c_0_sda_pullup_en),
        .xilinx_sda_t(xilinx_i3c_0_sda_t));
  caliptra_htg940_bd_cptra_rom_backdoor_bram_0_0 cptra_rom_backdoor_bram_0
       (.bram_addr_a(cptra_rom_backdoor_bram_0_BRAM_PORTA_ADDR),
        .bram_clk_a(cptra_rom_backdoor_bram_0_BRAM_PORTA_CLK),
        .bram_en_a(cptra_rom_backdoor_bram_0_BRAM_PORTA_EN),
        .bram_rddata_a(cptra_rom_backdoor_bram_0_BRAM_PORTA_DOUT),
        .bram_rst_a(cptra_rom_backdoor_bram_0_BRAM_PORTA_RST),
        .bram_we_a(cptra_rom_backdoor_bram_0_BRAM_PORTA_WE),
        .bram_wrdata_a(cptra_rom_backdoor_bram_0_BRAM_PORTA_DIN),
        .s_axi_aclk(board_core_clk),
        .s_axi_araddr(S_AXI_CALIPTRA_ROM_ARADDR),
        .s_axi_arburst(S_AXI_CALIPTRA_ROM_ARBURST),
        .s_axi_arcache(S_AXI_CALIPTRA_ROM_ARCACHE),
        .s_axi_aresetn(board_reset_n),
        .s_axi_arlen(S_AXI_CALIPTRA_ROM_ARLEN),
        .s_axi_arlock(S_AXI_CALIPTRA_ROM_ARLOCK),
        .s_axi_arprot(S_AXI_CALIPTRA_ROM_ARPROT),
        .s_axi_arready(S_AXI_CALIPTRA_ROM_ARREADY),
        .s_axi_arsize(S_AXI_CALIPTRA_ROM_ARSIZE),
        .s_axi_arvalid(S_AXI_CALIPTRA_ROM_ARVALID),
        .s_axi_awaddr(S_AXI_CALIPTRA_ROM_AWADDR),
        .s_axi_awburst(S_AXI_CALIPTRA_ROM_AWBURST),
        .s_axi_awcache(S_AXI_CALIPTRA_ROM_AWCACHE),
        .s_axi_awlen(S_AXI_CALIPTRA_ROM_AWLEN),
        .s_axi_awlock(S_AXI_CALIPTRA_ROM_AWLOCK),
        .s_axi_awprot(S_AXI_CALIPTRA_ROM_AWPROT),
        .s_axi_awready(S_AXI_CALIPTRA_ROM_AWREADY),
        .s_axi_awsize(S_AXI_CALIPTRA_ROM_AWSIZE),
        .s_axi_awvalid(S_AXI_CALIPTRA_ROM_AWVALID),
        .s_axi_bready(S_AXI_CALIPTRA_ROM_BREADY),
        .s_axi_bresp(S_AXI_CALIPTRA_ROM_BRESP),
        .s_axi_bvalid(S_AXI_CALIPTRA_ROM_BVALID),
        .s_axi_rdata(S_AXI_CALIPTRA_ROM_RDATA),
        .s_axi_rlast(S_AXI_CALIPTRA_ROM_RLAST),
        .s_axi_rready(S_AXI_CALIPTRA_ROM_RREADY),
        .s_axi_rresp(S_AXI_CALIPTRA_ROM_RRESP),
        .s_axi_rvalid(S_AXI_CALIPTRA_ROM_RVALID),
        .s_axi_wdata(S_AXI_CALIPTRA_ROM_WDATA),
        .s_axi_wlast(S_AXI_CALIPTRA_ROM_WLAST),
        .s_axi_wready(S_AXI_CALIPTRA_ROM_WREADY),
        .s_axi_wstrb(S_AXI_CALIPTRA_ROM_WSTRB),
        .s_axi_wvalid(S_AXI_CALIPTRA_ROM_WVALID));
  caliptra_htg940_bd_firmware_byte_to_word_0_0 firmware_byte_to_word_0
       (.Din(firmware_flash_bram_ctrl_0_bram_addr_a),
        .Dout(firmware_byte_to_word_0_Dout));
  caliptra_htg940_bd_firmware_flash_bram_ctrl_0_0 firmware_flash_bram_ctrl_0
       (.bram_addr_a(firmware_flash_bram_ctrl_0_bram_addr_a),
        .bram_clk_a(firmware_flash_bram_ctrl_0_bram_clk_a),
        .bram_en_a(firmware_flash_bram_ctrl_0_bram_en_a),
        .bram_rddata_a(firmware_flash_mem_0_douta),
        .bram_we_a(firmware_flash_bram_ctrl_0_bram_we_a),
        .bram_wrdata_a(firmware_flash_bram_ctrl_0_bram_wrdata_a),
        .s_axi_aclk(board_core_clk),
        .s_axi_araddr(S_AXI_FIRMWARE_FLASH_ARADDR),
        .s_axi_arburst(S_AXI_FIRMWARE_FLASH_ARBURST),
        .s_axi_arcache(S_AXI_FIRMWARE_FLASH_ARCACHE),
        .s_axi_aresetn(board_reset_n),
        .s_axi_arlen(S_AXI_FIRMWARE_FLASH_ARLEN),
        .s_axi_arlock(S_AXI_FIRMWARE_FLASH_ARLOCK),
        .s_axi_arprot(S_AXI_FIRMWARE_FLASH_ARPROT),
        .s_axi_arready(S_AXI_FIRMWARE_FLASH_ARREADY),
        .s_axi_arsize(S_AXI_FIRMWARE_FLASH_ARSIZE),
        .s_axi_arvalid(S_AXI_FIRMWARE_FLASH_ARVALID),
        .s_axi_awaddr(S_AXI_FIRMWARE_FLASH_AWADDR),
        .s_axi_awburst(S_AXI_FIRMWARE_FLASH_AWBURST),
        .s_axi_awcache(S_AXI_FIRMWARE_FLASH_AWCACHE),
        .s_axi_awlen(S_AXI_FIRMWARE_FLASH_AWLEN),
        .s_axi_awlock(S_AXI_FIRMWARE_FLASH_AWLOCK),
        .s_axi_awprot(S_AXI_FIRMWARE_FLASH_AWPROT),
        .s_axi_awready(S_AXI_FIRMWARE_FLASH_AWREADY),
        .s_axi_awsize(S_AXI_FIRMWARE_FLASH_AWSIZE),
        .s_axi_awvalid(S_AXI_FIRMWARE_FLASH_AWVALID),
        .s_axi_bready(S_AXI_FIRMWARE_FLASH_BREADY),
        .s_axi_bresp(S_AXI_FIRMWARE_FLASH_BRESP),
        .s_axi_bvalid(S_AXI_FIRMWARE_FLASH_BVALID),
        .s_axi_rdata(S_AXI_FIRMWARE_FLASH_RDATA),
        .s_axi_rlast(S_AXI_FIRMWARE_FLASH_RLAST),
        .s_axi_rready(S_AXI_FIRMWARE_FLASH_RREADY),
        .s_axi_rresp(S_AXI_FIRMWARE_FLASH_RRESP),
        .s_axi_rvalid(S_AXI_FIRMWARE_FLASH_RVALID),
        .s_axi_wdata(S_AXI_FIRMWARE_FLASH_WDATA),
        .s_axi_wlast(S_AXI_FIRMWARE_FLASH_WLAST),
        .s_axi_wready(S_AXI_FIRMWARE_FLASH_WREADY),
        .s_axi_wstrb(S_AXI_FIRMWARE_FLASH_WSTRB),
        .s_axi_wvalid(S_AXI_FIRMWARE_FLASH_WVALID));
  caliptra_htg940_bd_firmware_flash_mem_0_0 firmware_flash_mem_0
       (.addra(firmware_byte_to_word_0_Dout),
        .clka(firmware_flash_bram_ctrl_0_bram_clk_a),
        .dina(firmware_flash_bram_ctrl_0_bram_wrdata_a),
        .douta(firmware_flash_mem_0_douta),
        .ena(firmware_flash_bram_ctrl_0_bram_en_a),
        .wea(firmware_flash_bram_ctrl_0_bram_we_a));
  caliptra_htg940_bd_htg940_clocks_0 htg940_clocks
       (.clk_in1_n(ref_clock_156p25mhz_clk_n),
        .clk_in1_p(ref_clock_156p25mhz_clk_p),
        .clk_out1(board_core_clk),
        .clk_out2(htg940_clocks_clk_out2),
        .locked(board_clock_locked),
        .resetn(reset_n));
  caliptra_htg940_bd_mcu_rom_backdoor_bram_0_0 mcu_rom_backdoor_bram_0
       (.bram_addr_a(mcu_rom_backdoor_bram_0_BRAM_PORTA_ADDR),
        .bram_clk_a(mcu_rom_backdoor_bram_0_BRAM_PORTA_CLK),
        .bram_en_a(mcu_rom_backdoor_bram_0_BRAM_PORTA_EN),
        .bram_rddata_a(mcu_rom_backdoor_bram_0_BRAM_PORTA_DOUT),
        .bram_rst_a(mcu_rom_backdoor_bram_0_BRAM_PORTA_RST),
        .bram_we_a(mcu_rom_backdoor_bram_0_BRAM_PORTA_WE),
        .bram_wrdata_a(mcu_rom_backdoor_bram_0_BRAM_PORTA_DIN),
        .s_axi_aclk(board_core_clk),
        .s_axi_araddr(S_AXI_SS_ROM_ARADDR),
        .s_axi_arburst(S_AXI_SS_ROM_ARBURST),
        .s_axi_arcache(S_AXI_SS_ROM_ARCACHE),
        .s_axi_aresetn(board_reset_n),
        .s_axi_arlen(S_AXI_SS_ROM_ARLEN),
        .s_axi_arlock(S_AXI_SS_ROM_ARLOCK),
        .s_axi_arprot(S_AXI_SS_ROM_ARPROT),
        .s_axi_arready(S_AXI_SS_ROM_ARREADY),
        .s_axi_arsize(S_AXI_SS_ROM_ARSIZE),
        .s_axi_arvalid(S_AXI_SS_ROM_ARVALID),
        .s_axi_awaddr(S_AXI_SS_ROM_AWADDR),
        .s_axi_awburst(S_AXI_SS_ROM_AWBURST),
        .s_axi_awcache(S_AXI_SS_ROM_AWCACHE),
        .s_axi_awlen(S_AXI_SS_ROM_AWLEN),
        .s_axi_awlock(S_AXI_SS_ROM_AWLOCK),
        .s_axi_awprot(S_AXI_SS_ROM_AWPROT),
        .s_axi_awready(S_AXI_SS_ROM_AWREADY),
        .s_axi_awsize(S_AXI_SS_ROM_AWSIZE),
        .s_axi_awvalid(S_AXI_SS_ROM_AWVALID),
        .s_axi_bready(S_AXI_SS_ROM_BREADY),
        .s_axi_bresp(S_AXI_SS_ROM_BRESP),
        .s_axi_bvalid(S_AXI_SS_ROM_BVALID),
        .s_axi_rdata(S_AXI_SS_ROM_RDATA),
        .s_axi_rlast(S_AXI_SS_ROM_RLAST),
        .s_axi_rready(S_AXI_SS_ROM_RREADY),
        .s_axi_rresp(S_AXI_SS_ROM_RRESP),
        .s_axi_rvalid(S_AXI_SS_ROM_RVALID),
        .s_axi_wdata(S_AXI_SS_ROM_WDATA),
        .s_axi_wlast(S_AXI_SS_ROM_WLAST),
        .s_axi_wready(S_AXI_SS_ROM_WREADY),
        .s_axi_wstrb(S_AXI_SS_ROM_WSTRB),
        .s_axi_wvalid(S_AXI_SS_ROM_WVALID));
  caliptra_htg940_bd_otp_ram_bram_ctrl_0_0 otp_ram_bram_ctrl_0
       (.bram_addr_a(otp_ram_bram_ctrl_0_BRAM_PORTA_ADDR),
        .bram_clk_a(otp_ram_bram_ctrl_0_BRAM_PORTA_CLK),
        .bram_en_a(otp_ram_bram_ctrl_0_BRAM_PORTA_EN),
        .bram_rddata_a(otp_ram_bram_ctrl_0_BRAM_PORTA_DOUT),
        .bram_rst_a(otp_ram_bram_ctrl_0_BRAM_PORTA_RST),
        .bram_we_a(otp_ram_bram_ctrl_0_BRAM_PORTA_WE),
        .bram_wrdata_a(otp_ram_bram_ctrl_0_BRAM_PORTA_DIN),
        .s_axi_aclk(board_core_clk),
        .s_axi_araddr(S_AXI_OTP_RAM_ARADDR),
        .s_axi_arburst(S_AXI_OTP_RAM_ARBURST),
        .s_axi_arcache(S_AXI_OTP_RAM_ARCACHE),
        .s_axi_aresetn(board_reset_n),
        .s_axi_arlen(S_AXI_OTP_RAM_ARLEN),
        .s_axi_arlock(S_AXI_OTP_RAM_ARLOCK),
        .s_axi_arprot(S_AXI_OTP_RAM_ARPROT),
        .s_axi_arready(S_AXI_OTP_RAM_ARREADY),
        .s_axi_arsize(S_AXI_OTP_RAM_ARSIZE),
        .s_axi_arvalid(S_AXI_OTP_RAM_ARVALID),
        .s_axi_awaddr(S_AXI_OTP_RAM_AWADDR),
        .s_axi_awburst(S_AXI_OTP_RAM_AWBURST),
        .s_axi_awcache(S_AXI_OTP_RAM_AWCACHE),
        .s_axi_awlen(S_AXI_OTP_RAM_AWLEN),
        .s_axi_awlock(S_AXI_OTP_RAM_AWLOCK),
        .s_axi_awprot(S_AXI_OTP_RAM_AWPROT),
        .s_axi_awready(S_AXI_OTP_RAM_AWREADY),
        .s_axi_awsize(S_AXI_OTP_RAM_AWSIZE),
        .s_axi_awvalid(S_AXI_OTP_RAM_AWVALID),
        .s_axi_bready(S_AXI_OTP_RAM_BREADY),
        .s_axi_bresp(S_AXI_OTP_RAM_BRESP),
        .s_axi_bvalid(S_AXI_OTP_RAM_BVALID),
        .s_axi_rdata(S_AXI_OTP_RAM_RDATA),
        .s_axi_rlast(S_AXI_OTP_RAM_RLAST),
        .s_axi_rready(S_AXI_OTP_RAM_RREADY),
        .s_axi_rresp(S_AXI_OTP_RAM_RRESP),
        .s_axi_rvalid(S_AXI_OTP_RAM_RVALID),
        .s_axi_wdata(S_AXI_OTP_RAM_WDATA),
        .s_axi_wlast(S_AXI_OTP_RAM_WLAST),
        .s_axi_wready(S_AXI_OTP_RAM_WREADY),
        .s_axi_wstrb(S_AXI_OTP_RAM_WSTRB),
        .s_axi_wvalid(S_AXI_OTP_RAM_WVALID));
  caliptra_htg940_bd_proc_sys_reset_0_0 proc_sys_reset_0
       (.aux_reset_in(aux_reset_const_0_dout),
        .dcm_locked(board_clock_locked),
        .ext_reset_in(subsystem_reset_n),
        .mb_debug_sys_rst(1'b0),
        .peripheral_aresetn(board_reset_n),
        .slowest_sync_clk(board_core_clk));
  caliptra_htg940_bd_staging_sram_bram_ctrl_0_0 staging_sram_bram_ctrl_0
       (.bram_addr_a(staging_sram_bram_ctrl_0_BRAM_PORTA_ADDR),
        .bram_clk_a(staging_sram_bram_ctrl_0_BRAM_PORTA_CLK),
        .bram_en_a(staging_sram_bram_ctrl_0_BRAM_PORTA_EN),
        .bram_rddata_a(staging_sram_bram_ctrl_0_BRAM_PORTA_DOUT),
        .bram_rst_a(staging_sram_bram_ctrl_0_BRAM_PORTA_RST),
        .bram_we_a(staging_sram_bram_ctrl_0_BRAM_PORTA_WE),
        .bram_wrdata_a(staging_sram_bram_ctrl_0_BRAM_PORTA_DIN),
        .s_axi_aclk(board_core_clk),
        .s_axi_araddr(S_AXI_STAGING_SRAM_ARADDR),
        .s_axi_arburst(S_AXI_STAGING_SRAM_ARBURST),
        .s_axi_arcache(S_AXI_STAGING_SRAM_ARCACHE),
        .s_axi_aresetn(board_reset_n),
        .s_axi_arlen(S_AXI_STAGING_SRAM_ARLEN),
        .s_axi_arlock(S_AXI_STAGING_SRAM_ARLOCK),
        .s_axi_arprot(S_AXI_STAGING_SRAM_ARPROT),
        .s_axi_arready(S_AXI_STAGING_SRAM_ARREADY),
        .s_axi_arsize(S_AXI_STAGING_SRAM_ARSIZE),
        .s_axi_arvalid(S_AXI_STAGING_SRAM_ARVALID),
        .s_axi_awaddr(S_AXI_STAGING_SRAM_AWADDR),
        .s_axi_awburst(S_AXI_STAGING_SRAM_AWBURST),
        .s_axi_awcache(S_AXI_STAGING_SRAM_AWCACHE),
        .s_axi_awlen(S_AXI_STAGING_SRAM_AWLEN),
        .s_axi_awlock(S_AXI_STAGING_SRAM_AWLOCK),
        .s_axi_awprot(S_AXI_STAGING_SRAM_AWPROT),
        .s_axi_awready(S_AXI_STAGING_SRAM_AWREADY),
        .s_axi_awsize(S_AXI_STAGING_SRAM_AWSIZE),
        .s_axi_awvalid(S_AXI_STAGING_SRAM_AWVALID),
        .s_axi_bready(S_AXI_STAGING_SRAM_BREADY),
        .s_axi_bresp(S_AXI_STAGING_SRAM_BRESP),
        .s_axi_bvalid(S_AXI_STAGING_SRAM_BVALID),
        .s_axi_rdata(S_AXI_STAGING_SRAM_RDATA),
        .s_axi_rlast(S_AXI_STAGING_SRAM_RLAST),
        .s_axi_rready(S_AXI_STAGING_SRAM_RREADY),
        .s_axi_rresp(S_AXI_STAGING_SRAM_RRESP),
        .s_axi_rvalid(S_AXI_STAGING_SRAM_RVALID),
        .s_axi_wdata(S_AXI_STAGING_SRAM_WDATA),
        .s_axi_wlast(S_AXI_STAGING_SRAM_WLAST),
        .s_axi_wready(S_AXI_STAGING_SRAM_WREADY),
        .s_axi_wstrb(S_AXI_STAGING_SRAM_WSTRB),
        .s_axi_wvalid(S_AXI_STAGING_SRAM_WVALID));
  caliptra_htg940_bd_staging_sram_emb_mem_gen_0_0 staging_sram_emb_mem_gen_0
       (.addra({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,staging_sram_bram_ctrl_0_BRAM_PORTA_ADDR}),
        .clka(staging_sram_bram_ctrl_0_BRAM_PORTA_CLK),
        .dina(staging_sram_bram_ctrl_0_BRAM_PORTA_DIN),
        .douta(staging_sram_bram_ctrl_0_BRAM_PORTA_DOUT),
        .ena(staging_sram_bram_ctrl_0_BRAM_PORTA_EN),
        .rsta(staging_sram_bram_ctrl_0_BRAM_PORTA_RST),
        .wea(staging_sram_bram_ctrl_0_BRAM_PORTA_WE));
  caliptra_htg940_bd_usb_interconnect_0_0 usb_interconnect_0
       (.M00_AXI_araddr(S_AXI_USB_DEV_ARADDR),
        .M00_AXI_arburst(S_AXI_USB_DEV_ARBURST),
        .M00_AXI_arlen(S_AXI_USB_DEV_ARLEN),
        .M00_AXI_arlock(S_AXI_USB_DEV_ARLOCK),
        .M00_AXI_arready(S_AXI_USB_DEV_ARREADY),
        .M00_AXI_arsize(S_AXI_USB_DEV_ARSIZE),
        .M00_AXI_aruser(S_AXI_USB_DEV_ARUSER),
        .M00_AXI_arvalid(S_AXI_USB_DEV_ARVALID),
        .M00_AXI_awaddr(S_AXI_USB_DEV_AWADDR),
        .M00_AXI_awburst(S_AXI_USB_DEV_AWBURST),
        .M00_AXI_awlen(S_AXI_USB_DEV_AWLEN),
        .M00_AXI_awlock(S_AXI_USB_DEV_AWLOCK),
        .M00_AXI_awready(S_AXI_USB_DEV_AWREADY),
        .M00_AXI_awsize(S_AXI_USB_DEV_AWSIZE),
        .M00_AXI_awuser(S_AXI_USB_DEV_AWUSER),
        .M00_AXI_awvalid(S_AXI_USB_DEV_AWVALID),
        .M00_AXI_bready(S_AXI_USB_DEV_BREADY),
        .M00_AXI_bresp(S_AXI_USB_DEV_BRESP),
        .M00_AXI_bvalid(S_AXI_USB_DEV_BVALID),
        .M00_AXI_rdata(S_AXI_USB_DEV_RDATA),
        .M00_AXI_rlast(S_AXI_USB_DEV_RLAST),
        .M00_AXI_rready(S_AXI_USB_DEV_RREADY),
        .M00_AXI_rresp(S_AXI_USB_DEV_RRESP),
        .M00_AXI_rvalid(S_AXI_USB_DEV_RVALID),
        .M00_AXI_wdata(S_AXI_USB_DEV_WDATA),
        .M00_AXI_wlast(S_AXI_USB_DEV_WLAST),
        .M00_AXI_wready(S_AXI_USB_DEV_WREADY),
        .M00_AXI_wstrb(S_AXI_USB_DEV_WSTRB),
        .M00_AXI_wvalid(S_AXI_USB_DEV_WVALID),
        .M01_AXI_araddr(S_AXI_USB_HOST_ARADDR),
        .M01_AXI_arburst(S_AXI_USB_HOST_ARBURST),
        .M01_AXI_arlen(S_AXI_USB_HOST_ARLEN),
        .M01_AXI_arlock(S_AXI_USB_HOST_ARLOCK),
        .M01_AXI_arready(S_AXI_USB_HOST_ARREADY),
        .M01_AXI_arsize(S_AXI_USB_HOST_ARSIZE),
        .M01_AXI_aruser(S_AXI_USB_HOST_ARUSER),
        .M01_AXI_arvalid(S_AXI_USB_HOST_ARVALID),
        .M01_AXI_awaddr(S_AXI_USB_HOST_AWADDR),
        .M01_AXI_awburst(S_AXI_USB_HOST_AWBURST),
        .M01_AXI_awlen(S_AXI_USB_HOST_AWLEN),
        .M01_AXI_awlock(S_AXI_USB_HOST_AWLOCK),
        .M01_AXI_awready(S_AXI_USB_HOST_AWREADY),
        .M01_AXI_awsize(S_AXI_USB_HOST_AWSIZE),
        .M01_AXI_awuser(S_AXI_USB_HOST_AWUSER),
        .M01_AXI_awvalid(S_AXI_USB_HOST_AWVALID),
        .M01_AXI_bready(S_AXI_USB_HOST_BREADY),
        .M01_AXI_bresp(S_AXI_USB_HOST_BRESP),
        .M01_AXI_bvalid(S_AXI_USB_HOST_BVALID),
        .M01_AXI_rdata(S_AXI_USB_HOST_RDATA),
        .M01_AXI_rlast(S_AXI_USB_HOST_RLAST),
        .M01_AXI_rready(S_AXI_USB_HOST_RREADY),
        .M01_AXI_rresp(S_AXI_USB_HOST_RRESP),
        .M01_AXI_rvalid(S_AXI_USB_HOST_RVALID),
        .M01_AXI_wdata(S_AXI_USB_HOST_WDATA),
        .M01_AXI_wlast(S_AXI_USB_HOST_WLAST),
        .M01_AXI_wready(S_AXI_USB_HOST_WREADY),
        .M01_AXI_wstrb(S_AXI_USB_HOST_WSTRB),
        .M01_AXI_wvalid(S_AXI_USB_HOST_WVALID),
        .M02_AXI_araddr(S_AXI_USB_DMA_ARADDR),
        .M02_AXI_arburst(S_AXI_USB_DMA_ARBURST),
        .M02_AXI_arlen(S_AXI_USB_DMA_ARLEN),
        .M02_AXI_arlock(S_AXI_USB_DMA_ARLOCK),
        .M02_AXI_arready(S_AXI_USB_DMA_ARREADY),
        .M02_AXI_arsize(S_AXI_USB_DMA_ARSIZE),
        .M02_AXI_aruser(S_AXI_USB_DMA_ARUSER),
        .M02_AXI_arvalid(S_AXI_USB_DMA_ARVALID),
        .M02_AXI_awaddr(S_AXI_USB_DMA_AWADDR),
        .M02_AXI_awburst(S_AXI_USB_DMA_AWBURST),
        .M02_AXI_awlen(S_AXI_USB_DMA_AWLEN),
        .M02_AXI_awlock(S_AXI_USB_DMA_AWLOCK),
        .M02_AXI_awready(S_AXI_USB_DMA_AWREADY),
        .M02_AXI_awsize(S_AXI_USB_DMA_AWSIZE),
        .M02_AXI_awuser(S_AXI_USB_DMA_AWUSER),
        .M02_AXI_awvalid(S_AXI_USB_DMA_AWVALID),
        .M02_AXI_bready(S_AXI_USB_DMA_BREADY),
        .M02_AXI_bresp(S_AXI_USB_DMA_BRESP),
        .M02_AXI_bvalid(S_AXI_USB_DMA_BVALID),
        .M02_AXI_rdata(S_AXI_USB_DMA_RDATA),
        .M02_AXI_rlast(S_AXI_USB_DMA_RLAST),
        .M02_AXI_rready(S_AXI_USB_DMA_RREADY),
        .M02_AXI_rresp(S_AXI_USB_DMA_RRESP),
        .M02_AXI_rvalid(S_AXI_USB_DMA_RVALID),
        .M02_AXI_wdata(S_AXI_USB_DMA_WDATA),
        .M02_AXI_wlast(S_AXI_USB_DMA_WLAST),
        .M02_AXI_wready(S_AXI_USB_DMA_WREADY),
        .M02_AXI_wstrb(S_AXI_USB_DMA_WSTRB),
        .M02_AXI_wvalid(S_AXI_USB_DMA_WVALID),
        .S00_AXI_araddr(M_AXI_USB_BRIDGE_ARADDR),
        .S00_AXI_arburst(M_AXI_USB_BRIDGE_ARBURST),
        .S00_AXI_arcache(M_AXI_USB_BRIDGE_ARCACHE),
        .S00_AXI_arid(M_AXI_USB_BRIDGE_ARID),
        .S00_AXI_arlen(M_AXI_USB_BRIDGE_ARLEN),
        .S00_AXI_arlock(M_AXI_USB_BRIDGE_ARLOCK),
        .S00_AXI_arprot(M_AXI_USB_BRIDGE_ARPROT),
        .S00_AXI_arqos(M_AXI_USB_BRIDGE_ARQOS),
        .S00_AXI_arready(M_AXI_USB_BRIDGE_ARREADY),
        .S00_AXI_arsize(M_AXI_USB_BRIDGE_ARSIZE),
        .S00_AXI_aruser(M_AXI_USB_BRIDGE_ARUSER),
        .S00_AXI_arvalid(M_AXI_USB_BRIDGE_ARVALID),
        .S00_AXI_awaddr(M_AXI_USB_BRIDGE_AWADDR),
        .S00_AXI_awburst(M_AXI_USB_BRIDGE_AWBURST),
        .S00_AXI_awcache(M_AXI_USB_BRIDGE_AWCACHE),
        .S00_AXI_awid(M_AXI_USB_BRIDGE_AWID),
        .S00_AXI_awlen(M_AXI_USB_BRIDGE_AWLEN),
        .S00_AXI_awlock(M_AXI_USB_BRIDGE_AWLOCK),
        .S00_AXI_awprot(M_AXI_USB_BRIDGE_AWPROT),
        .S00_AXI_awqos(M_AXI_USB_BRIDGE_AWQOS),
        .S00_AXI_awready(M_AXI_USB_BRIDGE_AWREADY),
        .S00_AXI_awsize(M_AXI_USB_BRIDGE_AWSIZE),
        .S00_AXI_awuser(M_AXI_USB_BRIDGE_AWUSER),
        .S00_AXI_awvalid(M_AXI_USB_BRIDGE_AWVALID),
        .S00_AXI_bid(M_AXI_USB_BRIDGE_BID),
        .S00_AXI_bready(M_AXI_USB_BRIDGE_BREADY),
        .S00_AXI_bresp(M_AXI_USB_BRIDGE_BRESP),
        .S00_AXI_buser(M_AXI_USB_BRIDGE_BUSER),
        .S00_AXI_bvalid(M_AXI_USB_BRIDGE_BVALID),
        .S00_AXI_rdata(M_AXI_USB_BRIDGE_RDATA),
        .S00_AXI_rid(M_AXI_USB_BRIDGE_RID),
        .S00_AXI_rlast(M_AXI_USB_BRIDGE_RLAST),
        .S00_AXI_rready(M_AXI_USB_BRIDGE_RREADY),
        .S00_AXI_rresp(M_AXI_USB_BRIDGE_RRESP),
        .S00_AXI_ruser(M_AXI_USB_BRIDGE_RUSER),
        .S00_AXI_rvalid(M_AXI_USB_BRIDGE_RVALID),
        .S00_AXI_wdata(M_AXI_USB_BRIDGE_WDATA),
        .S00_AXI_wlast(M_AXI_USB_BRIDGE_WLAST),
        .S00_AXI_wready(M_AXI_USB_BRIDGE_WREADY),
        .S00_AXI_wstrb(M_AXI_USB_BRIDGE_WSTRB),
        .S00_AXI_wuser(M_AXI_USB_BRIDGE_WUSER),
        .S00_AXI_wvalid(M_AXI_USB_BRIDGE_WVALID),
        .aclk(board_core_clk),
        .aresetn(board_reset_n));
  caliptra_htg940_bd_xilinx_i3c_0_0 xilinx_i3c_0
       (.s_axi_aclk(htg940_clocks_clk_out2),
        .s_axi_araddr(S_AXI_XILINX_I3C_ARADDR),
        .s_axi_aresetn(xpm_cdc_gen_0_dest_rst_out),
        .s_axi_arready(S_AXI_XILINX_I3C_ARREADY),
        .s_axi_arvalid(S_AXI_XILINX_I3C_ARVALID),
        .s_axi_awaddr(S_AXI_XILINX_I3C_AWADDR),
        .s_axi_awready(S_AXI_XILINX_I3C_AWREADY),
        .s_axi_awvalid(S_AXI_XILINX_I3C_AWVALID),
        .s_axi_bready(S_AXI_XILINX_I3C_BREADY),
        .s_axi_bresp(S_AXI_XILINX_I3C_BRESP),
        .s_axi_bvalid(S_AXI_XILINX_I3C_BVALID),
        .s_axi_rdata(S_AXI_XILINX_I3C_RDATA),
        .s_axi_rready(S_AXI_XILINX_I3C_RREADY),
        .s_axi_rresp(S_AXI_XILINX_I3C_RRESP),
        .s_axi_rvalid(S_AXI_XILINX_I3C_RVALID),
        .s_axi_wdata(S_AXI_XILINX_I3C_WDATA),
        .s_axi_wready(S_AXI_XILINX_I3C_WREADY),
        .s_axi_wstrb(S_AXI_XILINX_I3C_WSTRB),
        .s_axi_wvalid(S_AXI_XILINX_I3C_WVALID),
        .scl_i(caliptra_package_top_0_xilinx_scl),
        .scl_o(xilinx_i3c_0_scl_o),
        .scl_pullup_en(xilinx_i3c_0_scl_pullup_en),
        .scl_t(xilinx_i3c_0_scl_t),
        .sda_i(caliptra_package_top_0_xilinx_sda),
        .sda_o(xilinx_i3c_0_sda_o),
        .sda_pullup_en(xilinx_i3c_0_sda_pullup_en),
        .sda_t(xilinx_i3c_0_sda_t));
  caliptra_htg940_bd_xpm_cdc_gen_0_0 xpm_cdc_gen_0
       (.dest_clk(htg940_clocks_clk_out2),
        .dest_rst_out(xpm_cdc_gen_0_dest_rst_out),
        .src_rst(caliptra_package_top_0_xilinx_i3c_aresetn));
endmodule
