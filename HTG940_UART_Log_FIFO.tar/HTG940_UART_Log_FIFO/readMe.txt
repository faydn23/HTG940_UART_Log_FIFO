htg940_board_top.sv	FPGA top; connects UART and both log streams
htg940_entropy_uart.sv	UART transport and command/reply handling
htg940_log_bridge.sv	MCU/Core log handling
htg940_entropy_control.sv	Entropy and subsystem control used by the board top
caliptra_package_top.v	Exposes the packaged subsystem interfaces
caliptra_wrapper_top.sv	Captures and exports internal log signals
htg940_board_nxp.xdc	Physical board pin constraints
htg940_pc_console/	PC-side Python reader


