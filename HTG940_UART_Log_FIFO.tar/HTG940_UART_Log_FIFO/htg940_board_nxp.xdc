# NXP HTG940 profile: USB FMC D, I3C FMC C; no external processor JTAG.
# Verify connector and VADJ settings match this profile before programming.
# Clock/reset/LED pins match the tested HTG940 smoke design.
set_property PACKAGE_PIN AW28 [get_ports {ref_clock_156p25mhz_clk_p}]
set_property IOSTANDARD LVDS [get_ports {ref_clock_156p25mhz_clk_p}]
set_property PACKAGE_PIN AY28 [get_ports {ref_clock_156p25mhz_clk_n}]
set_property IOSTANDARD LVDS [get_ports {ref_clock_156p25mhz_clk_n}]
set_property PACKAGE_PIN AJ34 [get_ports {resetn_i}]
set_property IOSTANDARD LVCMOS12 [get_ports {resetn_i}]
set_property PACKAGE_PIN AK32 [get_ports {usb_phy_resetn_i}]
set_property IOSTANDARD LVCMOS12 [get_ports {usb_phy_resetn_i}]
set_property PACKAGE_PIN BB22 [get_ports {usb_phy_resetn_o}]
set_property IOSTANDARD LVCMOS18 [get_ports {usb_phy_resetn_o}]
set_property PACKAGE_PIN AP28 [get_ports {GPIO_o[0]}]
set_property IOSTANDARD LVCMOS18 [get_ports {GPIO_o[0]}]
set_property PACKAGE_PIN AN28 [get_ports {GPIO_o[1]}]
set_property IOSTANDARD LVCMOS18 [get_ports {GPIO_o[1]}]
set_property PACKAGE_PIN AP26 [get_ports {GPIO_o[2]}]
set_property IOSTANDARD LVCMOS18 [get_ports {GPIO_o[2]}]
set_property PACKAGE_PIN AW16 [get_ports {cptra_ss_usb_ulpi_clk_i}]
set_property IOSTANDARD LVCMOS18 [get_ports {cptra_ss_usb_ulpi_clk_i}]
set_property PACKAGE_PIN AL15 [get_ports {cptra_ss_usb_ulpi_data_io[0]}]
set_property IOSTANDARD LVCMOS18 [get_ports {cptra_ss_usb_ulpi_data_io[0]}]
set_property PACKAGE_PIN AM15 [get_ports {cptra_ss_usb_ulpi_data_io[1]}]
set_property IOSTANDARD LVCMOS18 [get_ports {cptra_ss_usb_ulpi_data_io[1]}]
set_property PACKAGE_PIN AP15 [get_ports {cptra_ss_usb_ulpi_data_io[2]}]
set_property IOSTANDARD LVCMOS18 [get_ports {cptra_ss_usb_ulpi_data_io[2]}]
set_property PACKAGE_PIN AM14 [get_ports {cptra_ss_usb_ulpi_data_io[3]}]
set_property IOSTANDARD LVCMOS18 [get_ports {cptra_ss_usb_ulpi_data_io[3]}]
set_property PACKAGE_PIN AN14 [get_ports {cptra_ss_usb_ulpi_data_io[4]}]
set_property IOSTANDARD LVCMOS18 [get_ports {cptra_ss_usb_ulpi_data_io[4]}]
set_property PACKAGE_PIN AN13 [get_ports {cptra_ss_usb_ulpi_data_io[5]}]
set_property IOSTANDARD LVCMOS18 [get_ports {cptra_ss_usb_ulpi_data_io[5]}]
set_property PACKAGE_PIN AT15 [get_ports {cptra_ss_usb_ulpi_data_io[6]}]
set_property IOSTANDARD LVCMOS18 [get_ports {cptra_ss_usb_ulpi_data_io[6]}]
set_property PACKAGE_PIN AU15 [get_ports {cptra_ss_usb_ulpi_data_io[7]}]
set_property IOSTANDARD LVCMOS18 [get_ports {cptra_ss_usb_ulpi_data_io[7]}]
set_property PACKAGE_PIN AW15 [get_ports {cptra_ss_usb_ulpi_dir_i}]
set_property IOSTANDARD LVCMOS18 [get_ports {cptra_ss_usb_ulpi_dir_i}]
set_property PACKAGE_PIN AL14 [get_ports {cptra_ss_usb_ulpi_stp_o}]
set_property IOSTANDARD LVCMOS18 [get_ports {cptra_ss_usb_ulpi_stp_o}]
set_property PACKAGE_PIN AP14 [get_ports {cptra_ss_usb_ulpi_nxt_i}]
set_property IOSTANDARD LVCMOS18 [get_ports {cptra_ss_usb_ulpi_nxt_i}]
set_property PACKAGE_PIN AN22 [get_ports {cptra_ss_i3c_scl_io}]
set_property IOSTANDARD LVCMOS18 [get_ports {cptra_ss_i3c_scl_io}]
set_property PACKAGE_PIN AN21 [get_ports {cptra_ss_i3c_sda_io}]
set_property IOSTANDARD LVCMOS18 [get_ports {cptra_ss_i3c_sda_io}]

create_clock -name ref_clock_156p25mhz -period 6.400 [get_ports ref_clock_156p25mhz_clk_p]
create_clock -name usb_clk -period 16.667 [get_ports cptra_ss_usb_ulpi_clk_i]

# ULPI timing budget supplied by NXP; board timing closure still needs validation.
set_input_delay -clock usb_clk -max 3.65 [get_ports {cptra_ss_usb_ulpi_data_io[*] cptra_ss_usb_ulpi_dir_i cptra_ss_usb_ulpi_nxt_i}]
set_input_delay -clock usb_clk -min 1.0 [get_ports {cptra_ss_usb_ulpi_data_io[*] cptra_ss_usb_ulpi_dir_i cptra_ss_usb_ulpi_nxt_i}]
set_output_delay -clock usb_clk -max 5.15 [get_ports {cptra_ss_usb_ulpi_data_io[*] cptra_ss_usb_ulpi_stp_o}]
set_output_delay -clock usb_clk -min 0.0 [get_ports {cptra_ss_usb_ulpi_data_io[*] cptra_ss_usb_ulpi_stp_o}]


# No blanket asynchronous clock groups or DRC downgrades are imported.
# I3C is externally asynchronous and sampled through existing synchronizers.


# HTG940_ENTROPY_CONTROL_V1
# CP2103 VIO is powered by VADJ_FMC_A. This profile requires 1.8 V there.
# Net UART_TXD is the CP2103 output, hence FPGA input R15.
set_property PACKAGE_PIN R15 [get_ports host_uart_rx_i]
set_property IOSTANDARD LVCMOS18 [get_ports host_uart_rx_i]
set_property PULLUP true [get_ports host_uart_rx_i]
set_property PACKAGE_PIN P15 [get_ports host_uart_tx_o]
set_property IOSTANDARD LVCMOS18 [get_ports host_uart_tx_o]

# HTG940_NO_FMC_JTAG_V1: J3 configuration JTAG uses dedicated FPGA pins.
