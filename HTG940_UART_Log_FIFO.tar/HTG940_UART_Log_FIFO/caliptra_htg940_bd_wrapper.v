//Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
//Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
//--------------------------------------------------------------------------------
//Tool Version: Vivado v.2025.1_REL2_CR1238551_REL2 (lin64) Build 0 Fri Sep 12 10:40:17 MDT 2025
//Date        : Thu Sep 24 17:58:14 2026
//Host        : bearcat14802 running 64-bit Rocky Linux release 8.10 (Green Obsidian)
//Command     : generate_target caliptra_htg940_bd_wrapper.bd
//Design      : caliptra_htg940_bd_wrapper
//Purpose     : IP block netlist
//--------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

module caliptra_htg940_bd_wrapper
   (EXT_SCL,
    EXT_SDA,
    EXT_SDA_EN,
    EXT_SDA_IN,
    EXT_SDA_UP,
    USB_ULPI_CLK,
    USB_ULPI_DATA,
    USB_ULPI_DIR,
    USB_ULPI_NXT,
    USB_ULPI_STP,
    board_clock_locked,
    board_core_clk,
    board_core_log_byte,
    board_core_log_valid,
    board_mcu_log_byte,
    board_mcu_log_valid,
    board_reset_n,
    host_entropy_data,
    host_entropy_req,
    host_entropy_valid,
    jtag_in,
    jtag_out,
    ref_clock_156p25mhz_clk_n,
    ref_clock_156p25mhz_clk_p,
    reset_n,
    subsystem_reset_n);
  input EXT_SCL;
  input EXT_SDA;
  output EXT_SDA_EN;
  output EXT_SDA_IN;
  output EXT_SDA_UP;
  input USB_ULPI_CLK;
  inout [7:0]USB_ULPI_DATA;
  input USB_ULPI_DIR;
  input USB_ULPI_NXT;
  output USB_ULPI_STP;
  output board_clock_locked;
  output board_core_clk;
  output [7:0]board_core_log_byte;
  output board_core_log_valid;
  output [7:0]board_mcu_log_byte;
  output board_mcu_log_valid;
  output [0:0]board_reset_n;
  input [3:0]host_entropy_data;
  output host_entropy_req;
  input host_entropy_valid;
  input [14:0]jtag_in;
  output [14:0]jtag_out;
  input ref_clock_156p25mhz_clk_n;
  input ref_clock_156p25mhz_clk_p;
  input reset_n;
  input subsystem_reset_n;

  wire EXT_SCL;
  wire EXT_SDA;
  wire EXT_SDA_EN;
  wire EXT_SDA_IN;
  wire EXT_SDA_UP;
  wire USB_ULPI_CLK;
  wire [7:0]USB_ULPI_DATA;
  wire USB_ULPI_DIR;
  wire USB_ULPI_NXT;
  wire USB_ULPI_STP;
  wire board_clock_locked;
  wire board_core_clk;
  wire [7:0]board_core_log_byte;
  wire board_core_log_valid;
  wire [7:0]board_mcu_log_byte;
  wire board_mcu_log_valid;
  wire [0:0]board_reset_n;
  wire [3:0]host_entropy_data;
  wire host_entropy_req;
  wire host_entropy_valid;
  wire [14:0]jtag_in;
  wire [14:0]jtag_out;
  wire ref_clock_156p25mhz_clk_n;
  wire ref_clock_156p25mhz_clk_p;
  wire reset_n;
  wire subsystem_reset_n;

  caliptra_htg940_bd caliptra_htg940_bd_i
       (.EXT_SCL(EXT_SCL),
        .EXT_SDA(EXT_SDA),
        .EXT_SDA_EN(EXT_SDA_EN),
        .EXT_SDA_IN(EXT_SDA_IN),
        .EXT_SDA_UP(EXT_SDA_UP),
        .USB_ULPI_CLK(USB_ULPI_CLK),
        .USB_ULPI_DATA(USB_ULPI_DATA),
        .USB_ULPI_DIR(USB_ULPI_DIR),
        .USB_ULPI_NXT(USB_ULPI_NXT),
        .USB_ULPI_STP(USB_ULPI_STP),
        .board_clock_locked(board_clock_locked),
        .board_core_clk(board_core_clk),
        .board_core_log_byte(board_core_log_byte),
        .board_core_log_valid(board_core_log_valid),
        .board_mcu_log_byte(board_mcu_log_byte),
        .board_mcu_log_valid(board_mcu_log_valid),
        .board_reset_n(board_reset_n),
        .host_entropy_data(host_entropy_data),
        .host_entropy_req(host_entropy_req),
        .host_entropy_valid(host_entropy_valid),
        .jtag_in(jtag_in),
        .jtag_out(jtag_out),
        .ref_clock_156p25mhz_clk_n(ref_clock_156p25mhz_clk_n),
        .ref_clock_156p25mhz_clk_p(ref_clock_156p25mhz_clk_p),
        .reset_n(reset_n),
        .subsystem_reset_n(subsystem_reset_n));
endmodule
